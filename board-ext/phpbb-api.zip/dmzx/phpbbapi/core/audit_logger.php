<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use phpbb\db\driver\driver_interface;

class audit_logger
{
	/** @var driver_interface */
	protected $db;

	/** @var string */
	protected $log_table;

	/**
	 * @param driver_interface	$db
	 * @param string			$log_table
	 */
	public function __construct(driver_interface $db, $log_table)
	{
		$this->db = $db;
		$this->log_table = $log_table;
	}

	/**
	 * @param int		$credential_id
	 * @param int		$user_id
	 * @param string	$ip
	 * @param string	$method
	 * @param string	$route
	 * @param int		$status
	 * @param string	$error_code
	 * @return void
	 */
	public function log($credential_id, $user_id, $ip, $method, $route, $status, $error_code)
	{
		$sql_ary = [
			'credential_id'	=> (int) $credential_id,
			'user_id'		=> (int) $user_id,
			'ip'			=> substr((string) $ip, 0, 45),
			'method'		=> substr((string) $method, 0, 10),
			'route'			=> substr((string) $route, 0, 100),
			'status'		=> (int) $status,
			'error_code'	=> substr((string) $error_code, 0, 50),
			'request_time'	=> time(),
		];

		$sql = 'INSERT INTO ' . $this->log_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$start
	 * @param int	$limit
	 * @return array
	 */
	public function get_entries($start, $limit)
	{
		$sql = 'SELECT * FROM ' . $this->log_table . '
			ORDER BY request_time DESC';
		$result = $this->db->sql_query_limit($sql, $limit, $start);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param int	$before	unix time - entries older than this are removed
	 * @return void
	 */
	public function prune($before)
	{
		$sql = 'DELETE FROM ' . $this->log_table . '
			WHERE request_time < ' . (int) $before;
		$this->db->sql_query($sql);
	}

	/**
	 * @return int
	 */
	public function count_entries()
	{
		$sql = 'SELECT COUNT(*) AS total FROM ' . $this->log_table;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		return $total;
	}

	/**
	 * @param int	$since
	 * @return int
	 */
	public function count_since($since)
	{
		$sql = 'SELECT COUNT(*) AS total FROM ' . $this->log_table . '
			WHERE request_time >= ' . (int) $since;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		return $total;
	}

	/**
	 * @param int	$since
	 * @return int
	 */
	public function count_errors_since($since)
	{
		$sql = 'SELECT COUNT(*) AS total FROM ' . $this->log_table . '
			WHERE request_time >= ' . (int) $since . '
				AND status >= 400';
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		return $total;
	}

	/**
	 * @param int	$since
	 * @param int	$limit
	 * @return array
	 */
	public function top_routes($since, $limit)
	{
		$sql = 'SELECT route, COUNT(*) AS hits
			FROM ' . $this->log_table . '
			WHERE request_time >= ' . (int) $since . '
			GROUP BY route
			ORDER BY hits DESC';
		$result = $this->db->sql_query_limit($sql, $limit);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}
}
