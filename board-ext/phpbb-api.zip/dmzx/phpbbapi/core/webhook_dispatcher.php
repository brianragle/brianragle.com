<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use phpbb\db\driver\driver_interface;

class webhook_dispatcher
{
	const TIMEOUT_SECONDS = 5;

	const RETRY_BACKOFF = [60, 300, 1800, 7200, 43200];

	/** @var driver_interface */
	protected $db;

	/** @var webhook_manager */
	protected $webhook_manager;

	/** @var string */
	protected $webhook_log_table;

	/**
	 * @param driver_interface	$db
	 * @param webhook_manager	$webhook_manager
	 * @param string			$webhook_log_table
	 */
	public function __construct(driver_interface $db, webhook_manager $webhook_manager, $webhook_log_table)
	{
		$this->db = $db;
		$this->webhook_manager = $webhook_manager;
		$this->webhook_log_table = $webhook_log_table;
	}

	/**
	 * @param string	$event
	 * @param array		$data
	 * @param string	$origin	'api' or 'ui'
	 * @return void
	 */
	public function dispatch($event, array $data, $origin = 'api')
	{
		try
		{
			$webhooks = $this->webhook_manager->get_enabled_webhooks_for_event($event, $origin === 'ui');

			if (empty($webhooks))
			{
				return;
			}

			$payload = json_encode([
				'event'	=> $event,
				'time'	=> time(),
				'data'	=> $data,
			]);

			foreach ($webhooks as $webhook)
			{
				$this->deliver($webhook, $event, (string) $payload);
			}
		}
		catch (\Throwable $e)
		{
		}
	}

	/**
	 * @param array		$webhook
	 * @param string	$event
	 * @param string	$payload
	 * @return void
	 */
	protected function deliver(array $webhook, $event, $payload)
	{
		$result = $this->send($webhook, $event, $payload);

		$this->log_delivery((int) $webhook['webhook_id'], $event, $payload, $result);
		$this->webhook_manager->record_delivery_result((int) $webhook['webhook_id'], $result['success']);
	}

	/**
	 * @param int	$limit
	 * @return void
	 */
	public function process_due_retries($limit = 50)
	{
		foreach ($this->get_due_retries($limit) as $log_row)
		{
			$this->retry_delivery($log_row);
		}
	}

	/**
	 * @param array	$webhook
	 * @param string	$event
	 * @param string	$payload
	 * @return array	['status_code' => int, 'success' => bool, 'detail' => string]
	 */
	protected function send(array $webhook, $event, $payload)
	{
		if (strtolower((string) parse_url((string) $webhook['url'], PHP_URL_SCHEME)) !== 'https')
		{
			return ['status_code' => 0, 'success' => false, 'detail' => 'https_required'];
		}

		$signature = hash_hmac('sha256', $payload, $webhook['secret']);

		$headers = [
			'Content-Type: application/json',
			'X-Webhook-Event: ' . $event,
			'X-Webhook-Signature: sha256=' . $signature,
		];

		if ((string) ($webhook['previous_secret'] ?? '') !== '' && (int) ($webhook['previous_secret_expires_time'] ?? 0) > time())
		{
			$headers[] = 'X-Webhook-Signature-Previous: sha256=' . hash_hmac('sha256', $payload, $webhook['previous_secret']);
		}

		$ch = curl_init();
		curl_setopt_array($ch, [
			CURLOPT_URL				=> $webhook['url'],
			CURLOPT_POST			=> true,
			CURLOPT_POSTFIELDS		=> $payload,
			CURLOPT_HTTPHEADER		=> $headers,
			CURLOPT_RETURNTRANSFER	=> true,
			CURLOPT_TIMEOUT			=> self::TIMEOUT_SECONDS,
			CURLOPT_CONNECTTIMEOUT	=> self::TIMEOUT_SECONDS,
			CURLOPT_FOLLOWLOCATION	=> false,
			CURLOPT_PROTOCOLS		=> CURLPROTO_HTTPS,
			CURLOPT_SSL_VERIFYPEER	=> true,
			CURLOPT_SSL_VERIFYHOST	=> 2,
		]);

		$response = curl_exec($ch);
		$status_code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$curl_error = curl_error($ch);
		curl_close($ch);

		$success = $status_code >= 200 && $status_code < 300;
		$detail = $success ? (string) $response : ($curl_error !== '' ? $curl_error : (string) $response);

		return ['status_code' => $status_code, 'success' => $success, 'detail' => $detail];
	}

	/**
	 * @param int		$webhook_id
	 * @param string	$event
	 * @param string	$payload
	 * @param array		$result	['status_code' => int, 'success' => bool, 'detail' => string]
	 * @return void
	 */
	protected function log_delivery($webhook_id, $event, $payload, array $result)
	{
		$sql_ary = [
			'webhook_id'		=> (int) $webhook_id,
			'event'				=> substr((string) $event, 0, 100),
			'payload'			=> (string) $payload,
			'status_code'		=> max(0, $result['status_code']),
			'success'			=> $result['success'] ? 1 : 0,
			'response_snippet'	=> utf8_substr((string) $result['detail'], 0, 255),
			'retry_count'		=> 0,
			'next_retry_time'	=> $result['success'] ? 0 : (time() + self::RETRY_BACKOFF[0]),
			'request_time'		=> time(),
		];

		$sql = 'INSERT INTO ' . $this->webhook_log_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$limit
	 * @return array
	 */
	protected function get_due_retries($limit)
	{
		$sql = 'SELECT * FROM ' . $this->webhook_log_table . '
			WHERE success = 0
				AND next_retry_time > 0
				AND next_retry_time <= ' . time() . '
			ORDER BY next_retry_time ASC';
		$result = $this->db->sql_query_limit($sql, $limit);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param array	$log_row
	 * @return void
	 */
	protected function retry_delivery(array $log_row)
	{
		$webhook = $this->webhook_manager->get_webhook((int) $log_row['webhook_id']);

		if ($webhook === null || !$webhook['enabled'])
		{
			$this->give_up($log_row);

			return;
		}

		$result = $this->send($webhook, $log_row['event'], $log_row['payload']);
		$retry_count = (int) $log_row['retry_count'] + 1;
		$next_retry_time = (!$result['success'] && $retry_count < count(self::RETRY_BACKOFF))
			? time() + self::RETRY_BACKOFF[$retry_count]
			: 0;

		$sql_ary = [
			'status_code'		=> max(0, $result['status_code']),
			'success'			=> $result['success'] ? 1 : 0,
			'response_snippet'	=> utf8_substr((string) $result['detail'], 0, 255),
			'retry_count'		=> $retry_count,
			'next_retry_time'	=> $next_retry_time,
			'request_time'		=> time(),
		];

		$sql = 'UPDATE ' . $this->webhook_log_table . '
			SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE log_id = ' . (int) $log_row['log_id'];
		$this->db->sql_query($sql);

		$this->webhook_manager->record_delivery_result((int) $webhook['webhook_id'], $result['success']);
	}

	/**
	 * @param array	$log_row
	 * @return void
	 */
	protected function give_up(array $log_row)
	{
		$sql = 'UPDATE ' . $this->webhook_log_table . '
			SET next_retry_time = 0
			WHERE log_id = ' . (int) $log_row['log_id'];
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$start
	 * @param int	$limit
	 * @return array
	 */
	public function get_log_entries($start, $limit)
	{
		$sql = 'SELECT * FROM ' . $this->webhook_log_table . '
			ORDER BY request_time DESC';
		$result = $this->db->sql_query_limit($sql, $limit, $start);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param int	$before	unix time - delivered or given-up entries older than this are removed, pending retries stay
	 * @return void
	 */
	public function prune_log($before)
	{
		$sql = 'DELETE FROM ' . $this->webhook_log_table . '
			WHERE request_time < ' . (int) $before . '
				AND (success = 1 OR next_retry_time = 0)';
		$this->db->sql_query($sql);
	}

	/**
	 * @return int
	 */
	public function count_log_entries()
	{
		$sql = 'SELECT COUNT(*) AS total FROM ' . $this->webhook_log_table;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		return $total;
	}
}
