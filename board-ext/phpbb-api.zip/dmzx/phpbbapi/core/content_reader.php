<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\content_visibility;
use phpbb\db\driver\driver_interface;
use phpbb\event\dispatcher_interface;
use phpbb\user;

class content_reader
{
	const MAX_LIMIT = 100;
	const DEFAULT_LIMIT = 25;

	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var content_visibility */
	protected $visibility;

	/** @var user */
	protected $user;

	/** @var config */
	protected $config;

	/** @var dispatcher_interface */
	protected $dispatcher;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var object|null	\phpbb\search\search_backend_factory on 4.0.x, null on 3.3.x */
	protected $search_backend_factory;

	/**
	 * @param driver_interface		$db
	 * @param auth					$auth
	 * @param content_visibility	$visibility
	 * @param user					$user
	 * @param config				$config
	 * @param dispatcher_interface	$dispatcher
	 * @param string				$root_path
	 * @param string				$php_ext
	 * @param object|null			$search_backend_factory
	 */
	public function __construct(driver_interface $db, auth $auth, content_visibility $visibility, user $user, config $config, dispatcher_interface $dispatcher, $root_path, $php_ext, $search_backend_factory = null)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->visibility = $visibility;
		$this->user = $user;
		$this->config = $config;
		$this->dispatcher = $dispatcher;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->search_backend_factory = $search_backend_factory;
	}

	/**
	 * @param int	$topic_id
	 * @return int
	 */
	public function resolve_topic_forum_id($topic_id)
	{
		$sql = 'SELECT forum_id FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$forum_id = (int) $this->db->sql_fetchfield('forum_id');
		$this->db->sql_freeresult($result);

		if ($forum_id <= 0)
		{
			throw new api_exception('topic_not_found', 404);
		}

		return $forum_id;
	}

	/**
	 * @param int	$post_id
	 * @return int
	 */
	public function resolve_post_forum_id($post_id)
	{
		$sql = 'SELECT forum_id FROM ' . POSTS_TABLE . '
			WHERE post_id = ' . (int) $post_id;
		$result = $this->db->sql_query($sql);
		$forum_id = (int) $this->db->sql_fetchfield('forum_id');
		$this->db->sql_freeresult($result);

		if ($forum_id <= 0)
		{
			throw new api_exception('post_not_found', 404);
		}

		return $forum_id;
	}

	/**
	 * @return array
	 */
	public function get_readable_forum_ids()
	{
		$readable = array_keys($this->auth->acl_getf('f_read', true));

		return $this->exclude_password_protected($readable);
	}

	/**
	 * @return array
	 */
	public function list_forums()
	{
		$readable = array_keys($this->auth->acl_getf('f_read', true));

		if (empty($readable))
		{
			return [];
		}

		$sql = 'SELECT forum_id, parent_id, forum_name, forum_type, forum_password
			FROM ' . FORUMS_TABLE . '
			WHERE forum_type = ' . FORUM_POST . '
				AND ' . $this->db->sql_in_set('forum_id', $readable) . '
			ORDER BY left_id ASC';
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$forums = [];

		foreach ($rows as $row)
		{
			$locked_out = $row['forum_password'] !== '';

			$forums[] = [
				'forum_id'	=> (int) $row['forum_id'],
				'parent_id'	=> (int) $row['parent_id'],
				'name'		=> text::plain($row['forum_name']),
				'type'		=> (int) $row['forum_type'],
				'can_read'	=> !$locked_out,
				'can_post'	=> !$locked_out && $this->auth->acl_get('f_post', (int) $row['forum_id']),
				'can_reply'	=> !$locked_out && $this->auth->acl_get('f_reply', (int) $row['forum_id']),
			];
		}

		return $forums;
	}

	/**
	 * @param string	$event_id	an SSE id as emitted by list_new_activity(): "{time}-{t|p}-{id}", or a bare unix time
	 * @return array	['time' => int, 'kind' => 't'|'p'|'', 'id' => int]
	 */
	public static function parse_event_id($event_id)
	{
		if (preg_match('/^(\d+)-([tp])-(\d+)$/', (string) $event_id, $m))
		{
			return ['time' => (int) $m[1], 'kind' => $m[2], 'id' => (int) $m[3]];
		}

		return ['time' => (int) $event_id, 'kind' => '', 'id' => 0];
	}

	/**
	 * @param array		$forum_ids
	 * @param int		$since		unix time - events strictly after it are returned, plus same-second events after $after
	 * @param int		$limit
	 * @param array		$after		parse_event_id() cursor; kind '' means "everything strictly after $since"
	 * @return array	each event carries a unique, monotonic 'id' ("{time}-{t|p}-{id}") for Last-Event-ID resume
	 */
	public function list_new_activity(array $forum_ids, $since, $limit = 20, array $after = [])
	{
		if (empty($forum_ids))
		{
			return [];
		}

		$since = (int) $since;
		$limit = max(1, min(50, (int) $limit));
		$after_kind = (string) ($after['kind'] ?? '');
		$after_id = (int) ($after['id'] ?? 0);
		$time_op = $after_kind !== '' ? '>=' : '>';

		$sql = 'SELECT t.topic_id, t.forum_id, t.topic_title, t.topic_time, t.topic_poster, u.username AS poster_name
			FROM ' . TOPICS_TABLE . ' t
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = t.topic_poster)
			WHERE t.topic_time ' . $time_op . ' ' . (int) $since . '
				AND ' . $this->db->sql_in_set('t.forum_id', $forum_ids) . '
				AND t.topic_visibility = ' . ITEM_APPROVED . '
			ORDER BY t.topic_time ASC, t.topic_id ASC';
		$result = $this->db->sql_query_limit($sql, $limit);
		$topics = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$sql = 'SELECT p.post_id, p.topic_id, p.forum_id, p.post_time, p.poster_id, u.username AS poster_name
			FROM ' . POSTS_TABLE . ' p
			JOIN ' . TOPICS_TABLE . ' t ON (t.topic_id = p.topic_id)
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = p.poster_id)
			WHERE p.post_time ' . $time_op . ' ' . (int) $since . '
				AND p.post_id <> t.topic_first_post_id
				AND ' . $this->db->sql_in_set('p.forum_id', $forum_ids) . '
				AND p.post_visibility = ' . ITEM_APPROVED . '
			ORDER BY p.post_time ASC, p.post_id ASC';
		$result = $this->db->sql_query_limit($sql, $limit);
		$posts = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$events = [];

		foreach ($topics as $row)
		{
			$events[] = [
				'id'	=> (int) $row['topic_time'] . '-t-' . (int) $row['topic_id'],
				'event'	=> 'topic.created',
				'time'	=> (int) $row['topic_time'],
				'kind'	=> 't',
				'item'	=> (int) $row['topic_id'],
				'data'	=> [
					'topic_id'	=> (int) $row['topic_id'],
					'forum_id'	=> (int) $row['forum_id'],
					'title'		=> text::plain($row['topic_title']),
					'poster_id'	=> (int) $row['topic_poster'],
					'poster'	=> text::plain($row['poster_name']),
					'url'		=> generate_board_url() . '/viewtopic.php?t=' . (int) $row['topic_id'],
				],
			];
		}

		foreach ($posts as $row)
		{
			$events[] = [
				'id'	=> (int) $row['post_time'] . '-p-' . (int) $row['post_id'],
				'event'	=> 'post.created',
				'time'	=> (int) $row['post_time'],
				'kind'	=> 'p',
				'item'	=> (int) $row['post_id'],
				'data'	=> [
					'post_id'	=> (int) $row['post_id'],
					'topic_id'	=> (int) $row['topic_id'],
					'forum_id'	=> (int) $row['forum_id'],
					'poster_id'	=> (int) $row['poster_id'],
					'poster'	=> text::plain($row['poster_name']),
					'url'		=> generate_board_url() . '/viewtopic.php?t=' . (int) $row['topic_id'] . '&p=' . (int) $row['post_id'] . '#p' . (int) $row['post_id'],
				],
			];
		}

		$position = static function (array $event) {
			return [$event['time'], $event['kind'] === 't' ? 0 : 1, $event['item']];
		};

		if ($after_kind !== '')
		{
			$cursor = [$since, $after_kind === 't' ? 0 : 1, $after_id];
			$events = array_filter($events, static function (array $event) use ($position, $cursor) {
				return $position($event) > $cursor;
			});
		}

		usort($events, static function (array $a, array $b) use ($position) {
			return $position($a) <=> $position($b);
		});

		return array_values(array_map(static function (array $event) {
			unset($event['kind'], $event['item']);

			return $event;
		}, array_slice($events, 0, $limit)));
	}

	/**
	 * @param int	$forum_id
	 * @param int	$limit
	 * @param int	$start
	 * @return array
	 */
	public function list_topics($forum_id, $limit, $start)
	{
		$forum = $this->assert_forum_readable($forum_id);
		$limit = $this->clamp_limit($limit);
		$start = max(0, (int) $start);

		$where = 't.forum_id = ' . (int) $forum_id . ' AND ' . $this->visibility->get_visibility_sql('topic', (int) $forum_id, 't.');

		$sql = 'SELECT COUNT(*) AS total FROM ' . TOPICS_TABLE . ' t WHERE ' . $where;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		$sql = 'SELECT t.*, u.username AS poster_name, lu.username AS last_poster_name
			FROM ' . TOPICS_TABLE . ' t
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = t.topic_poster)
			LEFT JOIN ' . USERS_TABLE . ' lu ON (lu.user_id = t.topic_last_poster_id)
			WHERE ' . $where . '
			ORDER BY t.topic_last_post_time DESC';
		$result = $this->db->sql_query_limit($sql, $limit, $start);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return [
			'forum'			=> ['forum_id' => (int) $forum['forum_id'], 'name' => text::plain($forum['forum_name'])],
			'pagination'	=> ['limit' => $limit, 'start' => $start, 'total' => $total, 'count' => count($rows)],
			'topics'		=> array_map([$this, 'format_topic'], $rows),
		];
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	public function get_topic($topic_id)
	{
		$sql = 'SELECT t.*, u.username AS poster_name, lu.username AS last_poster_name
			FROM ' . TOPICS_TABLE . ' t
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = t.topic_poster)
			LEFT JOIN ' . USERS_TABLE . ' lu ON (lu.user_id = t.topic_last_poster_id)
			WHERE t.topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('topic_not_found', 404);
		}

		$this->assert_forum_readable((int) $row['forum_id']);

		if (!$this->visibility->is_visible('topic', (int) $row['forum_id'], $row))
		{
			throw new api_exception('topic_not_found', 404);
		}

		return $this->format_topic($row);
	}

	/**
	 * @param int	$topic_id
	 * @param int	$limit
	 * @param int	$start
	 * @return array
	 */
	public function list_posts($topic_id, $limit, $start)
	{
		$topic = $this->get_topic_row($topic_id);
		$forum_id = (int) $topic['forum_id'];
		$limit = $this->clamp_limit($limit);
		$start = max(0, (int) $start);

		$where = 'p.topic_id = ' . (int) $topic_id . ' AND ' . $this->visibility->get_visibility_sql('post', $forum_id, 'p.');

		$sql = 'SELECT COUNT(*) AS total FROM ' . POSTS_TABLE . ' p WHERE ' . $where;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		$sql = 'SELECT p.*, u.username AS poster_name
			FROM ' . POSTS_TABLE . ' p
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = p.poster_id)
			WHERE ' . $where . '
			ORDER BY p.post_time ASC';
		$result = $this->db->sql_query_limit($sql, $limit, $start);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return [
			'topic'			=> ['topic_id' => (int) $topic['topic_id'], 'forum_id' => $forum_id, 'title' => text::plain($topic['topic_title']), 'locked' => (int) $topic['topic_status'] === ITEM_LOCKED, 'first_post_id' => (int) $topic['topic_first_post_id']],
			'pagination'	=> ['limit' => $limit, 'start' => $start, 'total' => $total, 'count' => count($rows)],
			'posts'			=> array_map([$this, 'format_post'], $rows),
		];
	}

	/**
	 * @param int	$post_id
	 * @return array
	 */
	public function get_post($post_id)
	{
		$row = $this->get_post_row($post_id);
		$topic = $this->get_topic_row((int) $row['topic_id']);

		return [
			'post'		=> $this->format_post($row),
			'topic'		=> ['topic_id' => (int) $topic['topic_id'], 'forum_id' => (int) $topic['forum_id'], 'title' => text::plain($topic['topic_title']), 'locked' => (int) $topic['topic_status'] === ITEM_LOCKED, 'first_post_id' => (int) $topic['topic_first_post_id']],
			'forum'		=> ['forum_id' => (int) $topic['forum_id']],
		];
	}

	/**
	 * @param array	$ids
	 * @param array	$restrict_to_forums	Credential's forum allowlist, empty = no extra restriction
	 * @return array
	 */
	public function get_topics_by_ids(array $ids, array $restrict_to_forums = [])
	{
		$ids = $this->filter_bulk_ids($ids);

		if (empty($ids))
		{
			return [];
		}

		$readable = $this->get_readable_forum_ids();

		if (!empty($restrict_to_forums))
		{
			$readable = array_intersect($readable, $restrict_to_forums);
		}

		if (empty($readable))
		{
			return [];
		}

		$sql = 'SELECT t.*, u.username AS poster_name, lu.username AS last_poster_name
			FROM ' . TOPICS_TABLE . ' t
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = t.topic_poster)
			LEFT JOIN ' . USERS_TABLE . ' lu ON (lu.user_id = t.topic_last_poster_id)
			WHERE ' . $this->db->sql_in_set('t.topic_id', $ids) . '
				AND ' . $this->db->sql_in_set('t.forum_id', $readable);
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$by_id = [];

		foreach ($rows as $row)
		{
			if ($this->visibility->is_visible('topic', (int) $row['forum_id'], $row))
			{
				$by_id[(int) $row['topic_id']] = $this->format_topic($row);
			}
		}

		return $this->reorder_by_ids($by_id, $ids);
	}

	/**
	 * @param array	$ids
	 * @param array	$restrict_to_forums	Credential's forum allowlist, empty = no extra restriction
	 * @return array
	 */
	public function get_posts_by_ids(array $ids, array $restrict_to_forums = [])
	{
		$ids = $this->filter_bulk_ids($ids);

		if (empty($ids))
		{
			return [];
		}

		$readable = $this->get_readable_forum_ids();

		if (!empty($restrict_to_forums))
		{
			$readable = array_intersect($readable, $restrict_to_forums);
		}

		if (empty($readable))
		{
			return [];
		}

		$sql = 'SELECT p.*, u.username AS poster_name
			FROM ' . POSTS_TABLE . ' p
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = p.poster_id)
			WHERE ' . $this->db->sql_in_set('p.post_id', $ids) . '
				AND ' . $this->db->sql_in_set('p.forum_id', $readable);
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$by_id = [];

		foreach ($rows as $row)
		{
			if ($this->visibility->is_visible('post', (int) $row['forum_id'], $row))
			{
				$by_id[(int) $row['post_id']] = $this->format_post($row);
			}
		}

		return $this->reorder_by_ids($by_id, $ids);
	}

	/**
	 * @param array	$ids
	 * @return array
	 */
	protected function filter_bulk_ids(array $ids)
	{
		$ids = array_map('intval', $ids);
		$ids = array_filter($ids, static function ($id) {
			return $id > 0;
		});
		$ids = array_values(array_unique($ids));

		return array_slice($ids, 0, self::MAX_LIMIT);
	}

	/**
	 * @param array	$by_id	keyed by id
	 * @param array	$ids	the caller's originally requested order
	 * @return array
	 */
	protected function reorder_by_ids(array $by_id, array $ids)
	{
		$ordered = [];

		foreach ($ids as $id)
		{
			if (isset($by_id[$id]))
			{
				$ordered[] = $by_id[$id];
			}
		}

		return $ordered;
	}

	/**
	 * @param string	$type		'posts' or 'topics'
	 * @param string	$query
	 * @param int		$forum_id
	 * @param string	$author
	 * @param int		$limit
	 * @param int		$start
	 * @param array		$restrict_to_forums	Credential's forum allowlist, empty = no extra restriction
	 * @return array	results from the board's configured search backend (the same index search.php uses), never a LIKE over post_text
	 */
	public function search($type, $query, $forum_id, $author, $limit, $start, array $restrict_to_forums = [])
	{
		if (!(int) $this->config['load_search'] && !$this->auth->acl_get('a_search'))
		{
			throw new api_exception('search_disabled', 403);
		}

		if (!$this->auth->acl_get('u_search') || !$this->auth->acl_getf_global('f_search'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$type = $type === 'topics' ? 'topics' : 'posts';
		$query = trim((string) $query);

		if (utf8_strlen($query) < 3)
		{
			throw new api_exception('search_query_too_short', 400);
		}

		$readable = array_values(array_intersect($this->get_readable_forum_ids(), array_keys($this->auth->acl_getf('f_search', true))));

		if (!empty($restrict_to_forums))
		{
			$readable = array_intersect($readable, $restrict_to_forums);
		}

		if ($forum_id > 0)
		{
			$readable = array_intersect($readable, [(int) $forum_id]);
		}

		$limit = $this->clamp_limit($limit);
		$start = max(0, (int) $start);
		$empty = ['type' => $type, 'query' => text::plain($query), 'pagination' => ['limit' => $limit, 'start' => $start, 'total' => 0, 'count' => 0], 'results' => []];

		if (empty($readable))
		{
			return $empty;
		}

		$author_ids = [];

		if ((string) $author !== '')
		{
			$author_ids = $this->find_author_ids($author);

			if (empty($author_ids))
			{
				return $empty;
			}
		}

		$search = $this->create_search_backend();
		$keywords = $query;

		if (!$search->split_keywords($keywords, 'all') || (string) $search->get_search_query() === '')
		{
			throw new api_exception('search_no_keywords', 400);
		}

		$ex_fid_ary = $this->excluded_forum_ids(array_values($readable));
		$sort_by_sql = ['t' => $type === 'posts' ? 'p.post_time' : 't.topic_last_post_time'];
		$post_visibility = $this->visibility->get_global_visibility_sql('post', $ex_fid_ary, 'p.');
		$id_ary = [];
		$page_start = $start;

		$total = (int) $search->keyword_search($type, 'all', 'all', $sort_by_sql, 't', 'd', 0, $ex_fid_ary, $post_visibility, 0, $author_ids, '', $id_ary, $page_start, $limit);
		$id_ary = array_map('intval', array_slice((array) $id_ary, 0, $limit));

		$results = $type === 'posts' ? $this->load_search_posts($id_ary) : $this->load_search_topics($id_ary);

		return ['type' => $type, 'query' => text::plain($query), 'pagination' => ['limit' => $limit, 'start' => (int) $page_start, 'total' => $total, 'count' => count($results)], 'results' => $results];
	}

	/**
	 * @return object	a search backend exposing split_keywords(), get_search_query() and keyword_search() - 4.0.x via the factory, 3.3.x via $config['search_type']
	 */
	protected function create_search_backend()
	{
		if ($this->search_backend_factory !== null)
		{
			try
			{
				return $this->search_backend_factory->get_active();
			}
			catch (\Exception $e)
			{
				throw new api_exception('search_unavailable', 503);
			}
		}

		$search_type = (string) $this->config['search_type'];

		if ($search_type === '' || !class_exists($search_type))
		{
			throw new api_exception('search_unavailable', 503);
		}

		$error = false;
		$search = new $search_type($error, $this->root_path, $this->php_ext, $this->auth, $this->config, $this->db, $this->user, $this->dispatcher);

		if ($error)
		{
			throw new api_exception('search_unavailable', 503);
		}

		return $search;
	}

	/**
	 * @param string	$author
	 * @return array	user ids whose username contains $author
	 */
	protected function find_author_ids($author)
	{
		$any_char = $this->db->get_any_char();

		$sql = 'SELECT user_id FROM ' . USERS_TABLE . '
			WHERE username_clean ' . $this->db->sql_like_expression($any_char . utf8_clean_string((string) $author) . $any_char) . '
				AND user_type <> ' . USER_IGNORE;
		$result = $this->db->sql_query_limit($sql, 100);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_map('intval', array_column($rows, 'user_id'));
	}

	/**
	 * @param array	$searchable_forum_ids
	 * @return array	every other forum id, i.e. the ex_fid_ary the search backends expect
	 */
	protected function excluded_forum_ids(array $searchable_forum_ids)
	{
		$sql = 'SELECT forum_id FROM ' . FORUMS_TABLE . '
			WHERE ' . $this->db->sql_in_set('forum_id', $searchable_forum_ids, true);
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_map('intval', array_column($rows, 'forum_id'));
	}

	/**
	 * @param array	$post_ids	in result order
	 * @return array
	 */
	protected function load_search_posts(array $post_ids)
	{
		if (empty($post_ids))
		{
			return [];
		}

		$sql = 'SELECT p.post_id, p.topic_id, p.forum_id, p.post_time, p.post_text, u.username AS poster_name
			FROM ' . POSTS_TABLE . ' p
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = p.poster_id)
			WHERE ' . $this->db->sql_in_set('p.post_id', $post_ids);
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$by_id = [];

		foreach ($rows as $row)
		{
			$snippet = strip_tags(str_replace(['[', ']'], ' ', (string) $row['post_text']));
			$snippet = trim(preg_replace('/\s+/', ' ', $snippet));

			$by_id[(int) $row['post_id']] = [
				'post_id'	=> (int) $row['post_id'],
				'topic_id'	=> (int) $row['topic_id'],
				'forum_id'	=> (int) $row['forum_id'],
				'poster'	=> text::plain($row['poster_name']),
				'post_time'	=> (int) $row['post_time'],
				'snippet'	=> utf8_substr(text::plain($snippet), 0, 200),
			];
		}

		return $this->reorder_by_ids($by_id, $post_ids);
	}

	/**
	 * @param array	$topic_ids	in result order
	 * @return array
	 */
	protected function load_search_topics(array $topic_ids)
	{
		if (empty($topic_ids))
		{
			return [];
		}

		$sql = 'SELECT t.topic_id, t.forum_id, t.topic_title, t.topic_last_post_time, u.username AS poster_name
			FROM ' . TOPICS_TABLE . ' t
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = t.topic_poster)
			WHERE ' . $this->db->sql_in_set('t.topic_id', $topic_ids);
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$by_id = [];

		foreach ($rows as $row)
		{
			$by_id[(int) $row['topic_id']] = [
				'topic_id'			=> (int) $row['topic_id'],
				'forum_id'			=> (int) $row['forum_id'],
				'title'				=> text::plain($row['topic_title']),
				'poster'			=> text::plain($row['poster_name']),
				'last_post_time'	=> (int) $row['topic_last_post_time'],
			];
		}

		return $this->reorder_by_ids($by_id, $topic_ids);
	}

	/**
	 * @param array	$forum_ids
	 * @return array
	 */
	protected function exclude_password_protected(array $forum_ids)
	{
		if (empty($forum_ids))
		{
			return $forum_ids;
		}

		$sql = 'SELECT forum_id FROM ' . FORUMS_TABLE . '
			WHERE ' . $this->db->sql_in_set('forum_id', $forum_ids) . "
				AND forum_password <> ''";
		$result = $this->db->sql_query($sql);
		$locked = array_map('intval', array_column($this->db->sql_fetchrowset($result), 'forum_id'));
		$this->db->sql_freeresult($result);

		return array_values(array_diff($forum_ids, $locked));
	}

	/**
	 * @param int	$forum_id
	 * @return array	the forum row - throws unless the forum is postable, f_read is granted and no forum password is set
	 */
	public function assert_forum_readable($forum_id)
	{
		$sql = 'SELECT forum_id, forum_name, forum_type, forum_password
			FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . (int) $forum_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || (int) $row['forum_type'] !== FORUM_POST)
		{
			throw new api_exception('forum_not_found', 404);
		}

		if (!$this->auth->acl_get('f_read', (int) $forum_id))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		if ($row['forum_password'] !== '')
		{
			throw new api_exception('forum_password_required', 403);
		}

		return $row;
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function get_topic_row($topic_id)
	{
		$sql = 'SELECT * FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('topic_not_found', 404);
		}

		$this->assert_forum_readable((int) $row['forum_id']);

		if (!$this->visibility->is_visible('topic', (int) $row['forum_id'], $row))
		{
			throw new api_exception('topic_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param int	$post_id
	 * @return array
	 */
	protected function get_post_row($post_id)
	{
		$sql = 'SELECT p.*, u.username AS poster_name
			FROM ' . POSTS_TABLE . ' p
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = p.poster_id)
			WHERE p.post_id = ' . (int) $post_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('post_not_found', 404);
		}

		$this->assert_forum_readable((int) $row['forum_id']);

		if (!$this->visibility->is_visible('post', (int) $row['forum_id'], $row))
		{
			throw new api_exception('post_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param array	$row
	 * @return array
	 */
	protected function format_topic(array $row)
	{
		$type = 'normal';

		if ((int) $row['topic_type'] === POST_GLOBAL)
		{
			$type = 'global';
		}
		else if ((int) $row['topic_type'] === POST_ANNOUNCE)
		{
			$type = 'announcement';
		}
		else if ((int) $row['topic_type'] === POST_STICKY)
		{
			$type = 'sticky';
		}

		return [
			'topic_id'			=> (int) $row['topic_id'],
			'forum_id'			=> (int) $row['forum_id'],
			'title'				=> text::plain($row['topic_title']),
			'type'				=> $type,
			'poster_id'			=> (int) $row['topic_poster'],
			'poster'			=> text::plain($row['poster_name']),
			'replies'			=> max(0, (int) $row['topic_posts_approved'] - 1),
			'views'				=> (int) $row['topic_views'],
			'first_post_time'	=> (int) $row['topic_time'],
			'last_post_time'	=> (int) $row['topic_last_post_time'],
			'last_poster_id'	=> (int) $row['topic_last_poster_id'],
			'last_poster'		=> text::plain($row['last_poster_name']),
			'locked'			=> (int) $row['topic_status'] === ITEM_LOCKED,
			'url'				=> generate_board_url() . '/viewtopic.php?t=' . (int) $row['topic_id'],
			'poll'				=> $row['poll_title'] !== '' ? $this->format_poll($row) : null,
		];
	}

	/**
	 * @param array	$row	a TOPICS_TABLE row (SELECT t.*)
	 * @return array
	 */
	protected function format_poll(array $row)
	{
		$topic_id = (int) $row['topic_id'];

		$sql = 'SELECT poll_option_id, poll_option_text, poll_option_total
			FROM ' . POLL_OPTIONS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id . '
			ORDER BY poll_option_id ASC';
		$result = $this->db->sql_query($sql);
		$options = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$sql = 'SELECT bbcode_uid, bbcode_bitfield FROM ' . POSTS_TABLE . '
			WHERE post_id = ' . (int) $row['topic_first_post_id'];
		$result = $this->db->sql_query($sql);
		$first_post = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		$bbcode_uid = $first_post ? $first_post['bbcode_uid'] : '';
		$bbcode_bitfield = $first_post ? $first_post['bbcode_bitfield'] : '';
		$parse_flags = ((int) $bbcode_bitfield ? OPTION_FLAG_BBCODE : 0) | OPTION_FLAG_SMILIES;

		$voted_ids = [];

		if ($this->user->data['is_registered'])
		{
			$sql = 'SELECT poll_option_id FROM ' . POLL_VOTES_TABLE . '
				WHERE topic_id = ' . (int) $topic_id . '
					AND vote_user_id = ' . (int) $this->user->data['user_id'];
			$result = $this->db->sql_query($sql);

			while ($vote_row = $this->db->sql_fetchrow($result))
			{
				$voted_ids[] = (int) $vote_row['poll_option_id'];
			}
			$this->db->sql_freeresult($result);
		}

		return [
			'question'			=> generate_text_for_display($row['poll_title'], $bbcode_uid, $bbcode_bitfield, $parse_flags, true),
			'options'			=> array_map(function ($option) use ($bbcode_uid, $bbcode_bitfield, $parse_flags) {
				return [
					'option_id'	=> (int) $option['poll_option_id'],
					'text'		=> generate_text_for_display($option['poll_option_text'], $bbcode_uid, $bbcode_bitfield, $parse_flags, true),
					'votes'		=> (int) $option['poll_option_total'],
				];
			}, $options),
			'max_options'		=> (int) $row['poll_max_options'],
			'vote_change'		=> (bool) $row['poll_vote_change'],
			'expires'			=> (int) $row['poll_length'] > 0 ? (int) $row['poll_start'] + (int) $row['poll_length'] : null,
			'your_votes'		=> $voted_ids,
		];
	}

	/**
	 * @param array	$row
	 * @return array
	 */
	protected function format_post(array $row)
	{
		$parse_flags = ((int) $row['bbcode_bitfield'] ? OPTION_FLAG_BBCODE : 0) | OPTION_FLAG_SMILIES;

		return [
			'post_id'			=> (int) $row['post_id'],
			'poster_id'			=> (int) $row['poster_id'],
			'poster'			=> text::plain($row['poster_name']),
			'post_time'			=> (int) $row['post_time'],
			'edit_count'		=> (int) $row['post_edit_count'],
			'edit_time'			=> (int) $row['post_edit_time'],
			'subject'			=> text::plain($row['post_subject']),
			'content_html'		=> generate_text_for_display($row['post_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $parse_flags, true),
			'content_bbcode'	=> generate_text_for_edit($row['post_text'], $row['bbcode_uid'], $parse_flags)['text'],
			'url'				=> generate_board_url() . '/viewtopic.php?t=' . (int) $row['topic_id'] . '&p=' . (int) $row['post_id'] . '#p' . (int) $row['post_id'],
			'attachments'		=> (int) $row['post_attachment'] ? $this->list_attachments((int) $row['post_id']) : [],
			'approved'			=> (int) $row['post_visibility'] === ITEM_APPROVED,
		];
	}

	/**
	 * @param int	$post_id
	 * @return array
	 */
	protected function list_attachments($post_id)
	{
		$sql = 'SELECT attach_id, real_filename, filesize, mimetype
			FROM ' . ATTACHMENTS_TABLE . '
			WHERE post_msg_id = ' . (int) $post_id . '
				AND is_orphan = 0
			ORDER BY attach_id ASC';
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_map(static function ($row) {
			return [
				'attachment_id'	=> (int) $row['attach_id'],
				'filename'		=> text::plain($row['real_filename']),
				'filesize'		=> (int) $row['filesize'],
				'mimetype'		=> $row['mimetype'],
			];
		}, $rows);
	}

	/**
	 * @param int	$limit
	 * @return int
	 */
	protected function clamp_limit($limit)
	{
		$limit = (int) $limit;

		if ($limit <= 0)
		{
			return self::DEFAULT_LIMIT;
		}

		return min(self::MAX_LIMIT, $limit);
	}
}
