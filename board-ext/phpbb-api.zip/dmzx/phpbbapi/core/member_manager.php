<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\db\driver\driver_interface;
use phpbb\passwords\manager as passwords_manager;
use phpbb\user;

class member_manager
{
	const MAX_LIMIT = 100;
	const DEFAULT_LIMIT = 25;

	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var config */
	protected $config;

	/** @var passwords_manager */
	protected $passwords_manager;

	/** @var user */
	protected $user;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var object|null	\phpbb\ban\manager on 4.0.x, null on 3.3.x */
	protected $ban_manager;

	/**
	 * @param driver_interface		$db
	 * @param auth					$auth
	 * @param config				$config
	 * @param passwords_manager		$passwords_manager
	 * @param user					$user
	 * @param string				$root_path
	 * @param string				$php_ext
	 * @param object|null			$ban_manager
	 */
	public function __construct(driver_interface $db, auth $auth, config $config, passwords_manager $passwords_manager, user $user, $root_path, $php_ext, $ban_manager = null)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->config = $config;
		$this->passwords_manager = $passwords_manager;
		$this->user = $user;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
		$this->ban_manager = $ban_manager;
	}

	/**
	 * @param string	$query
	 * @param int		$limit
	 * @param int		$start
	 * @return array
	 */
	public function list_members($query, $limit, $start)
	{
		$this->assert_can_view_profiles();

		$limit = $this->clamp_limit($limit);
		$start = max(0, (int) $start);
		$query = trim((string) $query);

		$sql_where = 'user_type IN (' . USER_NORMAL . ', ' . USER_FOUNDER . ')';

		if ($query !== '')
		{
			$any_char = $this->db->get_any_char();
			$sql_where .= ' AND username_clean ' . $this->db->sql_like_expression($any_char . utf8_clean_string($query) . $any_char);
		}

		$sql = 'SELECT COUNT(*) AS total FROM ' . USERS_TABLE . ' WHERE ' . $sql_where;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		$sql = 'SELECT user_id, username, user_regdate, user_posts, user_colour
			FROM ' . USERS_TABLE . '
			WHERE ' . $sql_where . '
			ORDER BY username_clean ASC';
		$result = $this->db->sql_query_limit($sql, $limit, $start);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return [
			'pagination'	=> ['limit' => $limit, 'start' => $start, 'total' => $total, 'count' => count($rows)],
			'members'		=> array_map([$this, 'format_member'], $rows),
		];
	}

	/**
	 * @param int	$user_id
	 * @return array
	 */
	public function get_member($user_id)
	{
		$this->assert_can_view_profiles();

		return $this->format_member($this->load_user_row($user_id));
	}

	/**
	 * @param int	$user_id
	 * @return array
	 */
	public function get_member_groups($user_id)
	{
		$this->assert_can_view_profiles();

		$this->load_user_row($user_id);

		$can_see_hidden = (int) $user_id === (int) $this->user->data['user_id'] || $this->auth->acl_gets('a_group', 'a_groupadd', 'a_groupdel');

		$sql = 'SELECT g.group_id, g.group_name, ug.group_leader
			FROM ' . USER_GROUP_TABLE . ' ug
			INNER JOIN ' . GROUPS_TABLE . ' g ON (g.group_id = ug.group_id)
			WHERE ug.user_id = ' . (int) $user_id . '
				AND ug.user_pending = 0' . ($can_see_hidden ? '' : '
				AND g.group_type <> ' . GROUP_HIDDEN) . '
			ORDER BY g.group_name ASC';
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_map(static function ($row) {
			return [
				'group_id'		=> (int) $row['group_id'],
				'name'			=> text::plain($row['group_name']),
				'is_leader'		=> (bool) $row['group_leader'],
			];
		}, $rows);
	}

	/**
	 * @param int	$user_id
	 * @param int	$group_id
	 * @return void
	 */
	public function add_to_group($user_id, $group_id)
	{
		$this->assert_can_manage_groups();

		$this->load_user_row($user_id);
		$this->load_group_row($group_id);

		$this->include_user_functions();

		$result = group_user_add((int) $group_id, [(int) $user_id], false);

		if ($result !== false)
		{
			throw new api_exception('group_action_failed', 400);
		}
	}

	/**
	 * @param int	$user_id
	 * @param int	$group_id
	 * @return void
	 */
	public function remove_from_group($user_id, $group_id)
	{
		$this->assert_can_manage_groups();

		$this->load_user_row($user_id);
		$this->load_group_row($group_id);

		$this->include_user_functions();

		$result = group_user_del((int) $group_id, [(int) $user_id], false);

		if ($result !== false)
		{
			throw new api_exception('group_action_failed', 400);
		}
	}

	/**
	 * @param string	$username
	 * @param string	$password
	 * @param string	$email
	 * @return array
	 */
	public function register_member($username, $password, $email)
	{
		$this->assert_can_add_users();

		$this->include_user_functions();

		$data = [
			'username'		=> (string) $username,
			'new_password'	=> (string) $password,
			'email'			=> strtolower((string) $email),
		];

		$error = validate_data($data, [
			'username'		=> [
				['string', false, (int) $this->config['min_name_chars'], (int) $this->config['max_name_chars']],
				['username', ''],
			],
			'new_password'	=> [
				['string', false, (int) $this->config['min_pass_chars'], 0],
				['password'],
			],
			'email'			=> [
				['string', false, 6, 60],
				['user_email'],
			],
		]);

		if (!empty($error))
		{
			throw new api_exception(strtolower((string) $error[0]), 400);
		}

		$sql = 'SELECT group_id FROM ' . GROUPS_TABLE . "
			WHERE group_name = 'REGISTERED'
				AND group_type = " . GROUP_SPECIAL;
		$result = $this->db->sql_query($sql);
		$group_id = (int) $this->db->sql_fetchfield('group_id');
		$this->db->sql_freeresult($result);

		if (!$group_id)
		{
			throw new api_exception('no_group', 500);
		}

		$user_row = [
			'username'			=> $data['username'],
			'user_password'		=> $this->passwords_manager->hash($data['new_password']),
			'user_email'		=> $data['email'],
			'group_id'			=> $group_id,
			'user_type'			=> USER_NORMAL,
			'user_timezone'		=> $this->config['board_timezone'],
			'user_lang'			=> $this->config['default_lang'],
			'user_ip'			=> '',
		];

		$user_id = user_add($user_row);

		if (!$user_id)
		{
			throw new api_exception('registration_failed', 400);
		}

		return ['user_id' => (int) $user_id, 'username' => text::plain($data['username'])];
	}

	/**
	 * @param int		$user_id
	 * @param int		$length_minutes		0 = permanent
	 * @param string	$reason
	 * @param string	$display_reason
	 * @return void
	 */
	public function ban_member($user_id, $length_minutes, $reason, $display_reason)
	{
		if (!$this->auth->acl_get('a_ban'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$target = $this->load_user_row($user_id);

		if ((int) $target['user_id'] === (int) $this->user->data['user_id'])
		{
			throw new api_exception('cannot_ban_self', 403);
		}

		if ((int) $target['user_type'] === USER_FOUNDER)
		{
			throw new api_exception('cannot_ban_founder', 403);
		}

		$reason = utf8_encode_ucr((string) $reason);
		$display_reason = utf8_encode_ucr((string) $display_reason);

		if ($this->ban_manager !== null)
		{
			$start = new \DateTime();
			$end = new \DateTime();
			$end->setTimestamp((int) $length_minutes > 0 ? time() + ((int) $length_minutes * 60) : 0);

			$this->ban_manager->ban('user', [$target['username']], $start, $end, (string) $reason, (string) $display_reason);

			return;
		}

		$this->include_user_functions();

		user_ban('user', [$target['username']], (int) $length_minutes, '', false, (string) $reason, (string) $display_reason);
	}

	/**
	 * @param int	$user_id
	 * @return void
	 */
	public function unban_member($user_id)
	{
		if (!$this->auth->acl_get('a_ban'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$ban_ids = $this->find_ban_ids($user_id);

		if (empty($ban_ids))
		{
			throw new api_exception('member_not_banned', 400);
		}

		if ($this->ban_manager !== null)
		{
			$this->ban_manager->unban('user', $ban_ids);

			return;
		}

		$this->include_user_functions();

		user_unban('user', $ban_ids);
	}

	/**
	 * @param int		$user_id
	 * @param string	$mode	'remove' deletes the member's posts too; anything else (including omitted) retains them
	 * @return void
	 */
	public function delete_member($user_id, $mode)
	{
		if (!$this->auth->acl_get('a_userdel'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$target = $this->load_user_row($user_id);

		if ((int) $target['user_id'] === (int) $this->user->data['user_id'])
		{
			throw new api_exception('cannot_delete_self', 403);
		}

		if ((int) $target['user_type'] === USER_FOUNDER)
		{
			throw new api_exception('cannot_delete_founder', 403);
		}

		$this->include_user_functions();

		user_delete(((string) $mode === 'remove') ? 'remove' : 'retain', (int) $target['user_id'], true);
	}

	/**
	 * @param int	$user_id
	 * @return array
	 */
	protected function find_ban_ids($user_id)
	{
		if (defined('BANS_TABLE'))
		{
			$sql = 'SELECT ban_id FROM ' . BANS_TABLE . "
				WHERE ban_mode = 'user'
					AND ban_userid = " . (int) $user_id;
		}
		else
		{
			$sql = 'SELECT ban_id FROM ' . BANLIST_TABLE . '
				WHERE ban_userid = ' . (int) $user_id;
		}

		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_map('intval', array_column($rows, 'ban_id'));
	}

	/**
	 * @param int	$user_id
	 * @return array
	 */
	protected function load_user_row($user_id)
	{
		$sql = 'SELECT user_id, username, user_regdate, user_posts, user_colour, user_type
			FROM ' . USERS_TABLE . '
			WHERE user_id = ' . (int) $user_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || in_array((int) $row['user_type'], [USER_INACTIVE, USER_IGNORE], true))
		{
			throw new api_exception('member_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param int	$group_id
	 * @return array
	 */
	protected function load_group_row($group_id)
	{
		$sql = 'SELECT group_id, group_name, group_founder_manage FROM ' . GROUPS_TABLE . '
			WHERE group_id = ' . (int) $group_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('group_not_found', 404);
		}

		if ((int) $row['group_founder_manage'] && (int) $this->user->data['user_type'] !== USER_FOUNDER)
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		return $row;
	}

	/**
	 * @param array	$row
	 * @return array
	 */
	protected function format_member(array $row)
	{
		return [
			'user_id'		=> (int) $row['user_id'],
			'username'		=> text::plain($row['username']),
			'regdate'		=> (int) $row['user_regdate'],
			'posts'			=> (int) $row['user_posts'],
			'colour'		=> $row['user_colour'],
		];
	}

	/**
	 * @return void
	 */
	protected function assert_can_view_profiles()
	{
		if (!$this->auth->acl_get('u_viewprofile'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}
	}

	/**
	 * @return void
	 */
	protected function assert_can_manage_groups()
	{
		if (!$this->auth->acl_get('a_group'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}
	}

	/**
	 * @return void
	 */
	protected function assert_can_add_users()
	{
		if (!$this->auth->acl_get('a_user'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}
	}

	/**
	 * @param int	$limit
	 * @return int
	 */
	protected function clamp_limit($limit)
	{
		$limit = (int) $limit;

		if ($limit <= 0)
		{
			return self::DEFAULT_LIMIT;
		}

		return min(self::MAX_LIMIT, $limit);
	}

	/**
	 * @return void
	 */
	protected function include_user_functions()
	{
		if (!function_exists('validate_data'))
		{
			include($this->root_path . 'includes/functions_user.' . $this->php_ext);
		}
	}
}
