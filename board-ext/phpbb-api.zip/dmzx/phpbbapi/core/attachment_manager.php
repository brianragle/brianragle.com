<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\attachment\manager as core_attachment_manager;
use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\content_visibility;
use phpbb\db\driver\driver_interface;
use phpbb\request\request;
use phpbb\user;

class attachment_manager
{
	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var config */
	protected $config;

	/** @var content_visibility */
	protected $visibility;

	/** @var core_attachment_manager */
	protected $attachments;

	/** @var request */
	protected $request;

	/** @var user */
	protected $user;

	/** @var string */
	protected $root_path;

	/** @var object|null	\phpbb\storage\storage (storage.attachment) on 4.0.x, null on 3.3.x */
	protected $storage;

	/**
	 * @param driver_interface			$db
	 * @param auth						$auth
	 * @param config					$config
	 * @param content_visibility		$visibility
	 * @param core_attachment_manager	$attachments
	 * @param request					$request
	 * @param user						$user
	 * @param string					$root_path
	 * @param object|null				$storage
	 */
	public function __construct(driver_interface $db, auth $auth, config $config, content_visibility $visibility, core_attachment_manager $attachments, request $request, user $user, $root_path, $storage = null)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->config = $config;
		$this->visibility = $visibility;
		$this->attachments = $attachments;
		$this->request = $request;
		$this->user = $user;
		$this->root_path = $root_path;
		$this->storage = $storage;
	}

	/**
	 * @param string	$form_field
	 * @param int		$forum_id
	 * @param int		$current_count	attachments already collected for this post (uploaded in this request plus existing ones)
	 * @return array|null	one attachment_data entry for post_composer's submit_post()
	 *						call, or null if the request carried no file for this field
	 */
	public function upload($form_field, $forum_id, $current_count = 0)
	{
		$file = $this->request->file($form_field);

		if (!isset($file['name']) || $file['name'] === 'none' || $file['name'] === '')
		{
			return null;
		}

		if (!(int) $this->config['allow_attachments'])
		{
			throw new api_exception('attachments_disabled', 403);
		}

		if (!$this->auth->acl_get('u_attach') || !$this->auth->acl_get('f_attach', (int) $forum_id))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		if ((int) $this->config['max_attachments'] && (int) $current_count >= (int) $this->config['max_attachments'] && !$this->auth->acl_get('a_') && !$this->auth->acl_get('m_', (int) $forum_id))
		{
			throw new api_exception('too_many_attachments', 400);
		}

		$filedata = $this->attachments->upload($form_field, (int) $forum_id, false, '', false);

		if (empty($filedata['post_attach']))
		{
			throw new api_exception('attachment_rejected', 400);
		}

		$sql_ary = [
			'physical_filename'	=> $filedata['physical_filename'],
			'attach_comment'		=> '',
			'real_filename'			=> $filedata['real_filename'],
			'extension'				=> $filedata['extension'],
			'mimetype'				=> $filedata['mimetype'],
			'filesize'				=> (int) $filedata['filesize'],
			'filetime'				=> (int) $filedata['filetime'],
			'thumbnail'				=> (int) $filedata['thumbnail'],
			'is_orphan'				=> 1,
			'in_message'			=> 0,
			'poster_id'				=> (int) $this->user->data['user_id'],
		];

		$this->db->sql_query('INSERT INTO ' . ATTACHMENTS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary));

		return [
			'attach_id'			=> (int) $this->db->sql_nextid(),
			'is_orphan'			=> 1,
			'attach_comment'	=> '',
		];
	}

	/**
	 * @param int	$attachment_id
	 * @return array	the attachment row
	 */
	public function load_for_download($attachment_id)
	{
		if (!(int) $this->config['allow_attachments'])
		{
			throw new api_exception('attachments_disabled', 403);
		}

		$sql = 'SELECT * FROM ' . ATTACHMENTS_TABLE . '
			WHERE attach_id = ' . (int) $attachment_id . '
				AND is_orphan = 0
				AND in_message = 0';
		$result = $this->db->sql_query($sql);
		$attachment = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$attachment)
		{
			throw new api_exception('attachment_not_found', 404);
		}

		$sql = 'SELECT * FROM ' . POSTS_TABLE . '
			WHERE post_id = ' . (int) $attachment['post_msg_id'];
		$result = $this->db->sql_query($sql);
		$post = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$post)
		{
			throw new api_exception('attachment_not_found', 404);
		}

		$sql = 'SELECT * FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $post['topic_id'];
		$result = $this->db->sql_query($sql);
		$topic = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		$forum_id = (int) $post['forum_id'];

		if (!$topic || !$this->visibility->is_visible('topic', $forum_id, $topic) || !$this->visibility->is_visible('post', $forum_id, $post))
		{
			throw new api_exception('attachment_not_found', 404);
		}

		if (!$this->auth->acl_get('u_download') || !$this->auth->acl_get('f_download', $forum_id))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$extensions = [];

		if (!extension_allowed($forum_id, $attachment['extension'], $extensions))
		{
			throw new api_exception('attachment_not_found', 404);
		}

		$this->db->sql_query('UPDATE ' . ATTACHMENTS_TABLE . '
			SET download_count = download_count + 1
			WHERE attach_id = ' . (int) $attachment['attach_id']);

		return $attachment;
	}

	/**
	 * @param array	$attachment
	 * @return resource
	 */
	public function open_stream(array $attachment)
	{
		if ($this->storage !== null)
		{
			return $this->storage->read($attachment['physical_filename']);
		}

		$path = $this->root_path . $this->config['upload_path'] . '/' . utf8_basename($attachment['physical_filename']);
		$handle = @fopen($path, 'rb');

		if ($handle === false)
		{
			throw new api_exception('attachment_not_found', 404);
		}

		return $handle;
	}
}
