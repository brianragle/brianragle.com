<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\content_visibility;
use phpbb\db\driver\driver_interface;
use phpbb\event\dispatcher_interface;
use phpbb\user;

class post_composer
{
	const MAX_TITLE_LENGTH = 255;

	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var config */
	protected $config;

	/** @var user */
	protected $user;

	/** @var content_visibility */
	protected $visibility;

	/** @var dispatcher_interface */
	protected $dispatcher;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/**
	 * @param driver_interface		$db
	 * @param auth					$auth
	 * @param config				$config
	 * @param user					$user
	 * @param content_visibility	$visibility
	 * @param dispatcher_interface	$dispatcher
	 * @param string				$root_path
	 * @param string				$php_ext
	 */
	public function __construct(driver_interface $db, auth $auth, config $config, user $user, content_visibility $visibility, dispatcher_interface $dispatcher, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->config = $config;
		$this->user = $user;
		$this->visibility = $visibility;
		$this->dispatcher = $dispatcher;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	/**
	 * @param int		$forum_id
	 * @param string	$title
	 * @param string	$content
	 * @param string	$type				'normal', 'sticky' or 'announcement'
	 * @param array		$attachment_data	zero or more entries built by attachment_manager::upload()
	 * @param array		$poll				empty for no poll, else ['question', 'options' => [...], 'max_options', 'length_days', 'vote_change']
	 * @return array
	 */
	public function create_topic($forum_id, $title, $content, $type, array $attachment_data = [], array $poll = [])
	{
		$forum = $this->load_forum($forum_id);

		if ((int) $forum['forum_status'] === ITEM_LOCKED && !$this->auth->acl_get('m_edit', (int) $forum['forum_id']))
		{
			throw new api_exception('forum_locked', 403);
		}

		if (!$this->auth->acl_get('f_post', (int) $forum['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$this->assert_not_flooding((int) $forum['forum_id']);

		$poll_ary = $this->build_poll_ary($poll, (int) $forum['forum_id']);

		$topic_type = $this->resolve_topic_type($type, (int) $forum['forum_id']);

		$title = utf8_encode_ucr(trim((string) $title));
		$content = trim((string) $content);

		if ($title === '' || $content === '')
		{
			throw new api_exception('missing_fields', 400);
		}

		if (utf8_strlen($title) > self::MAX_TITLE_LENGTH)
		{
			throw new api_exception('title_too_long', 400);
		}

		$this->include_posting_functions();

		$parsed = $this->parse_message($content, (int) $forum['forum_id']);
		$message_parser = $parsed['parser'];

		$data = [
			'topic_title'			=> $title,
			'topic_first_post_id'	=> 0,
			'topic_last_post_id'	=> 0,
			'topic_time_limit'		=> 0,
			'topic_attachment'		=> 0,
			'post_id'				=> 0,
			'topic_id'				=> 0,
			'forum_id'				=> (int) $forum['forum_id'],
			'icon_id'				=> 0,
			'poster_id'				=> (int) $this->user->data['user_id'],
			'enable_sig'			=> false,
			'enable_bbcode'			=> $parsed['bbcode_status'],
			'enable_smilies'		=> $parsed['smilies_status'],
			'enable_urls'			=> $parsed['url_status'],
			'enable_indexing'		=> true,
			'message_md5'			=> md5($message_parser->message),
			'post_checksum'			=> '',
			'post_edit_reason'		=> '',
			'post_edit_user'		=> 0,
			'forum_parents'			=> $forum['forum_parents'],
			'forum_name'			=> $forum['forum_name'],
			'notify'				=> false,
			'notify_set'			=> true,
			'poster_ip'				=> $this->user->ip,
			'post_edit_locked'		=> 0,
			'bbcode_bitfield'		=> $message_parser->bbcode_bitfield,
			'bbcode_uid'			=> $message_parser->bbcode_uid,
			'message'				=> $message_parser->message,
			'attachment_data'		=> $attachment_data,
			'filename_data'			=> [],
			'topic_status'			=> ITEM_UNLOCKED,
			'username'				=> '',
		];

		submit_post('post', $title, '', $topic_type, $poll_ary, $data, true, true);

		return [
			'topic_id'			=> (int) $data['topic_id'],
			'post_id'			=> (int) $data['post_id'],
			'url'				=> generate_board_url() . '/viewtopic.php?t=' . (int) $data['topic_id'],
			'attachment_ids'	=> array_column($attachment_data, 'attach_id'),
		];
	}

	/**
	 * @param int		$topic_id
	 * @param string	$content
	 * @param array		$attachment_data	zero or more entries built by attachment_manager::upload()
	 * @return array
	 */
	public function create_reply($topic_id, $content, array $attachment_data = [])
	{
		$topic = $this->load_topic($topic_id);
		$forum = $this->load_forum((int) $topic['forum_id']);

		if ((int) $forum['forum_status'] === ITEM_LOCKED && !$this->auth->acl_get('m_lock', (int) $forum['forum_id']))
		{
			throw new api_exception('forum_locked', 403);
		}

		if ((int) $topic['topic_status'] === ITEM_LOCKED && !$this->auth->acl_get('m_lock', (int) $forum['forum_id']))
		{
			throw new api_exception('topic_locked', 403);
		}

		if (!$this->auth->acl_get('f_reply', (int) $forum['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$this->assert_not_flooding((int) $forum['forum_id']);

		$content = trim((string) $content);

		if ($content === '')
		{
			throw new api_exception('missing_fields', 400);
		}

		$this->include_posting_functions();

		$parsed = $this->parse_message($content, (int) $forum['forum_id']);
		$message_parser = $parsed['parser'];
		$subject = 'Re: ' . $topic['topic_title'];

		$data = [
			'topic_title'			=> $topic['topic_title'],
			'topic_first_post_id'	=> (int) $topic['topic_first_post_id'],
			'topic_last_post_id'	=> (int) $topic['topic_last_post_id'],
			'topic_time_limit'		=> (int) $topic['topic_time_limit'],
			'topic_attachment'		=> 0,
			'post_id'				=> 0,
			'topic_id'				=> (int) $topic['topic_id'],
			'forum_id'				=> (int) $forum['forum_id'],
			'icon_id'				=> 0,
			'poster_id'				=> (int) $this->user->data['user_id'],
			'enable_sig'			=> false,
			'enable_bbcode'			=> $parsed['bbcode_status'],
			'enable_smilies'		=> $parsed['smilies_status'],
			'enable_urls'			=> $parsed['url_status'],
			'enable_indexing'		=> true,
			'message_md5'			=> md5($message_parser->message),
			'post_checksum'			=> '',
			'post_edit_reason'		=> '',
			'post_edit_user'		=> 0,
			'forum_parents'			=> $forum['forum_parents'],
			'forum_name'			=> $forum['forum_name'],
			'notify'				=> false,
			'notify_set'			=> true,
			'poster_ip'				=> $this->user->ip,
			'post_edit_locked'		=> 0,
			'bbcode_bitfield'		=> $message_parser->bbcode_bitfield,
			'bbcode_uid'			=> $message_parser->bbcode_uid,
			'message'				=> $message_parser->message,
			'attachment_data'		=> $attachment_data,
			'filename_data'			=> [],
			'topic_status'			=> (int) $topic['topic_status'],
			'username'				=> '',
		];

		$poll = [];

		submit_post('reply', $subject, '', (int) $topic['topic_type'], $poll, $data, true, true);

		return [
			'topic_id'			=> (int) $data['topic_id'],
			'post_id'			=> (int) $data['post_id'],
			'url'				=> generate_board_url() . '/viewtopic.php?t=' . (int) $data['topic_id'] . '&p=' . (int) $data['post_id'] . '#p' . (int) $data['post_id'],
			'attachment_ids'	=> array_column($attachment_data, 'attach_id'),
		];
	}

	/**
	 * @param int		$topic_id
	 * @param string	$title
	 * @param string	$content
	 * @return array
	 */
	public function update_topic($topic_id, $title, $content)
	{
		$topic = $this->load_topic($topic_id);
		$forum = $this->load_forum((int) $topic['forum_id']);
		$post = $this->load_post((int) $topic['topic_first_post_id']);

		$title = utf8_encode_ucr(trim((string) $title));
		$content = trim((string) $content);

		if ($title === '' || $content === '')
		{
			throw new api_exception('missing_fields', 400);
		}

		if (utf8_strlen($title) > self::MAX_TITLE_LENGTH)
		{
			throw new api_exception('title_too_long', 400);
		}

		$this->assert_editable($post, $forum, $topic);

		$this->include_posting_functions();

		$parsed = $this->parse_message($content, (int) $forum['forum_id']);
		$message_parser = $parsed['parser'];

		$data = [
			'topic_title'				=> $title,
			'topic_first_post_id'		=> (int) $topic['topic_first_post_id'],
			'topic_last_post_id'		=> (int) $topic['topic_last_post_id'],
			'topic_time_limit'			=> (int) $topic['topic_time_limit'],
			'topic_attachment'			=> (int) $topic['topic_attachment'],
			'post_id'					=> (int) $post['post_id'],
			'topic_id'					=> (int) $topic['topic_id'],
			'forum_id'					=> (int) $forum['forum_id'],
			'icon_id'					=> (int) $post['icon_id'],
			'poster_id'					=> (int) $post['poster_id'],
			'enable_sig'				=> (bool) $post['enable_sig'],
			'enable_bbcode'				=> $parsed['bbcode_status'],
			'enable_smilies'			=> $parsed['smilies_status'],
			'enable_urls'				=> $parsed['url_status'],
			'enable_indexing'			=> true,
			'message_md5'				=> md5($message_parser->message),
			'post_checksum'				=> $post['post_checksum'],
			'post_edit_reason'			=> '',
			'post_edit_user'			=> (int) $this->user->data['user_id'],
			'forum_parents'				=> $forum['forum_parents'],
			'forum_name'				=> $forum['forum_name'],
			'notify'					=> false,
			'notify_set'				=> true,
			'poster_ip'					=> $post['poster_ip'],
			'post_edit_locked'			=> (int) $post['post_edit_locked'],
			'bbcode_bitfield'			=> $message_parser->bbcode_bitfield,
			'bbcode_uid'				=> $message_parser->bbcode_uid,
			'message'					=> $message_parser->message,
			'attachment_data'			=> $this->load_existing_attachments((int) $post['post_id']),
			'filename_data'				=> [],
			'topic_status'				=> (int) $topic['topic_status'],
			'topic_posts_approved'		=> (int) $topic['topic_posts_approved'],
			'topic_posts_unapproved'	=> (int) $topic['topic_posts_unapproved'],
			'topic_posts_softdeleted'	=> (int) $topic['topic_posts_softdeleted'],
			'username'					=> '',
		];

		$poll = $this->build_poll_ary_for_preservation($topic);

		submit_post('edit', $title, $this->poster_name($post), (int) $topic['topic_type'], $poll, $data, true, true);

		return [
			'topic_id'	=> (int) $data['topic_id'],
			'post_id'	=> (int) $data['post_id'],
			'url'		=> generate_board_url() . '/viewtopic.php?t=' . (int) $data['topic_id'],
		];
	}

	/**
	 * @param int		$post_id
	 * @param string	$content
	 * @return array
	 */
	public function update_post($post_id, $content)
	{
		$post = $this->load_post($post_id);
		$topic = $this->load_topic((int) $post['topic_id']);
		$forum = $this->load_forum((int) $post['forum_id']);

		$content = trim((string) $content);

		if ($content === '')
		{
			throw new api_exception('missing_fields', 400);
		}

		$this->assert_editable($post, $forum, $topic);

		$this->include_posting_functions();

		$parsed = $this->parse_message($content, (int) $forum['forum_id']);
		$message_parser = $parsed['parser'];
		$subject = $post['post_subject'];

		$data = [
			'topic_title'				=> $topic['topic_title'],
			'topic_first_post_id'		=> (int) $topic['topic_first_post_id'],
			'topic_last_post_id'		=> (int) $topic['topic_last_post_id'],
			'topic_time_limit'			=> (int) $topic['topic_time_limit'],
			'topic_attachment'			=> (int) $topic['topic_attachment'],
			'post_id'					=> (int) $post['post_id'],
			'topic_id'					=> (int) $topic['topic_id'],
			'forum_id'					=> (int) $forum['forum_id'],
			'icon_id'					=> (int) $post['icon_id'],
			'poster_id'					=> (int) $post['poster_id'],
			'enable_sig'				=> (bool) $post['enable_sig'],
			'enable_bbcode'				=> $parsed['bbcode_status'],
			'enable_smilies'			=> $parsed['smilies_status'],
			'enable_urls'				=> $parsed['url_status'],
			'enable_indexing'			=> true,
			'message_md5'				=> md5($message_parser->message),
			'post_checksum'				=> $post['post_checksum'],
			'post_edit_reason'			=> '',
			'post_edit_user'			=> (int) $this->user->data['user_id'],
			'forum_parents'				=> $forum['forum_parents'],
			'forum_name'				=> $forum['forum_name'],
			'notify'					=> false,
			'notify_set'				=> true,
			'poster_ip'					=> $post['poster_ip'],
			'post_edit_locked'			=> (int) $post['post_edit_locked'],
			'bbcode_bitfield'			=> $message_parser->bbcode_bitfield,
			'bbcode_uid'				=> $message_parser->bbcode_uid,
			'message'					=> $message_parser->message,
			'attachment_data'			=> $this->load_existing_attachments((int) $post['post_id']),
			'filename_data'				=> [],
			'topic_status'				=> (int) $topic['topic_status'],
			'topic_posts_approved'		=> (int) $topic['topic_posts_approved'],
			'topic_posts_unapproved'	=> (int) $topic['topic_posts_unapproved'],
			'topic_posts_softdeleted'	=> (int) $topic['topic_posts_softdeleted'],
			'username'					=> '',
		];

		$poll = $this->build_poll_ary_for_preservation($topic);

		submit_post('edit', $subject, $this->poster_name($post), (int) $topic['topic_type'], $poll, $data, true, true);

		return [
			'topic_id'	=> (int) $data['topic_id'],
			'post_id'	=> (int) $data['post_id'],
			'url'		=> generate_board_url() . '/viewtopic.php?t=' . (int) $data['topic_id'] . '&p=' . (int) $data['post_id'] . '#p' . (int) $data['post_id'],
		];
	}

	/**
	 * @param array	$post
	 * @param array	$forum
	 * @param array	$topic
	 * @return void
	 */
	protected function assert_editable(array $post, array $forum, array $topic)
	{
		$forum_id = (int) $forum['forum_id'];

		if ($this->auth->acl_get('m_edit', $forum_id))
		{
			return;
		}

		if ((int) $topic['topic_status'] === ITEM_LOCKED)
		{
			throw new api_exception('topic_locked', 403);
		}

		if (!$this->auth->acl_get('f_edit', $forum_id) || (int) $post['poster_id'] !== (int) $this->user->data['user_id'])
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		if ((int) $post['post_edit_locked'] === ITEM_LOCKED)
		{
			throw new api_exception('post_locked', 403);
		}

		if ((int) $this->config['edit_time'] > 0 && (int) $post['post_time'] <= time() - ((int) $this->config['edit_time'] * 60))
		{
			throw new api_exception('edit_time_expired', 403);
		}
	}

	/**
	 * @param int	$forum_id
	 * @return void
	 */
	protected function assert_not_flooding($forum_id)
	{
		$flood_interval = (int) $this->config['flood_interval'];

		if (!$flood_interval || $this->auth->acl_get('u_ignoreflood') || $this->auth->acl_get('f_ignoreflood', $forum_id))
		{
			return;
		}

		$last_post_time = (int) ($this->user->data['user_lastpost_time'] ?? 0);

		if ($last_post_time && time() - $last_post_time < $flood_interval)
		{
			throw new api_exception('flood_interval', 429);
		}
	}

	/**
	 * @param string	$type
	 * @param int		$forum_id
	 * @return int
	 */
	protected function resolve_topic_type($type, $forum_id)
	{
		if ($type === 'announcement')
		{
			if (!$this->auth->acl_get('f_announce', $forum_id))
			{
				throw new api_exception('insufficient_permissions', 403);
			}

			return POST_ANNOUNCE;
		}

		if ($type === 'sticky')
		{
			if (!$this->auth->acl_get('f_sticky', $forum_id))
			{
				throw new api_exception('insufficient_permissions', 403);
			}

			return POST_STICKY;
		}

		return POST_NORMAL;
	}

	/**
	 * @param array	$topic
	 * @return array	empty if the topic has no poll
	 */
	protected function build_poll_ary_for_preservation(array $topic)
	{
		if ((string) $topic['poll_title'] === '')
		{
			return [];
		}

		$sql = 'SELECT poll_option_text FROM ' . POLL_OPTIONS_TABLE . '
			WHERE topic_id = ' . (int) $topic['topic_id'] . '
			ORDER BY poll_option_id ASC';
		$result = $this->db->sql_query($sql);
		$options = array_column($this->db->sql_fetchrowset($result), 'poll_option_text');
		$this->db->sql_freeresult($result);

		if (empty($options))
		{
			return [];
		}

		return [
			'poll_title'		=> $topic['poll_title'],
			'poll_options'		=> $options,
			'poll_max_options'	=> max(1, (int) $topic['poll_max_options']),
			'poll_length'		=> (int) $topic['poll_length'] > 0 ? (int) round((int) $topic['poll_length'] / 86400) : 0,
			'poll_vote_change'	=> (int) $topic['poll_vote_change'],
			'poll_start'		=> (int) $topic['poll_start'],
		];
	}

	/**
	 * @param array	$poll
	 * @param int	$forum_id
	 * @return array	empty for no poll, else a poll_ary ready for submit_post()
	 */
	protected function build_poll_ary(array $poll, $forum_id)
	{
		if (empty($poll))
		{
			return [];
		}

		if (!$this->auth->acl_get('f_poll', $forum_id))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$question = utf8_encode_ucr(trim((string) ($poll['question'] ?? '')));
		$options = array_values(array_filter(array_map(static function ($option) {
			return utf8_encode_ucr(trim((string) $option));
		}, (array) ($poll['options'] ?? [])), static function ($option) {
			return $option !== '';
		}));

		if ($question === '' || count($options) < 2)
		{
			throw new api_exception('missing_fields', 400);
		}

		if (utf8_strlen($question) > self::MAX_TITLE_LENGTH)
		{
			throw new api_exception('poll_question_too_long', 400);
		}

		if (count($options) > (int) $this->config['max_poll_options'])
		{
			throw new api_exception('too_many_poll_options', 400);
		}

		$max_options = max(1, min((int) ($poll['max_options'] ?? 1), count($options)));

		return [
			'poll_title'		=> $question,
			'poll_options'		=> $options,
			'poll_max_options'	=> $max_options,
			'poll_length'		=> max(0, (int) ($poll['length_days'] ?? 0)),
			'poll_vote_change'	=> !empty($poll['vote_change']) ? 1 : 0,
			'poll_start'		=> 0,
		];
	}

	/**
	 * @param string	$content
	 * @param int		$forum_id
	 * @return array	['parser' => \parse_message, 'bbcode_status' => bool, 'smilies_status' => bool, 'url_status' => bool] with the flags posting.php would use
	 */
	protected function parse_message($content, $forum_id)
	{
		$bbcode_status = (bool) $this->config['allow_bbcode'] && $this->auth->acl_get('f_bbcode', $forum_id);
		$smilies_status = (bool) $this->config['allow_smilies'] && $this->auth->acl_get('f_smilies', $forum_id);
		$img_status = $bbcode_status && $this->auth->acl_get('f_img', $forum_id);
		$url_status = (bool) $this->config['allow_post_links'];
		$flash_status = $bbcode_status && $this->auth->acl_get('f_flash', $forum_id) && (bool) $this->config['allow_post_flash'];

		$message_parser = new \parse_message($content);
		$message_parser->parse($bbcode_status, $url_status, $smilies_status, $img_status, $flash_status, true, $url_status);

		if (!empty($message_parser->warn_msg))
		{
			throw new api_exception('message_rejected', 400);
		}

		return [
			'parser'			=> $message_parser,
			'bbcode_status'		=> $bbcode_status,
			'smilies_status'	=> $smilies_status,
			'url_status'		=> $url_status,
		];
	}

	/**
	 * @param int	$forum_id
	 * @return array
	 */
	protected function load_forum($forum_id)
	{
		$sql = 'SELECT forum_id, forum_name, forum_type, forum_status, forum_password, forum_parents
			FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . (int) $forum_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || (int) $row['forum_type'] !== FORUM_POST)
		{
			throw new api_exception('forum_not_found', 404);
		}

		if ($row['forum_password'] !== '')
		{
			throw new api_exception('forum_password_required', 403);
		}

		return $row;
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function load_topic($topic_id)
	{
		$sql = 'SELECT * FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || !$this->visibility->is_visible('topic', (int) $row['forum_id'], $row))
		{
			throw new api_exception('topic_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param array	$post	a POSTS_TABLE row
	 * @return string	what posting.php passes as submit_post()'s username on edit - the guest name for an anonymous post, else the poster's username (edit_first_post rewrites topic_first_poster_name from it)
	 */
	protected function poster_name(array $post)
	{
		if ((int) $post['poster_id'] === ANONYMOUS)
		{
			return (string) $post['post_username'];
		}

		$sql = 'SELECT username FROM ' . USERS_TABLE . '
			WHERE user_id = ' . (int) $post['poster_id'];
		$result = $this->db->sql_query($sql);
		$username = (string) $this->db->sql_fetchfield('username');
		$this->db->sql_freeresult($result);

		return $username;
	}

	/**
	 * @param int	$post_id
	 * @return array	the post's current attachment rows in the shape submit_post('edit') expects, like posting.php preloads them
	 */
	protected function load_existing_attachments($post_id)
	{
		$sql = 'SELECT attach_id, is_orphan, attach_comment, real_filename, filesize
			FROM ' . ATTACHMENTS_TABLE . '
			WHERE post_msg_id = ' . (int) $post_id . '
				AND in_message = 0
				AND is_orphan = 0
			ORDER BY attach_id DESC';
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param int	$post_id
	 * @return array
	 */
	protected function load_post($post_id)
	{
		$sql = 'SELECT * FROM ' . POSTS_TABLE . '
			WHERE post_id = ' . (int) $post_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || !$this->visibility->is_visible('post', (int) $row['forum_id'], $row))
		{
			throw new api_exception('post_not_found', 404);
		}

		return $row;
	}

	/**
	 * @return void
	 */
	protected function include_posting_functions()
	{
		if (!function_exists('submit_post'))
		{
			include($this->root_path . 'includes/functions_posting.' . $this->php_ext);
		}

		if (!class_exists('parse_message', false))
		{
			include($this->root_path . 'includes/message_parser.' . $this->php_ext);
		}
	}
}
