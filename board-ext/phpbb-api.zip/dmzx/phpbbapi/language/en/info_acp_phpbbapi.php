<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

$lang = array_merge($lang, [
	'ACP_PHPBBAPI_TITLE'				=> 'phpBB API',
	'ACP_PHPBBAPI_OVERVIEW_TITLE'		=> 'Overview',
	'ACP_PHPBBAPI_CREDENTIALS_TITLE'	=> 'API credentials',
	'ACP_PHPBBAPI_LOG_TITLE'			=> 'Request log',
	'ACP_PHPBBAPI_SETTINGS_TITLE'		=> 'Settings',
	'ACP_PHPBBAPI_WEBHOOKS_TITLE'		=> 'Webhooks',
	'ACP_PHPBBAPI_WEBHOOK_LOG_TITLE'	=> 'Webhook deliveries',

	'LOG_PHPBBAPI_CREDENTIAL_CREATED'	=> '<strong>API credential created</strong><br />» %1$s',
	'LOG_PHPBBAPI_CREDENTIAL_UPDATED'	=> '<strong>API credential updated</strong><br />» %1$s',
	'LOG_PHPBBAPI_CREDENTIAL_TOGGLED'	=> '<strong>API credential enabled/disabled</strong><br />» %1$s',
	'LOG_PHPBBAPI_CREDENTIAL_REGENERATED'	=> '<strong>API credential token regenerated</strong><br />» %1$s',
	'LOG_PHPBBAPI_CREDENTIAL_DELETED'	=> '<strong>API credential deleted</strong><br />» %1$s',
	'LOG_PHPBBAPI_SETTINGS_SAVED'		=> '<strong>phpBB API settings updated</strong>',
	'LOG_PHPBBAPI_WEBHOOK_CREATED'		=> '<strong>Webhook created</strong><br />» %1$s',
	'LOG_PHPBBAPI_WEBHOOK_UPDATED'		=> '<strong>Webhook updated</strong><br />» %1$s',
	'LOG_PHPBBAPI_WEBHOOK_TOGGLED'		=> '<strong>Webhook enabled/disabled</strong><br />» %1$s',
	'LOG_PHPBBAPI_WEBHOOK_SECRET_REGENERATED'	=> '<strong>Webhook signing secret regenerated</strong><br />» %1$s',
	'LOG_PHPBBAPI_WEBHOOK_DELETED'		=> '<strong>Webhook deleted</strong><br />» %1$s',
]);
