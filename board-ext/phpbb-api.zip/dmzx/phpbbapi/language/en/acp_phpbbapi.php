<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = [];
}

$lang = array_merge($lang, [
	'PHPBBAPI_OVERVIEW_EXPLAIN'		=> 'A quick look at how the REST API is being used on this board.',
	'PHPBBAPI_STAT_CREDENTIALS'		=> 'Credentials',
	'PHPBBAPI_STAT_ENABLED'			=> 'Enabled',
	'PHPBBAPI_STAT_DISABLED'		=> 'Disabled',
	'PHPBBAPI_STAT_REQUESTS_24H'	=> 'Requests (24h)',
	'PHPBBAPI_STAT_ERROR_RATE'		=> 'Error rate (24h)',
	'PHPBBAPI_TOP_ROUTES'			=> 'Most-used routes (last 24h)',
	'PHPBBAPI_TOP_ROUTES_HITS'		=> 'Requests',
	'PHPBBAPI_TOP_ROUTES_NONE'		=> 'No requests in the last 24 hours.',

	'PHPBBAPI_EXPLAIN'				=> 'A credential lets an external application act as one phpBB member through the REST API, scoped to exactly the permissions you grant below. The token is only ever shown once, right after creation.',

	'PHPBBAPI_NEW_CREDENTIAL'		=> 'New credential',
	'PHPBBAPI_EDIT_CREDENTIAL'		=> 'Edit credential',
	'PHPBBAPI_SAVE_CHANGES'			=> 'Save changes',
	'PHPBBAPI_CANCEL'				=> 'Cancel',
	'PHPBBAPI_CREDENTIAL_SAVED'		=> 'Credential updated.',
	'PHPBBAPI_USERNAME_LOCKED_EXPLAIN'	=> 'Cannot be changed here - create a new credential to bind a different member.',
	'PHPBBAPI_NAME'					=> 'Credential name',
	'PHPBBAPI_NAME_EXPLAIN'			=> 'A label to recognise this credential by, e.g. "Discord bot".',
	'PHPBBAPI_USERNAME'				=> 'Acts as user',
	'PHPBBAPI_USERNAME_EXPLAIN'		=> 'Every request with this credential runs with this member\'s own permissions - nothing more.',
	'PHPBBAPI_USER_NOT_FOUND'		=> 'That username was not found.',
	'PHPBBAPI_USER_NOT_BINDABLE'	=> 'A credential cannot be bound to the Anonymous user, a bot or an inactive account.',
	'PHPBBAPI_USER_FOUNDER_ONLY'	=> 'Only a founder can bind a credential to a founder account.',
	'PHPBBAPI_SCOPES'				=> 'Scopes',
	'PHPBBAPI_SCOPES_EXPLAIN'		=> 'What this credential is allowed to do. Every action is still checked against the member\'s own phpBB permissions on top of this.',
	'PHPBBAPI_FORUM_ALLOWLIST'		=> 'Forum allowlist',
	'PHPBBAPI_FORUM_ALLOWLIST_EXPLAIN'	=> 'Tick the forums this credential may access. Leave everything unticked to allow every forum the member can already read.',
	'PHPBBAPI_NO_FORUMS'			=> 'No forums found.',
	'PHPBBAPI_IP_ALLOWLIST'			=> 'IP allowlist',
	'PHPBBAPI_IP_ALLOWLIST_EXPLAIN'	=> 'Comma-separated IP addresses allowed to use this credential. Leave blank to allow any IP.',
	'PHPBBAPI_RATE_LIMIT'			=> 'Rate limit',
	'PHPBBAPI_RATE_LIMIT_EXPLAIN'	=> 'Maximum requests per window. 0 = unlimited.',
	'PHPBBAPI_RATE_WINDOW'			=> 'Rate window (seconds)',
	'PHPBBAPI_EXPIRES'				=> 'Expires on',
	'PHPBBAPI_EXPIRES_EXPLAIN'		=> 'Optional. Leave blank for a credential that never expires.',
	'PHPBBAPI_CREATE'				=> 'Create credential',

	'PHPBBAPI_TOKEN_WARNING'		=> 'Copy this token now - it will never be shown again.',
	'PHPBBAPI_TOKEN_FOR'			=> 'Token for "%s"',

	'PHPBBAPI_COL_NAME'				=> 'Name',
	'PHPBBAPI_COL_USER'				=> 'User',
	'PHPBBAPI_COL_TOKEN'			=> 'Token',
	'PHPBBAPI_COL_SCOPES'			=> 'Scopes',
	'PHPBBAPI_COL_FORUMS'			=> 'Forums',
	'PHPBBAPI_ALL_FORUMS'			=> 'All',
	'PHPBBAPI_COL_RATE_LIMIT'		=> 'Rate limit',
	'PHPBBAPI_COL_EXPIRES'			=> 'Expires',
	'PHPBBAPI_COL_LAST_USED'		=> 'Last used',
	'PHPBBAPI_COL_STATUS'			=> 'Status',
	'PHPBBAPI_COL_ACTIONS'			=> 'Actions',

	'PHPBBAPI_STATUS_ENABLED'		=> 'Enabled',
	'PHPBBAPI_STATUS_DISABLED'		=> 'Disabled',
	'PHPBBAPI_NEVER'				=> 'Never',
	'PHPBBAPI_TOGGLE'				=> 'Enable/disable',
	'PHPBBAPI_CONFIRM_TOGGLE'		=> 'Enable or disable this credential? Requests using it will start failing immediately while disabled.',
	'PHPBBAPI_CREDENTIAL_UPDATED'	=> 'Credential updated.',
	'PHPBBAPI_REGENERATE'			=> 'Regenerate',
	'PHPBBAPI_CONFIRM_REGENERATE'	=> 'Generate a new token for this credential? The current token will keep working for 24 hours so you can update your application, then stop working.',
	'PHPBBAPI_OLD_TOKEN_VALID_UNTIL'	=> 'Old token valid until %s',
	'PHPBBAPI_DELETE'				=> 'Delete',
	'PHPBBAPI_CONFIRM_DELETE'		=> 'Delete this credential permanently? Any application still using its token will immediately lose access.',
	'PHPBBAPI_CREDENTIAL_DELETED'	=> 'Credential deleted.',
	'PHPBBAPI_NO_CREDENTIALS'		=> 'No API credentials have been created yet.',

	'PHPBBAPI_LOG_EXPLAIN'			=> 'Every request made through the API, successful or not.',
	'PHPBBAPI_LOG_COL_TIME'			=> 'Time',
	'PHPBBAPI_LOG_COL_USER'			=> 'User',
	'PHPBBAPI_LOG_COL_IP'			=> 'IP',
	'PHPBBAPI_LOG_COL_METHOD'		=> 'Method',
	'PHPBBAPI_LOG_COL_ROUTE'		=> 'Route',
	'PHPBBAPI_LOG_COL_STATUS'		=> 'Status',
	'PHPBBAPI_LOG_COL_ERROR'		=> 'Error',
	'PHPBBAPI_LOG_NO_ENTRIES'		=> 'No requests have been logged yet.',

	'PHPBBAPI_SETTINGS_EXPLAIN'		=> 'Board-wide switches for the REST API. Individual access is controlled per credential above.',
	'PHPBBAPI_ENABLED'				=> 'API enabled',
	'PHPBBAPI_ENABLED_EXPLAIN'		=> 'Master switch. When off, every API request is rejected regardless of credential.',
	'PHPBBAPI_REQUIRE_HTTPS'		=> 'Require HTTPS',
	'PHPBBAPI_REQUIRE_HTTPS_EXPLAIN'	=> 'Reject any API request that did not arrive over HTTPS. Only disable this for local development.',
	'PHPBBAPI_CORS_ORIGINS'			=> 'Allowed CORS origins',
	'PHPBBAPI_CORS_ORIGINS_EXPLAIN'	=> 'Comma-separated origins (e.g. https://app.example.com) allowed to call the API directly from browser JavaScript. Leave blank to disable CORS entirely - server-to-server and mobile clients are unaffected either way.',
	'PHPBBAPI_LOG_RETENTION_DAYS'	=> 'Log retention (days)',
	'PHPBBAPI_LOG_RETENTION_DAYS_EXPLAIN'	=> 'Request log and webhook delivery log entries older than this are removed once a day by the board cron. 0 keeps them forever.',
	'PHPBBAPI_SETTINGS_SAVED'		=> 'Settings saved.',

	'PHPBBAPI_WEBHOOKS_EXPLAIN'		=> 'Get an HTTP POST sent to a URL of your choice whenever something matching your subscribed events happens through this API. Every delivery is signed - verify it using the secret shown once at creation.',
	'PHPBBAPI_NEW_WEBHOOK'			=> 'New webhook',
	'PHPBBAPI_EDIT_WEBHOOK'			=> 'Edit webhook',
	'PHPBBAPI_WEBHOOK_SAVED'		=> 'Webhook updated.',
	'PHPBBAPI_WEBHOOK_NAME'			=> 'Webhook name',
	'PHPBBAPI_WEBHOOK_NAME_EXPLAIN'	=> 'A label to recognise this webhook by, e.g. "Discord notifier".',
	'PHPBBAPI_WEBHOOK_URL'			=> 'Delivery URL',
	'PHPBBAPI_WEBHOOK_URL_EXPLAIN'	=> 'Where the signed POST request is sent for every matching event. Must be an HTTPS URL.',
	'PHPBBAPI_WEBHOOK_URL_INVALID'	=> 'Enter a valid HTTPS URL. Plain HTTP is not allowed, because the signed board data would be sent unencrypted.',
	'PHPBBAPI_WEBHOOK_EVENTS'		=> 'Events',
	'PHPBBAPI_WEBHOOK_EVENTS_EXPLAIN'	=> 'Which events this webhook should be sent for.',
	'PHPBBAPI_WEBHOOK_FIRE_ON_UI_ACTIONS'	=> 'Fire for forum-UI actions too',
	'PHPBBAPI_WEBHOOK_FIRE_ON_UI_ACTIONS_EXPLAIN'	=> 'By default this webhook only fires for actions made through the REST API. Enable this to also fire when the same kind of action happens through the normal forum UI (e.g. a manual post or edit).',
	'PHPBBAPI_CREATE_WEBHOOK'		=> 'Create webhook',

	'PHPBBAPI_WEBHOOK_SECRET_WARNING'	=> 'Copy this secret now - it will never be shown again. Use it to verify the X-Webhook-Signature header on every delivery.',
	'PHPBBAPI_WEBHOOK_SECRET_FOR'	=> 'Secret for "%s"',

	'PHPBBAPI_WEBHOOK_COL_NAME'		=> 'Name',
	'PHPBBAPI_WEBHOOK_COL_URL'		=> 'URL',
	'PHPBBAPI_WEBHOOK_COL_SECRET'	=> 'Secret',
	'PHPBBAPI_WEBHOOK_COL_EVENTS'	=> 'Events',
	'PHPBBAPI_WEBHOOK_COL_FAILURES'	=> 'Failures',
	'PHPBBAPI_WEBHOOK_COL_LAST_TRIGGERED'	=> 'Last triggered',
	'PHPBBAPI_WEBHOOK_COL_STATUS'	=> 'Status',
	'PHPBBAPI_WEBHOOK_COL_UI_ORIGIN'	=> 'UI actions',
	'PHPBBAPI_WEBHOOK_COL_ACTIONS'	=> 'Actions',
	'PHPBBAPI_WEBHOOK_UPDATED'		=> 'Webhook updated.',
	'PHPBBAPI_WEBHOOK_DELETED'		=> 'Webhook deleted.',
	'PHPBBAPI_CONFIRM_TOGGLE_WEBHOOK'	=> 'Enable or disable this webhook? Deliveries will stop immediately while disabled.',
	'PHPBBAPI_CONFIRM_REGENERATE_WEBHOOK'	=> 'Generate a new signing secret for this webhook? Deliveries will be signed with both the new and current secret for 24 hours so you can update your endpoint\'s verification, then only with the new one.',
	'PHPBBAPI_OLD_SECRET_VALID_UNTIL'	=> 'Old secret valid until %s',
	'PHPBBAPI_CONFIRM_DELETE_WEBHOOK'	=> 'Delete this webhook permanently?',
	'PHPBBAPI_NO_WEBHOOKS'			=> 'No webhooks have been created yet.',

	'PHPBBAPI_WEBHOOK_LOG_EXPLAIN'		=> 'Every webhook delivery attempt, successful or not, including automatic retries of failed deliveries.',
	'PHPBBAPI_WEBHOOK_LOG_COL_TIME'		=> 'Last attempt',
	'PHPBBAPI_WEBHOOK_LOG_COL_WEBHOOK'	=> 'Webhook',
	'PHPBBAPI_WEBHOOK_LOG_COL_EVENT'		=> 'Event',
	'PHPBBAPI_WEBHOOK_LOG_COL_STATUS'	=> 'HTTP status',
	'PHPBBAPI_WEBHOOK_LOG_COL_RESULT'	=> 'Result',
	'PHPBBAPI_WEBHOOK_LOG_COL_RETRY'		=> 'Retry',
	'PHPBBAPI_WEBHOOK_LOG_COL_RESPONSE'	=> 'Response',
	'PHPBBAPI_WEBHOOK_LOG_NO_ENTRIES'	=> 'No webhook deliveries have been logged yet.',
	'PHPBBAPI_WEBHOOK_DELIVERED'		=> 'Delivered',
	'PHPBBAPI_WEBHOOK_FAILED'			=> 'Failed',
	'PHPBBAPI_WEBHOOK_RETRY_PENDING'	=> 'Retry %1$d of %2$d scheduled for %3$s',
	'PHPBBAPI_WEBHOOK_RETRY_EXHAUSTED'	=> 'Retries exhausted',
]);
