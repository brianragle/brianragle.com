<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use phpbb\db\driver\driver_interface;

class webhook_manager
{
	const SECRET_PREFIX = 'whsec_';
	const SECRET_ROTATION_GRACE_SECONDS = 86400;

	const EVENTS = [
		'topic.created',
		'topic.updated',
		'topic.deleted',
		'topic.locked',
		'topic.unlocked',
		'topic.soft_deleted',
		'topic.restored',
		'topic.moved',
		'topic.merged',
		'topic.split',
		'post.created',
		'post.updated',
		'post.deleted',
		'post.approved',
		'post.disapproved',
		'post.soft_deleted',
		'post.restored',
		'member.registered',
	];

	/** @var driver_interface */
	protected $db;

	/** @var string */
	protected $webhooks_table;

	/**
	 * @param driver_interface	$db
	 * @param string			$webhooks_table
	 */
	public function __construct(driver_interface $db, $webhooks_table)
	{
		$this->db = $db;
		$this->webhooks_table = $webhooks_table;
	}

	/**
	 * @param array	$data	name, url, events, fire_on_ui_actions
	 * @return array	['webhook' => array, 'secret' => string]	The raw secret is only ever available here
	 */
	public function create_webhook(array $data)
	{
		$secret = $this->generate_secret();

		$sql_ary = [
			'name'					=> utf8_substr(trim((string) ($data['name'] ?? '')), 0, 100),
			'url'					=> trim((string) ($data['url'] ?? '')),
			'secret'				=> $secret,
			'secret_prefix'			=> self::SECRET_PREFIX . substr($secret, strlen(self::SECRET_PREFIX), 6),
			'events'				=> $this->encode_list($this->filter_events($data['events'] ?? [])),
			'fire_on_ui_actions'	=> !empty($data['fire_on_ui_actions']) ? 1 : 0,
			'enabled'				=> 1,
			'created_time'			=> time(),
			'last_triggered_time'	=> 0,
			'failure_count'			=> 0,
		];

		$sql = 'INSERT INTO ' . $this->webhooks_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
		$this->db->sql_query($sql);

		$sql_ary['webhook_id'] = (int) $this->db->sql_nextid();

		return ['webhook' => $sql_ary, 'secret' => $secret];
	}

	/**
	 * @param int	$webhook_id
	 * @param array	$data	name, url, events, fire_on_ui_actions
	 * @return void
	 */
	public function update_webhook($webhook_id, array $data)
	{
		$sql_ary = [
			'name'					=> utf8_substr(trim((string) ($data['name'] ?? '')), 0, 100),
			'url'					=> trim((string) ($data['url'] ?? '')),
			'events'				=> $this->encode_list($this->filter_events($data['events'] ?? [])),
			'fire_on_ui_actions'	=> !empty($data['fire_on_ui_actions']) ? 1 : 0,
		];

		$sql = 'UPDATE ' . $this->webhooks_table . '
			SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE webhook_id = ' . (int) $webhook_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$webhook_id
	 * @return void
	 */
	public function delete_webhook($webhook_id)
	{
		$sql = 'DELETE FROM ' . $this->webhooks_table . '
			WHERE webhook_id = ' . (int) $webhook_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$webhook_id
	 * @param bool	$enabled
	 * @return void
	 */
	public function set_enabled($webhook_id, $enabled)
	{
		$sql = 'UPDATE ' . $this->webhooks_table . '
			SET enabled = ' . ($enabled ? 1 : 0) . '
			WHERE webhook_id = ' . (int) $webhook_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$webhook_id
	 * @return string|null	the new plaintext secret, or null if the webhook doesn't exist
	 */
	public function regenerate_secret($webhook_id)
	{
		$webhook = $this->get_webhook($webhook_id);

		if ($webhook === null)
		{
			return null;
		}

		$secret = $this->generate_secret();

		$sql_ary = [
			'secret'						=> $secret,
			'secret_prefix'					=> self::SECRET_PREFIX . substr($secret, strlen(self::SECRET_PREFIX), 6),
			'previous_secret'				=> $webhook['secret'],
			'previous_secret_expires_time'	=> time() + self::SECRET_ROTATION_GRACE_SECONDS,
		];

		$sql = 'UPDATE ' . $this->webhooks_table . '
			SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE webhook_id = ' . (int) $webhook_id;
		$this->db->sql_query($sql);

		return $secret;
	}

	/**
	 * @param int	$webhook_id
	 * @return array|null
	 */
	public function get_webhook($webhook_id)
	{
		$sql = 'SELECT * FROM ' . $this->webhooks_table . '
			WHERE webhook_id = ' . (int) $webhook_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		return $row ?: null;
	}

	/**
	 * @return array
	 */
	public function get_all_webhooks()
	{
		$sql = 'SELECT * FROM ' . $this->webhooks_table . '
			ORDER BY created_time DESC';
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param string	$event
	 * @param bool		$ui_origin
	 * @return array
	 */
	public function get_enabled_webhooks_for_event($event, $ui_origin = false)
	{
		$sql = 'SELECT * FROM ' . $this->webhooks_table . '
			WHERE enabled = 1' . ($ui_origin ? '
				AND fire_on_ui_actions = 1' : '');
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_values(array_filter($rows, function ($row) use ($event) {
			return in_array($event, $this->get_events($row), true);
		}));
	}

	/**
	 * @param int	$webhook_id
	 * @param bool	$success
	 * @return void
	 */
	public function record_delivery_result($webhook_id, $success)
	{
		$sql = 'UPDATE ' . $this->webhooks_table . '
			SET last_triggered_time = ' . time() . ',
				failure_count = ' . ($success ? 0 : 'failure_count + 1') . '
			WHERE webhook_id = ' . (int) $webhook_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param array	$webhook
	 * @return array
	 */
	public function get_events(array $webhook)
	{
		return $this->decode_list($webhook['events']);
	}

	/**
	 * @return string
	 */
	protected function generate_secret()
	{
		return self::SECRET_PREFIX . bin2hex(random_bytes(32));
	}

	/**
	 * @param mixed	$events
	 * @return array
	 */
	protected function filter_events($events)
	{
		$events = is_array($events) ? $events : [];

		return array_values(array_intersect($events, self::EVENTS));
	}

	/**
	 * @param array	$values
	 * @return string
	 */
	protected function encode_list(array $values)
	{
		return implode(',', $values);
	}

	/**
	 * @param string	$value
	 * @return array
	 */
	protected function decode_list($value)
	{
		$value = trim((string) $value);

		return $value === '' ? [] : explode(',', $value);
	}
}
