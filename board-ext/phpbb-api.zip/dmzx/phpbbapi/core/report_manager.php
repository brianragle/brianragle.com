<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\db\driver\driver_interface;

class report_manager
{
	const MAX_LIMIT = 100;
	const DEFAULT_LIMIT = 25;

	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/**
	 * @param driver_interface	$db
	 * @param auth				$auth
	 */
	public function __construct(driver_interface $db, auth $auth)
	{
		$this->db = $db;
		$this->auth = $auth;
	}

	/**
	 * @param string	$status		'open', 'closed', or 'all'
	 * @param int		$limit
	 * @param int		$start
	 * @return array
	 */
	public function list_reports($status, $limit, $start)
	{
		$limit = $this->clamp_limit($limit);
		$start = max(0, (int) $start);

		$forum_ids = $this->get_reportable_forum_ids();

		if (empty($forum_ids))
		{
			return [
				'pagination'	=> ['limit' => $limit, 'start' => $start, 'total' => 0, 'count' => 0],
				'reports'		=> [],
			];
		}

		$sql_where = 'r.pm_id = 0
			AND r.post_id = p.post_id
			AND ' . $this->db->sql_in_set('p.forum_id', array_map('intval', $forum_ids));

		if ($status === 'open')
		{
			$sql_where .= ' AND r.report_closed = 0';
		}
		else if ($status === 'closed')
		{
			$sql_where .= ' AND r.report_closed = 1';
		}

		$sql = 'SELECT COUNT(*) AS total
			FROM ' . REPORTS_TABLE . ' r, ' . POSTS_TABLE . ' p
			WHERE ' . $sql_where;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		$sql = 'SELECT r.report_id, r.post_id, r.user_id, r.report_time, r.report_closed, r.report_text,
				p.topic_id, p.forum_id, p.post_subject, u.username, rr.reason_title
			FROM ' . REPORTS_TABLE . ' r, ' . POSTS_TABLE . ' p, ' . USERS_TABLE . ' u, ' . REPORTS_REASONS_TABLE . ' rr
			WHERE ' . $sql_where . '
				AND r.user_id = u.user_id
				AND r.reason_id = rr.reason_id
			ORDER BY r.report_closed ASC, r.report_time DESC';
		$result = $this->db->sql_query_limit($sql, $limit, $start);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return [
			'pagination'	=> ['limit' => $limit, 'start' => $start, 'total' => $total, 'count' => count($rows)],
			'reports'		=> array_map([$this, 'format_report'], $rows),
		];
	}

	/**
	 * @return array
	 */
	protected function get_reportable_forum_ids()
	{
		$sql = 'SELECT forum_id FROM ' . FORUMS_TABLE;
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		$forum_ids = [];

		foreach ($rows as $row)
		{
			$forum_id = (int) $row['forum_id'];

			if ($this->auth->acl_get('m_report', $forum_id))
			{
				$forum_ids[] = $forum_id;
			}
		}

		return $forum_ids;
	}

	/**
	 * @param int	$report_id
	 * @return void
	 */
	public function resolve_report($report_id)
	{
		$report = $this->load_report($report_id);

		if (!$this->auth->acl_get('m_report', (int) $report['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		if ((int) $report['report_closed'])
		{
			throw new api_exception('report_already_resolved', 400);
		}

		$this->db->sql_query('UPDATE ' . REPORTS_TABLE . '
			SET report_closed = 1
			WHERE report_id = ' . (int) $report_id);

		$this->resync_reported_flags((int) $report['post_id'], (int) $report['topic_id']);
	}

	/**
	 * @param int	$post_id
	 * @param int	$topic_id
	 * @return void
	 */
	protected function resync_reported_flags($post_id, $topic_id)
	{
		$sql = 'SELECT COUNT(*) AS total FROM ' . REPORTS_TABLE . '
			WHERE post_id = ' . (int) $post_id . '
				AND pm_id = 0
				AND report_closed = 0';
		$result = $this->db->sql_query($sql);
		$remaining = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		if ($remaining)
		{
			return;
		}

		$this->db->sql_query('UPDATE ' . POSTS_TABLE . '
			SET post_reported = 0
			WHERE post_id = ' . (int) $post_id);

		$sql = 'SELECT COUNT(*) AS total FROM ' . POSTS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id . '
				AND post_reported = 1';
		$result = $this->db->sql_query($sql);
		$remaining_in_topic = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		if (!$remaining_in_topic)
		{
			$this->db->sql_query('UPDATE ' . TOPICS_TABLE . '
				SET topic_reported = 0
				WHERE topic_id = ' . (int) $topic_id . '
					OR topic_moved_id = ' . (int) $topic_id);
		}
	}

	/**
	 * @param int	$report_id
	 * @return array
	 */
	protected function load_report($report_id)
	{
		$sql = 'SELECT r.report_id, r.post_id, r.report_closed, p.forum_id, p.topic_id
			FROM ' . REPORTS_TABLE . ' r, ' . POSTS_TABLE . ' p
			WHERE r.report_id = ' . (int) $report_id . '
				AND r.pm_id = 0
				AND r.post_id = p.post_id';
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('report_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param array	$row
	 * @return array
	 */
	protected function format_report(array $row)
	{
		return [
			'report_id'		=> (int) $row['report_id'],
			'post_id'		=> (int) $row['post_id'],
			'topic_id'		=> (int) $row['topic_id'],
			'forum_id'		=> (int) $row['forum_id'],
			'post_subject'	=> $row['post_subject'],
			'reporter_id'	=> (int) $row['user_id'],
			'reporter'		=> $row['username'],
			'reason'		=> $row['reason_title'],
			'report_text'	=> $row['report_text'],
			'report_time'	=> (int) $row['report_time'],
			'resolved'		=> (bool) $row['report_closed'],
		];
	}

	/**
	 * @param int	$limit
	 * @return int
	 */
	protected function clamp_limit($limit)
	{
		$limit = (int) $limit;

		if ($limit <= 0)
		{
			return self::DEFAULT_LIMIT;
		}

		return min(self::MAX_LIMIT, $limit);
	}
}
