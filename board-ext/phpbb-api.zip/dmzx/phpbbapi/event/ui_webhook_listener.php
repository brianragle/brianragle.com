<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\event;

use dmzx\phpbbapi\core\auth_resolver;
use dmzx\phpbbapi\core\text;
use dmzx\phpbbapi\core\webhook_dispatcher;
use phpbb\db\driver\driver_interface;
use phpbb\event\data;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class ui_webhook_listener implements EventSubscriberInterface
{
	/** @var webhook_dispatcher */
	protected $webhooks;

	/** @var auth_resolver */
	protected $auth_resolver;

	/** @var driver_interface */
	protected $db;

	/** @var array	topic_id => forum_id, captured in on_move_topics_before() for on_move_topics_after() */
	protected $pending_topic_forum_ids = [];

	/**
	 * @param webhook_dispatcher	$webhooks
	 * @param auth_resolver			$auth_resolver
	 * @param driver_interface		$db
	 */
	public function __construct(webhook_dispatcher $webhooks, auth_resolver $auth_resolver, driver_interface $db)
	{
		$this->webhooks = $webhooks;
		$this->auth_resolver = $auth_resolver;
		$this->db = $db;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		return [
			'core.submit_post_end'					=> 'on_submit_post',
			'core.delete_post_after'				=> 'on_delete_post',
			'core.mcp_lock_unlock_after'			=> 'on_lock_unlock',
			'core.set_post_visibility_after'		=> 'on_set_post_visibility',
			'core.set_topic_visibility_after'		=> 'on_set_topic_visibility',
			'core.approve_posts_after'				=> 'on_approve_posts',
			'core.approve_topics_after'			=> 'on_approve_topics',
			'core.disapprove_posts_after'			=> 'on_disapprove_posts',
			'core.move_topics_before'				=> 'on_move_topics_before',
			'core.move_topics_after'				=> 'on_move_topics_after',
			'core.mcp_topics_merge_posts_after'	=> 'on_mcp_topics_merge_posts',
			'core.mcp_forum_merge_topics_after'	=> 'on_mcp_forum_merge_topics',
			'core.mcp_topic_split_topic_after'		=> 'on_mcp_topic_split',
			'core.user_add_after'					=> 'on_user_add',
		];
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_submit_post(data $event)
	{
		if ($this->auth_resolver->is_api_request())
		{
			return;
		}

		$post_data = $event['data'];
		$is_topic_post = (int) ($post_data['post_id'] ?? 0) === (int) ($post_data['topic_first_post_id'] ?? 0);

		switch ($event['mode'])
		{
			case 'post':
				$webhook_event = 'topic.created';
				break;

			case 'reply':
			case 'quote':
				$webhook_event = 'post.created';
				break;

			case 'edit':
				$webhook_event = $is_topic_post ? 'topic.updated' : 'post.updated';
				break;

			default:
				return;
		}

		$topic_id = (int) ($post_data['topic_id'] ?? 0);
		$post_id = (int) ($post_data['post_id'] ?? 0);
		$forum_id = (int) ($post_data['forum_id'] ?? 0);

		$payload = [
			'topic_id'	=> $topic_id,
			'post_id'	=> $post_id,
			'forum_id'	=> $forum_id,
		];

		if ($webhook_event === 'topic.created' || $webhook_event === 'topic.updated')
		{
			$payload['title'] = text::plain($post_data['topic_title'] ?? '');
			$payload['url'] = generate_board_url() . '/viewtopic.php?t=' . $topic_id;
		}
		else
		{
			$payload['url'] = generate_board_url() . '/viewtopic.php?t=' . $topic_id . '&p=' . $post_id . '#p' . $post_id;
		}

		$this->webhooks->dispatch($webhook_event, $payload, 'ui');
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_delete_post(data $event)
	{
		if ($event['is_soft'] || $this->auth_resolver->is_api_request())
		{
			return;
		}

		$forum_id = (int) $event['forum_id'];

		if (in_array($event['post_mode'], ['delete_topic', 'delete_first_post'], true))
		{
			$this->webhooks->dispatch('topic.deleted', [
				'topic_id'	=> (int) $event['topic_id'],
				'forum_id'	=> $forum_id,
			], 'ui');
		}
		else
		{
			$this->webhooks->dispatch('post.deleted', [
				'post_id'	=> (int) $event['post_id'],
				'forum_id'	=> $forum_id,
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_lock_unlock(data $event)
	{
		if (!in_array($event['action'], ['lock', 'unlock'], true) || $this->auth_resolver->is_api_request())
		{
			return;
		}

		$webhook_event = $event['action'] === 'lock' ? 'topic.locked' : 'topic.unlocked';

		foreach ($event['data'] as $row)
		{
			$this->webhooks->dispatch($webhook_event, [
				'topic_id'	=> (int) $row['topic_id'],
				'forum_id'	=> (int) $row['forum_id'],
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_set_post_visibility(data $event)
	{
		if ((int) $event['visibility'] !== ITEM_DELETED || $this->auth_resolver->is_api_request())
		{
			return;
		}

		$post_ids = is_array($event['post_id']) ? $event['post_id'] : [$event['post_id']];

		foreach ($post_ids as $post_id)
		{
			$this->webhooks->dispatch('post.soft_deleted', [
				'post_id'	=> (int) $post_id,
				'forum_id'	=> (int) $event['forum_id'],
				'reason'	=> text::plain($event['reason']),
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_set_topic_visibility(data $event)
	{
		if ((int) $event['visibility'] !== ITEM_DELETED || $this->auth_resolver->is_api_request())
		{
			return;
		}

		$this->webhooks->dispatch('topic.soft_deleted', [
			'topic_id'	=> (int) $event['topic_id'],
			'forum_id'	=> (int) $event['forum_id'],
			'reason'	=> text::plain($event['reason']),
		], 'ui');
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_approve_posts(data $event)
	{
		if ($this->auth_resolver->is_api_request())
		{
			return;
		}

		$webhook_event = $event['action'] === 'restore' ? 'post.restored' : 'post.approved';

		foreach ($event['post_info'] as $post_id => $row)
		{
			$this->webhooks->dispatch($webhook_event, [
				'post_id'	=> (int) $post_id,
				'forum_id'	=> (int) $row['forum_id'],
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_approve_topics(data $event)
	{
		if ($event['action'] !== 'restore' || $this->auth_resolver->is_api_request())
		{
			return;
		}

		foreach ($event['topic_info'] as $topic_id => $row)
		{
			$this->webhooks->dispatch('topic.restored', [
				'topic_id'	=> (int) $topic_id,
				'forum_id'	=> (int) $row['forum_id'],
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_disapprove_posts(data $event)
	{
		if (!$event['is_disapproving'] || $this->auth_resolver->is_api_request())
		{
			return;
		}

		foreach ($event['post_info'] as $post_id => $row)
		{
			$this->webhooks->dispatch('post.disapproved', [
				'post_id'	=> (int) $post_id,
				'forum_id'	=> (int) $row['forum_id'],
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_move_topics_before(data $event)
	{
		$sql = 'SELECT topic_id, forum_id FROM ' . TOPICS_TABLE . '
			WHERE ' . $this->db->sql_in_set('topic_id', array_map('intval', $event['topic_ids']));
		$result = $this->db->sql_query($sql);

		while ($row = $this->db->sql_fetchrow($result))
		{
			$this->pending_topic_forum_ids[(int) $row['topic_id']] = (int) $row['forum_id'];
		}
		$this->db->sql_freeresult($result);
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_move_topics_after(data $event)
	{
		$to_forum_id = (int) $event['forum_id'];
		$is_api_request = $this->auth_resolver->is_api_request();

		foreach ($event['topic_ids'] as $topic_id)
		{
			$topic_id = (int) $topic_id;
			$forum_id = $this->pending_topic_forum_ids[$topic_id] ?? $to_forum_id;
			unset($this->pending_topic_forum_ids[$topic_id]);

			if ($is_api_request)
			{
				continue;
			}

			$this->webhooks->dispatch('topic.moved', [
				'topic_id'		=> $topic_id,
				'forum_id'		=> $forum_id,
				'to_forum_id'	=> $to_forum_id,
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_mcp_topics_merge_posts(data $event)
	{
		if ($this->auth_resolver->is_api_request())
		{
			return;
		}

		$topic_id = (int) $event['topic_id'];

		$sql = 'SELECT forum_id FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$forum_id = (int) $this->db->sql_fetchfield('forum_id');
		$this->db->sql_freeresult($result);

		$this->webhooks->dispatch('topic.merged', [
			'topic_id'		=> $topic_id,
			'forum_id'		=> $forum_id,
			'to_topic_id'	=> (int) $event['to_topic_id'],
		], 'ui');
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_mcp_forum_merge_topics(data $event)
	{
		if ($this->auth_resolver->is_api_request())
		{
			return;
		}

		$to_topic_id = (int) $event['to_topic_id'];

		foreach ($event['all_topic_data'] as $topic_id => $row)
		{
			if ((int) $topic_id === $to_topic_id)
			{
				continue;
			}

			$this->webhooks->dispatch('topic.merged', [
				'topic_id'		=> (int) $topic_id,
				'forum_id'		=> (int) $row['forum_id'],
				'to_topic_id'	=> $to_topic_id,
			], 'ui');
		}
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_mcp_topic_split(data $event)
	{
		if ($this->auth_resolver->is_api_request())
		{
			return;
		}

		$new_topic_id = (int) $event['to_topic_id'];

		$sql = 'SELECT post_id FROM ' . POSTS_TABLE . '
			WHERE topic_id = ' . (int) $new_topic_id;
		$result = $this->db->sql_query($sql);
		$post_ids = array_map('intval', array_column($this->db->sql_fetchrowset($result), 'post_id'));
		$this->db->sql_freeresult($result);

		$this->webhooks->dispatch('topic.split', [
			'topic_id'		=> (int) $event['topic_id'],
			'forum_id'		=> (int) $event['topic_info']['forum_id'],
			'new_topic_id'	=> $new_topic_id,
			'to_forum_id'	=> (int) $event['to_forum_id'],
			'post_ids'		=> $post_ids,
		], 'ui');
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function on_user_add(data $event)
	{
		if ($this->auth_resolver->is_api_request())
		{
			return;
		}

		$this->webhooks->dispatch('member.registered', [
			'user_id'	=> (int) $event['user_id'],
			'username'	=> text::plain($event['user_row']['username']),
		], 'ui');
	}
}
