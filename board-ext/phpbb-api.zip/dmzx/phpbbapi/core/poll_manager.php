<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\content_visibility;
use phpbb\db\driver\driver_interface;
use phpbb\user;

class poll_manager
{
	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var content_visibility */
	protected $visibility;

	/** @var user */
	protected $user;

	/**
	 * @param driver_interface		$db
	 * @param auth					$auth
	 * @param content_visibility	$visibility
	 * @param user					$user
	 */
	public function __construct(driver_interface $db, auth $auth, content_visibility $visibility, user $user)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->visibility = $visibility;
		$this->user = $user;
	}

	/**
	 * @param int	$topic_id
	 * @param array	$option_ids
	 * @return array
	 */
	public function vote($topic_id, array $option_ids)
	{
		$topic = $this->load_topic($topic_id);
		$forum = $this->load_forum((int) $topic['forum_id']);
		$forum_id = (int) $forum['forum_id'];

		$options = $this->load_options((int) $topic['topic_id']);

		if (empty($options))
		{
			throw new api_exception('poll_not_found', 404);
		}

		if ((int) $topic['topic_status'] === ITEM_LOCKED || (int) $forum['forum_status'] === ITEM_LOCKED)
		{
			throw new api_exception('topic_locked', 403);
		}

		if (!$this->auth->acl_get('f_vote', $forum_id))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$poll_length = (int) $topic['poll_length'];

		if ($poll_length !== 0 && (int) $topic['poll_start'] + $poll_length <= time())
		{
			throw new api_exception('poll_closed', 403);
		}

		$current_votes = $this->load_current_votes((int) $topic['topic_id']);

		if (in_array(VOTE_CONVERTED, $current_votes, true))
		{
			throw new api_exception('vote_converted', 403);
		}

		if (!empty($current_votes) && !($this->auth->acl_get('f_votechg', $forum_id) && (int) $topic['poll_vote_change']))
		{
			throw new api_exception('vote_change_not_allowed', 403);
		}

		$option_ids = array_values(array_unique(array_map('intval', $option_ids)));

		if (empty($option_ids))
		{
			throw new api_exception('missing_fields', 400);
		}

		if (count($option_ids) > (int) $topic['poll_max_options'])
		{
			throw new api_exception('too_many_vote_options', 400);
		}

		$valid_option_ids = array_map('intval', array_column($options, 'poll_option_id'));

		if (count(array_diff($option_ids, $valid_option_ids)))
		{
			throw new api_exception('poll_option_not_found', 404);
		}

		foreach (array_diff($option_ids, $current_votes) as $option_id)
		{
			$this->db->sql_query('UPDATE ' . POLL_OPTIONS_TABLE . '
				SET poll_option_total = poll_option_total + 1
				WHERE poll_option_id = ' . (int) $option_id . '
					AND topic_id = ' . (int) $topic['topic_id']);

			$this->db->sql_query('INSERT INTO ' . POLL_VOTES_TABLE . ' ' . $this->db->sql_build_array('INSERT', [
				'topic_id'			=> (int) $topic['topic_id'],
				'poll_option_id'	=> (int) $option_id,
				'vote_user_id'		=> (int) $this->user->data['user_id'],
				'vote_user_ip'		=> (string) $this->user->ip,
			]));
		}

		foreach (array_diff($current_votes, $option_ids) as $option_id)
		{
			$this->db->sql_query('UPDATE ' . POLL_OPTIONS_TABLE . '
				SET poll_option_total = poll_option_total - 1
				WHERE poll_option_id = ' . (int) $option_id . '
					AND topic_id = ' . (int) $topic['topic_id']);

			$this->db->sql_query('DELETE FROM ' . POLL_VOTES_TABLE . '
				WHERE topic_id = ' . (int) $topic['topic_id'] . '
					AND poll_option_id = ' . (int) $option_id . '
					AND vote_user_id = ' . (int) $this->user->data['user_id']);
		}

		$this->db->sql_query('UPDATE ' . TOPICS_TABLE . '
			SET poll_last_vote = ' . time() . '
			WHERE topic_id = ' . (int) $topic['topic_id']);

		return ['your_votes' => $option_ids];
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function load_topic($topic_id)
	{
		$sql = 'SELECT * FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || !$this->visibility->is_visible('topic', (int) $row['forum_id'], $row))
		{
			throw new api_exception('topic_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param int	$forum_id
	 * @return array
	 */
	protected function load_forum($forum_id)
	{
		$sql = 'SELECT forum_id, forum_type, forum_password, forum_status
			FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . (int) $forum_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || (int) $row['forum_type'] !== FORUM_POST)
		{
			throw new api_exception('forum_not_found', 404);
		}

		if ($row['forum_password'] !== '')
		{
			throw new api_exception('forum_password_required', 403);
		}

		return $row;
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function load_options($topic_id)
	{
		$sql = 'SELECT poll_option_id FROM ' . POLL_OPTIONS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function load_current_votes($topic_id)
	{
		$sql = 'SELECT poll_option_id FROM ' . POLL_VOTES_TABLE . '
			WHERE topic_id = ' . (int) $topic_id . '
				AND vote_user_id = ' . (int) $this->user->data['user_id'];
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_map('intval', array_column($rows, 'poll_option_id'));
	}
}
