<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use phpbb\db\driver\driver_interface;

class credential_manager
{
	const TOKEN_PREFIX = 'pbapi_';
	const TOKEN_ROTATION_GRACE_SECONDS = 86400;
	const LAST_USED_RESOLUTION_SECONDS = 60;

	const SCOPES = [
		'forums.read',
		'topics.read',
		'topics.write',
		'topics.delete',
		'topics.moderate',
		'topics.vote',
		'topics.manage',
		'topics.watch',
		'posts.read',
		'posts.write',
		'posts.delete',
		'posts.attach',
		'posts.approve',
		'search.read',
		'members.read',
		'members.write',
		'members.ban',
		'messages.read',
		'messages.write',
		'reports.read',
		'reports.manage',
		'notifications.read',
		'stream.read',
	];

	/** @var driver_interface */
	protected $db;

	/** @var string */
	protected $credentials_table;

	/**
	 * @param driver_interface	$db
	 * @param string			$credentials_table
	 */
	public function __construct(driver_interface $db, $credentials_table)
	{
		$this->db = $db;
		$this->credentials_table = $credentials_table;
	}

	/**
	 * @param array	$data	name, user_id, scopes, forum_allowlist, ip_allowlist, rate_limit, rate_window, expires_time
	 * @return array	['credential' => array, 'token' => string]	The raw token is only ever available here
	 */
	public function create_credential(array $data)
	{
		$token = $this->generate_token();

		$sql_ary = [
			'name'				=> utf8_substr(trim((string) ($data['name'] ?? '')), 0, 100),
			'user_id'			=> (int) ($data['user_id'] ?? 0),
			'token_hash'		=> hash('sha256', $token),
			'token_prefix'		=> self::TOKEN_PREFIX . substr($token, strlen(self::TOKEN_PREFIX), 6),
			'scopes'			=> $this->encode_list($this->filter_scopes($data['scopes'] ?? [])),
			'forum_allowlist'	=> $this->encode_list($this->filter_ids($data['forum_allowlist'] ?? [])),
			'ip_allowlist'		=> $this->encode_list($this->filter_ips($data['ip_allowlist'] ?? [])),
			'rate_limit'		=> max(0, (int) ($data['rate_limit'] ?? 60)),
			'rate_window'		=> max(1, (int) ($data['rate_window'] ?? 3600)),
			'enabled'			=> 1,
			'expires_time'		=> max(0, (int) ($data['expires_time'] ?? 0)),
			'created_time'		=> time(),
			'last_used_time'	=> 0,
		];

		$sql = 'INSERT INTO ' . $this->credentials_table . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
		$this->db->sql_query($sql);

		$sql_ary['credential_id'] = (int) $this->db->sql_nextid();

		return ['credential' => $sql_ary, 'token' => $token];
	}

	/**
	 * @param int	$credential_id
	 * @param array	$data	name, scopes, forum_allowlist, ip_allowlist, rate_limit, rate_window, expires_time
	 * @return void
	 */
	public function update_credential($credential_id, array $data)
	{
		$sql_ary = [
			'name'				=> utf8_substr(trim((string) ($data['name'] ?? '')), 0, 100),
			'scopes'			=> $this->encode_list($this->filter_scopes($data['scopes'] ?? [])),
			'forum_allowlist'	=> $this->encode_list($this->filter_ids($data['forum_allowlist'] ?? [])),
			'ip_allowlist'		=> $this->encode_list($this->filter_ips($data['ip_allowlist'] ?? [])),
			'rate_limit'		=> max(0, (int) ($data['rate_limit'] ?? 60)),
			'rate_window'		=> max(1, (int) ($data['rate_window'] ?? 3600)),
			'expires_time'		=> max(0, (int) ($data['expires_time'] ?? 0)),
		];

		$sql = 'UPDATE ' . $this->credentials_table . '
			SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE credential_id = ' . (int) $credential_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$credential_id
	 * @return void
	 */
	public function delete_credential($credential_id)
	{
		$sql = 'DELETE FROM ' . $this->credentials_table . '
			WHERE credential_id = ' . (int) $credential_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$credential_id
	 * @param bool	$enabled
	 * @return void
	 */
	public function set_enabled($credential_id, $enabled)
	{
		$sql = 'UPDATE ' . $this->credentials_table . '
			SET enabled = ' . ($enabled ? 1 : 0) . '
			WHERE credential_id = ' . (int) $credential_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param int	$credential_id
	 * @return array|null
	 */
	public function get_credential($credential_id)
	{
		$sql = 'SELECT * FROM ' . $this->credentials_table . '
			WHERE credential_id = ' . (int) $credential_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		return $row ?: null;
	}

	/**
	 * @param string	$token
	 * @return array|null
	 */
	public function find_by_token($token)
	{
		$hash = hash('sha256', (string) $token);

		$sql = 'SELECT * FROM ' . $this->credentials_table . "
			WHERE token_hash = '" . $this->db->sql_escape($hash) . "'
				OR (previous_token_hash = '" . $this->db->sql_escape($hash) . "' AND previous_token_expires_time > " . time() . ')';
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		return $row ?: null;
	}

	/**
	 * @param int	$credential_id
	 * @return string|null	the new plaintext token, or null if the credential doesn't exist
	 */
	public function regenerate_token($credential_id)
	{
		$credential = $this->get_credential($credential_id);

		if ($credential === null)
		{
			return null;
		}

		$token = $this->generate_token();

		$sql_ary = [
			'token_hash'					=> hash('sha256', $token),
			'token_prefix'					=> self::TOKEN_PREFIX . substr($token, strlen(self::TOKEN_PREFIX), 6),
			'previous_token_hash'			=> $credential['token_hash'],
			'previous_token_expires_time'	=> time() + self::TOKEN_ROTATION_GRACE_SECONDS,
		];

		$sql = 'UPDATE ' . $this->credentials_table . '
			SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . '
			WHERE credential_id = ' . (int) $credential_id;
		$this->db->sql_query($sql);

		return $token;
	}

	/**
	 * @return array
	 */
	public function get_all_credentials()
	{
		$sql = 'SELECT * FROM ' . $this->credentials_table . '
			ORDER BY created_time DESC';
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param int	$credential_id
	 * @return void
	 */
	public function touch_last_used($credential_id)
	{
		$sql = 'UPDATE ' . $this->credentials_table . '
			SET last_used_time = ' . time() . '
			WHERE credential_id = ' . (int) $credential_id;
		$this->db->sql_query($sql);
	}

	/**
	 * @param array		$credential
	 * @param string	$scope
	 * @return bool
	 */
	public function has_scope(array $credential, $scope)
	{
		return in_array($scope, $this->decode_list($credential['scopes']), true);
	}

	/**
	 * @param array	$credential
	 * @param int	$forum_id
	 * @return bool
	 */
	public function is_forum_allowed(array $credential, $forum_id)
	{
		$allowlist = $this->decode_list($credential['forum_allowlist']);

		return empty($allowlist) || in_array((string) (int) $forum_id, $allowlist, true);
	}

	/**
	 * @param array		$credential
	 * @param string	$ip
	 * @return bool
	 */
	public function is_ip_allowed(array $credential, $ip)
	{
		$allowlist = $this->decode_list($credential['ip_allowlist']);

		return empty($allowlist) || in_array((string) $ip, $allowlist, true);
	}

	/**
	 * @param array	$credential
	 * @return array
	 */
	public function get_scopes(array $credential)
	{
		return $this->decode_list($credential['scopes']);
	}

	/**
	 * @param array	$credential
	 * @return array
	 */
	public function get_forum_allowlist(array $credential)
	{
		return array_map('intval', $this->decode_list($credential['forum_allowlist']));
	}

	/**
	 * @param array	$credential
	 * @return array
	 */
	public function get_ip_allowlist(array $credential)
	{
		return $this->decode_list($credential['ip_allowlist']);
	}

	/**
	 * @return string
	 */
	protected function generate_token()
	{
		return self::TOKEN_PREFIX . bin2hex(random_bytes(32));
	}

	/**
	 * @param mixed	$scopes
	 * @return array
	 */
	protected function filter_scopes($scopes)
	{
		$scopes = is_array($scopes) ? $scopes : [];

		return array_values(array_intersect($scopes, self::SCOPES));
	}

	/**
	 * @param mixed	$ids
	 * @return array
	 */
	protected function filter_ids($ids)
	{
		$ids = is_array($ids) ? $ids : [];
		$ids = array_map('intval', $ids);
		$ids = array_filter($ids, static function ($id) {
			return $id > 0;
		});

		return array_values(array_unique($ids));
	}

	/**
	 * @param mixed	$ips
	 * @return array
	 */
	protected function filter_ips($ips)
	{
		$ips = is_array($ips) ? $ips : [];
		$ips = array_filter($ips, static function ($ip) {
			return filter_var($ip, FILTER_VALIDATE_IP) !== false;
		});

		return array_values(array_unique($ips));
	}

	/**
	 * @param array	$values
	 * @return string
	 */
	protected function encode_list(array $values)
	{
		return implode(',', $values);
	}

	/**
	 * @param string	$value
	 * @return array
	 */
	protected function decode_list($value)
	{
		$value = trim((string) $value);

		return $value === '' ? [] : explode(',', $value);
	}
}
