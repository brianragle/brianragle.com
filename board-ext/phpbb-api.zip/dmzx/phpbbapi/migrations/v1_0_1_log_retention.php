<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\migrations;

class v1_0_1_log_retention extends \phpbb\db\migration\migration
{
	/**
	 * @return array
	 */
	public static function depends_on()
	{
		return ['\dmzx\phpbbapi\migrations\v1_0_1_unicode_columns'];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		return [
			['config.add', ['phpbbapi_log_retention_days', 30]],
			['config.add', ['phpbbapi_log_last_prune', 0]],
		];
	}

	/**
	 * @return array
	 */
	public function revert_data()
	{
		return [
			['config.remove', ['phpbbapi_log_last_prune']],
			['config.remove', ['phpbbapi_log_retention_days']],
		];
	}
}
