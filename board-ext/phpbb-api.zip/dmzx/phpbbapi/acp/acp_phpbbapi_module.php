<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\acp;

class acp_phpbbapi_module
{
	public $page_title;
	public $tpl_name;
	public $u_action;

	/**
	 * @param int		$id
	 * @param string	$mode
	 * @return void
	 */
	public function main($id, $mode)
	{
		global $phpbb_container;

		/** @var \dmzx\phpbbapi\controller\admin_controller $controller */
		$controller = $phpbb_container->get('dmzx.phpbbapi.admin.controller');

		$language = $phpbb_container->get('language');
		$language->add_lang('acp_phpbbapi', 'dmzx/phpbbapi');

		$controller->set_page_url($this->u_action);

		switch ($mode)
		{
			case 'credentials':
				$this->tpl_name = 'acp_phpbbapi_credentials';
				$this->page_title = 'ACP_PHPBBAPI_CREDENTIALS_TITLE';
				$controller->handle_credentials();
				break;

			case 'log':
				$this->tpl_name = 'acp_phpbbapi_log';
				$this->page_title = 'ACP_PHPBBAPI_LOG_TITLE';
				$controller->handle_log();
				break;

			case 'settings':
				$this->tpl_name = 'acp_phpbbapi_settings';
				$this->page_title = 'ACP_PHPBBAPI_SETTINGS_TITLE';
				$controller->handle_settings();
				break;

			case 'webhooks':
				$this->tpl_name = 'acp_phpbbapi_webhooks';
				$this->page_title = 'ACP_PHPBBAPI_WEBHOOKS_TITLE';
				$controller->handle_webhooks();
				break;

			case 'webhook_log':
				$this->tpl_name = 'acp_phpbbapi_webhook_log';
				$this->page_title = 'ACP_PHPBBAPI_WEBHOOK_LOG_TITLE';
				$controller->handle_webhook_log();
				break;

			default:
				$this->tpl_name = 'acp_phpbbapi_overview';
				$this->page_title = 'ACP_PHPBBAPI_OVERVIEW_TITLE';
				$controller->handle_overview();
				break;
		}
	}
}
