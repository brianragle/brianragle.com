<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\migrations;

class install_phpbbapi extends \phpbb\db\migration\migration
{
	/**
	 * @return array
	 */
	public static function depends_on()
	{
		return ['\phpbb\db\migration\data\v330\v330'];
	}

	/**
	 * @return array
	 */
	public function update_data()
	{
		return [
			['config.add', ['phpbbapi_enabled', 1]],
			['config.add', ['phpbbapi_require_https', 1]],
			['config.add', ['phpbbapi_cors_origins', '']],
			['config.add', ['phpbbapi_webhook_retry_last_gc', 0]],

			['permission.add', ['a_phpbbapi', true]],

			['module.add', ['acp', 'ACP_CAT_DOT_MODS', 'ACP_PHPBBAPI_TITLE']],
			['module.add', ['acp', 'ACP_PHPBBAPI_TITLE', [
				'module_basename'	=> '\dmzx\phpbbapi\acp\acp_phpbbapi_module',
				'modes'				=> ['overview', 'credentials', 'log', 'settings', 'webhooks', 'webhook_log'],
			]]],
		];
	}

	/**
	 * @return array
	 */
	public function revert_data()
	{
		return [
			['module.remove', ['acp', 'ACP_PHPBBAPI_TITLE', [
				'module_basename'	=> '\dmzx\phpbbapi\acp\acp_phpbbapi_module',
				'modes'				=> ['overview', 'credentials', 'log', 'settings', 'webhooks', 'webhook_log'],
			]]],
			['module.remove', ['acp', 'ACP_CAT_DOT_MODS', 'ACP_PHPBBAPI_TITLE']],

			['permission.remove', ['a_phpbbapi']],

			['config.remove', ['phpbbapi_webhook_retry_last_gc']],
			['config.remove', ['phpbbapi_cors_origins']],
			['config.remove', ['phpbbapi_require_https']],
			['config.remove', ['phpbbapi_enabled']],
		];
	}

	/**
	 * @return array
	 */
	public function update_schema()
	{
		return [
			'add_tables' => [
				$this->table_prefix . 'phpbbapi_credentials' => [
					'COLUMNS' => [
						'credential_id'		=> ['ULINT', null, 'auto_increment'],
						'name'					=> ['VCHAR_UNI:100', ''],
						'user_id'				=> ['UINT', 0],
						'token_hash'			=> ['VCHAR:64', ''],
						'token_prefix'			=> ['VCHAR:16', ''],
						'previous_token_hash'	=> ['VCHAR:64', ''],
						'previous_token_expires_time'	=> ['TIMESTAMP', 0],
						'scopes'				=> ['TEXT_UNI', ''],
						'forum_allowlist'		=> ['TEXT_UNI', ''],
						'ip_allowlist'			=> ['TEXT_UNI', ''],
						'rate_limit'			=> ['UINT', 60],
						'rate_window'			=> ['UINT', 3600],
						'enabled'				=> ['BOOL', 1],
						'expires_time'			=> ['TIMESTAMP', 0],
						'created_time'			=> ['TIMESTAMP', 0],
						'last_used_time'		=> ['TIMESTAMP', 0],
					],
					'PRIMARY_KEY' => 'credential_id',
					'KEYS' => [
						'token_hash'	=> ['UNIQUE', 'token_hash'],
						'user_id'		=> ['INDEX', 'user_id'],
					],
				],
				$this->table_prefix . 'phpbbapi_log' => [
					'COLUMNS' => [
						'log_id'			=> ['ULINT', null, 'auto_increment'],
						'credential_id'		=> ['UINT', 0],
						'user_id'			=> ['UINT', 0],
						'ip'				=> ['VCHAR:45', ''],
						'method'			=> ['VCHAR:10', ''],
						'route'				=> ['VCHAR:100', ''],
						'status'			=> ['USINT', 0],
						'error_code'		=> ['VCHAR:50', ''],
						'request_time'		=> ['TIMESTAMP', 0],
					],
					'PRIMARY_KEY' => 'log_id',
					'KEYS' => [
						'credential_id'	=> ['INDEX', 'credential_id'],
						'request_time'	=> ['INDEX', 'request_time'],
					],
				],
				$this->table_prefix . 'phpbbapi_webhooks' => [
					'COLUMNS' => [
						'webhook_id'			=> ['ULINT', null, 'auto_increment'],
						'name'					=> ['VCHAR_UNI:100', ''],
						'url'					=> ['TEXT_UNI', ''],
						'secret'				=> ['VCHAR:80', ''],
						'secret_prefix'			=> ['VCHAR:16', ''],
						'previous_secret'		=> ['VCHAR:80', ''],
						'previous_secret_expires_time'	=> ['TIMESTAMP', 0],
						'events'				=> ['TEXT_UNI', ''],
						'fire_on_ui_actions'	=> ['BOOL', 0],
						'enabled'				=> ['BOOL', 1],
						'created_time'			=> ['TIMESTAMP', 0],
						'last_triggered_time'	=> ['TIMESTAMP', 0],
						'failure_count'			=> ['UINT', 0],
					],
					'PRIMARY_KEY' => 'webhook_id',
				],
				$this->table_prefix . 'phpbbapi_webhook_log' => [
					'COLUMNS' => [
						'log_id'			=> ['ULINT', null, 'auto_increment'],
						'webhook_id'		=> ['UINT', 0],
						'event'				=> ['VCHAR:100', ''],
						'payload'			=> ['TEXT_UNI', ''],
						'status_code'		=> ['USINT', 0],
						'success'			=> ['BOOL', 0],
						'response_snippet'	=> ['VCHAR_UNI:255', ''],
						'retry_count'		=> ['UINT', 0],
						'next_retry_time'	=> ['TIMESTAMP', 0],
						'request_time'		=> ['TIMESTAMP', 0],
					],
					'PRIMARY_KEY' => 'log_id',
					'KEYS' => [
						'webhook_id'	=> ['INDEX', 'webhook_id'],
						'request_time'	=> ['INDEX', 'request_time'],
						'retry_due'		=> ['INDEX', ['success', 'next_retry_time']],
					],
				],
			],
		];
	}

	/**
	 * @return array
	 */
	public function revert_schema()
	{
		return [
			'drop_tables' => [
				$this->table_prefix . 'phpbbapi_credentials',
				$this->table_prefix . 'phpbbapi_log',
				$this->table_prefix . 'phpbbapi_webhooks',
				$this->table_prefix . 'phpbbapi_webhook_log',
			],
		];
	}
}
