<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\db\driver\driver_interface;
use phpbb\request\request;
use phpbb\user;

class auth_resolver
{
	/** @var credential_manager */
	protected $credential_manager;

	/** @var driver_interface */
	protected $db;

	/** @var user */
	protected $user;

	/** @var auth */
	protected $auth;

	/** @var config */
	protected $config;

	/** @var request */
	protected $request;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/** @var bool */
	protected $resolved = false;

	/**
	 * @param credential_manager	$credential_manager
	 * @param driver_interface		$db
	 * @param user					$user
	 * @param auth					$auth
	 * @param config				$config
	 * @param request				$request
	 * @param string				$root_path
	 * @param string				$php_ext
	 */
	public function __construct(credential_manager $credential_manager, driver_interface $db, user $user, auth $auth, config $config, request $request, $root_path, $php_ext)
	{
		$this->credential_manager = $credential_manager;
		$this->db = $db;
		$this->user = $user;
		$this->auth = $auth;
		$this->config = $config;
		$this->request = $request;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	/**
	 * @param bool	$allow_query_token	accept ?access_token= as well - only the SSE stream route, EventSource cannot send headers
	 * @return array	the resolved credential row
	 */
	public function resolve($allow_query_token = false)
	{
		if (!(int) $this->config['phpbbapi_enabled'])
		{
			throw new api_exception('api_disabled', 503);
		}

		if ((int) $this->config['phpbbapi_require_https'] && !$this->request->is_secure())
		{
			throw new api_exception('https_required', 403);
		}

		$token = $this->extract_token($allow_query_token);

		if ($token === '')
		{
			throw new api_exception('missing_token', 401);
		}

		$credential = $this->credential_manager->find_by_token($token);

		if ($credential === null)
		{
			throw new api_exception('invalid_token', 401);
		}

		if (!(int) $credential['enabled'])
		{
			throw new api_exception('credential_disabled', 403);
		}

		if ((int) $credential['expires_time'] > 0 && (int) $credential['expires_time'] < time())
		{
			throw new api_exception('credential_expired', 403);
		}

		if (!$this->credential_manager->is_ip_allowed($credential, (string) $this->request->server('REMOTE_ADDR')))
		{
			throw new api_exception('ip_not_allowed', 403);
		}

		$user_row = $this->load_user((int) $credential['user_id']);

		if ($user_row === null)
		{
			throw new api_exception('account_unavailable', 403);
		}

		if ($this->is_banned($user_row))
		{
			throw new api_exception('account_banned', 403);
		}

		$this->impersonate($user_row);

		if (time() - (int) $credential['last_used_time'] >= credential_manager::LAST_USED_RESOLUTION_SECONDS)
		{
			$this->credential_manager->touch_last_used((int) $credential['credential_id']);
		}

		$this->resolved = true;

		return $credential;
	}

	/**
	 * @return bool
	 */
	public function is_api_request()
	{
		if ($this->resolved)
		{
			return true;
		}

		$token = $this->extract_token(false);

		return $token !== '' && $this->credential_manager->find_by_token($token) !== null;
	}

	/**
	 * @param bool	$allow_query_token
	 * @return string
	 */
	protected function extract_token($allow_query_token)
	{
		$header = (string) $this->request->server('HTTP_AUTHORIZATION');

		if ($header === '')
		{
			$header = (string) $this->request->server('REDIRECT_HTTP_AUTHORIZATION');
		}

		if ($header !== '' && stripos($header, 'Bearer ') === 0)
		{
			return trim(substr($header, 7));
		}

		$api_key = trim((string) $this->request->server('HTTP_X_API_KEY'));

		if ($api_key !== '' || !$allow_query_token)
		{
			return $api_key;
		}

		return trim($this->request->variable('access_token', '', false, \phpbb\request\request_interface::GET));
	}

	/**
	 * @param int	$user_id
	 * @return array|null
	 */
	protected function load_user($user_id)
	{
		if ($user_id <= 0)
		{
			return null;
		}

		$sql = 'SELECT * FROM ' . USERS_TABLE . '
			WHERE user_id = ' . (int) $user_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || in_array((int) $row['user_type'], [USER_INACTIVE, USER_IGNORE], true))
		{
			return null;
		}

		return $row;
	}

	/**
	 * @param array	$user_row
	 * @return bool	user, IP and e-mail bans, the same check session_begin() runs for a browser session
	 */
	protected function is_banned(array $user_row)
	{
		return (bool) $this->user->check_ban((int) $user_row['user_id'], $this->user->ip, (string) $user_row['user_email'], true);
	}

	/**
	 * @param array	$user_row
	 * @return void
	 */
	protected function impersonate(array $user_row)
	{
		$user_row['is_registered'] = in_array((int) $user_row['user_type'], [USER_NORMAL, USER_FOUNDER], true);
		$user_row['is_bot'] = false;

		$this->user->data = array_merge((array) $this->user->data, $user_row);
		$this->auth->acl($this->user->data);
	}
}
