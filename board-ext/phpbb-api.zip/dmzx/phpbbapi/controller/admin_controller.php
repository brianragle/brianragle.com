<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\controller;

use dmzx\phpbbapi\core\audit_logger;
use dmzx\phpbbapi\core\credential_manager;
use dmzx\phpbbapi\core\webhook_dispatcher;
use dmzx\phpbbapi\core\webhook_manager;
use phpbb\config\config;
use phpbb\db\driver\driver_interface;
use phpbb\language\language;
use phpbb\log\log;
use phpbb\pagination;
use phpbb\request\request;
use phpbb\template\template;
use phpbb\user;
use phpbb\user_loader;

class admin_controller
{
	const LOG_PER_PAGE = 50;

	/** @var credential_manager */
	protected $credential_manager;

	/** @var audit_logger */
	protected $audit_logger;

	/** @var webhook_manager */
	protected $webhook_manager;

	/** @var webhook_dispatcher */
	protected $webhook_dispatcher;

	/** @var driver_interface */
	protected $db;

	/** @var config */
	protected $config;

	/** @var request */
	protected $request;

	/** @var template */
	protected $template;

	/** @var language */
	protected $language;

	/** @var user */
	protected $user;

	/** @var user_loader */
	protected $user_loader;

	/** @var pagination */
	protected $pagination;

	/** @var log */
	protected $log;

	/** @var string */
	protected $u_action;

	/**
	 * @param credential_manager	$credential_manager
	 * @param audit_logger			$audit_logger
	 * @param webhook_manager		$webhook_manager
	 * @param webhook_dispatcher	$webhook_dispatcher
	 * @param driver_interface		$db
	 * @param config				$config
	 * @param request				$request
	 * @param template				$template
	 * @param language				$language
	 * @param user					$user
	 * @param user_loader			$user_loader
	 * @param pagination			$pagination
	 * @param log					$log
	 */
	public function __construct(credential_manager $credential_manager, audit_logger $audit_logger, webhook_manager $webhook_manager, webhook_dispatcher $webhook_dispatcher, driver_interface $db, config $config, request $request, template $template, language $language, user $user, user_loader $user_loader, pagination $pagination, log $log)
	{
		$this->credential_manager = $credential_manager;
		$this->audit_logger = $audit_logger;
		$this->webhook_manager = $webhook_manager;
		$this->webhook_dispatcher = $webhook_dispatcher;
		$this->db = $db;
		$this->config = $config;
		$this->request = $request;
		$this->template = $template;
		$this->language = $language;
		$this->user = $user;
		$this->user_loader = $user_loader;
		$this->pagination = $pagination;
		$this->log = $log;
	}

	/**
	 * @param string	$u_action
	 * @return void
	 */
	public function set_page_url($u_action)
	{
		$this->u_action = $u_action;
	}

	/**
	 * @return void
	 */
	public function handle_credentials()
	{
		add_form_key('phpbbapi_credentials');

		$action = $this->request->variable('action', '');
		$credential_id = $this->request->variable('credential_id', 0);

		if (($action === 'create' || $action === 'update') && $this->request->is_set_post('submit'))
		{
			if (!check_form_key('phpbbapi_credentials'))
			{
				trigger_error('FORM_INVALID', E_USER_WARNING);
			}

			if ($action === 'update' && $credential_id)
			{
				$this->process_update($credential_id);
			}
			else
			{
				$this->process_create();
			}

			return;
		}

		if ($action === 'toggle' && $credential_id)
		{
			$this->process_toggle($credential_id);

			return;
		}

		if ($action === 'regenerate' && $credential_id)
		{
			$this->process_regenerate($credential_id);

			return;
		}

		if ($action === 'delete' && $credential_id)
		{
			$this->process_delete($credential_id);

			return;
		}

		$editing = null;

		if ($action === 'edit' && $credential_id)
		{
			$editing = $this->credential_manager->get_credential($credential_id);
		}

		$this->display_credentials('', '', '', $editing);
	}

	/**
	 * @return void
	 */
	public function handle_log()
	{
		$start = max(0, $this->request->variable('start', 0));
		$total = $this->audit_logger->count_entries();
		$entries = $this->audit_logger->get_entries($start, self::LOG_PER_PAGE);

		$user_ids = array_filter(array_map('intval', array_column($entries, 'user_id')));
		$this->user_loader->load_users($user_ids);

		foreach ($entries as $row)
		{
			$this->template->assign_block_vars('log', [
				'TIME'			=> $this->user->format_date((int) $row['request_time']),
				'USERNAME'		=> (int) $row['user_id'] > 0 ? $this->user_loader->get_username((int) $row['user_id'], 'username') : '-',
				'IP'			=> $row['ip'],
				'METHOD'		=> $row['method'],
				'METHOD_CLASS'	=> $this->method_class($row['method']),
				'ROUTE'			=> $row['route'],
				'STATUS'		=> (int) $row['status'],
				'STATUS_CLASS'	=> $this->status_class((int) $row['status']),
				'ERROR_CODE'	=> $row['error_code'],
				'S_ERROR'		=> $row['error_code'] !== '',
			]);
		}

		$this->pagination->generate_template_pagination($this->u_action, 'pagination', 'start', $total, self::LOG_PER_PAGE, $start);

		$this->template->assign_vars([
			'U_ACTION'		=> $this->u_action,
			'S_HAS_LOG'		=> !empty($entries),
			'LOG_TOTAL'		=> $total,
		]);
	}

	/**
	 * @return void
	 */
	public function handle_overview()
	{
		$credentials = $this->credential_manager->get_all_credentials();
		$enabled = count(array_filter($credentials, static function ($row) {
			return (int) $row['enabled'] === 1;
		}));

		$since = time() - 86400;
		$requests_24h = $this->audit_logger->count_since($since);
		$errors_24h = $this->audit_logger->count_errors_since($since);
		$error_rate = $requests_24h > 0 ? round(($errors_24h / $requests_24h) * 100, 1) : 0;

		$top_routes = $this->audit_logger->top_routes($since, 5);

		foreach ($top_routes as $row)
		{
			$this->template->assign_block_vars('top_routes', [
				'ROUTE'	=> $row['route'],
				'HITS'	=> (int) $row['hits'],
			]);
		}

		$this->template->assign_vars([
			'U_ACTION'			=> $this->u_action,
			'CRED_TOTAL'		=> count($credentials),
			'CRED_ENABLED'		=> $enabled,
			'CRED_DISABLED'		=> count($credentials) - $enabled,
			'REQUESTS_24H'		=> $requests_24h,
			'ERRORS_24H'		=> $errors_24h,
			'ERROR_RATE'		=> $error_rate,
			'S_HAS_TOP_ROUTES'	=> !empty($top_routes),
		]);
	}

	/**
	 * @return void
	 */
	public function handle_settings()
	{
		add_form_key('phpbbapi_settings');

		if ($this->request->is_set_post('submit'))
		{
			if (!check_form_key('phpbbapi_settings'))
			{
				trigger_error('FORM_INVALID', E_USER_WARNING);
			}

			$this->config->set('phpbbapi_enabled', $this->request->variable('enabled', false) ? 1 : 0);
			$this->config->set('phpbbapi_require_https', $this->request->variable('require_https', false) ? 1 : 0);
			$this->config->set('phpbbapi_cors_origins', $this->request->variable('cors_origins', '', true));
			$this->config->set('phpbbapi_log_retention_days', max(0, $this->request->variable('log_retention_days', 30)));

			$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_SETTINGS_SAVED');

			trigger_error($this->language->lang('PHPBBAPI_SETTINGS_SAVED') . adm_back_link($this->u_action));
		}

		$this->template->assign_vars([
			'U_ACTION'			=> $this->u_action,
			'S_ENABLED'			=> (bool) $this->config['phpbbapi_enabled'],
			'S_REQUIRE_HTTPS'	=> (bool) $this->config['phpbbapi_require_https'],
			'CORS_ORIGINS'		=> (string) $this->config['phpbbapi_cors_origins'],
			'LOG_RETENTION_DAYS'	=> (int) $this->config['phpbbapi_log_retention_days'],
		]);
	}

	/**
	 * @return void
	 */
	public function handle_webhooks()
	{
		add_form_key('phpbbapi_webhooks');

		$action = $this->request->variable('action', '');
		$webhook_id = $this->request->variable('webhook_id', 0);

		if (($action === 'create' || $action === 'update') && $this->request->is_set_post('submit'))
		{
			if (!check_form_key('phpbbapi_webhooks'))
			{
				trigger_error('FORM_INVALID', E_USER_WARNING);
			}

			if ($action === 'update' && $webhook_id)
			{
				$this->process_update_webhook($webhook_id);
			}
			else
			{
				$this->process_create_webhook();
			}

			return;
		}

		if ($action === 'toggle' && $webhook_id)
		{
			$this->process_toggle_webhook($webhook_id);

			return;
		}

		if ($action === 'regenerate_secret' && $webhook_id)
		{
			$this->process_regenerate_secret($webhook_id);

			return;
		}

		if ($action === 'delete' && $webhook_id)
		{
			$this->process_delete_webhook($webhook_id);

			return;
		}

		$editing = null;

		if ($action === 'edit' && $webhook_id)
		{
			$editing = $this->webhook_manager->get_webhook($webhook_id);
		}

		$this->display_webhooks('', '', '', $editing);
	}

	/**
	 * @return void
	 */
	public function handle_webhook_log()
	{
		$start = max(0, $this->request->variable('start', 0));
		$total = $this->webhook_dispatcher->count_log_entries();
		$entries = $this->webhook_dispatcher->get_log_entries($start, self::LOG_PER_PAGE);

		$webhook_names = array_column($this->webhook_manager->get_all_webhooks(), 'name', 'webhook_id');
		$max_retries = count(webhook_dispatcher::RETRY_BACKOFF);

		foreach ($entries as $row)
		{
			$webhook_id = (int) $row['webhook_id'];
			$success = (bool) $row['success'];
			$pending_retry = !$success && (int) $row['next_retry_time'] > 0;

			$this->template->assign_block_vars('log', [
				'TIME'				=> $this->user->format_date((int) $row['request_time']),
				'WEBHOOK_NAME'		=> $webhook_names[$webhook_id] ?? ('#' . $webhook_id),
				'EVENT'				=> $row['event'],
				'EVENT_CLASS'		=> $this->event_class($row['event']),
				'STATUS'			=> (int) $row['status_code'] > 0 ? (int) $row['status_code'] : '-',
				'S_SUCCESS'			=> $success,
				'RETRY_COUNT'		=> (int) $row['retry_count'] + 1,
				'MAX_RETRIES'		=> $max_retries,
				'S_PENDING_RETRY'	=> $pending_retry,
				'S_EXHAUSTED'		=> !$success && !$pending_retry,
				'NEXT_RETRY'		=> $pending_retry ? $this->user->format_date((int) $row['next_retry_time']) : '',
				'RESPONSE'			=> $row['response_snippet'],
			]);
		}

		$this->pagination->generate_template_pagination($this->u_action, 'pagination', 'start', $total, self::LOG_PER_PAGE, $start);

		$this->template->assign_vars([
			'U_ACTION'	=> $this->u_action,
			'S_HAS_LOG'	=> !empty($entries),
			'LOG_TOTAL'	=> $total,
		]);
	}

	/**
	 * @return void
	 */
	protected function process_create()
	{
		$username = $this->request->variable('username', '', true);
		$bound_user = $this->resolve_bindable_user($username);

		if (!is_array($bound_user))
		{
			$this->display_credentials($this->language->lang($bound_user));

			return;
		}

		$user_id = (int) $bound_user['user_id'];

		$scopes = $this->request->variable('scopes', ['']);
		$forum_allowlist = $this->request->variable('forum_allowlist', [0]);
		$ip_allowlist = array_filter(array_map('trim', explode(',', $this->request->variable('ip_allowlist', ''))));
		$expires = $this->request->variable('expires', '');
		$expires_time = $expires !== '' ? (int) strtotime($expires . ' 23:59:59') : 0;

		$result = $this->credential_manager->create_credential([
			'name'				=> $this->request->variable('name', '', true),
			'user_id'			=> $user_id,
			'scopes'			=> $scopes,
			'forum_allowlist'	=> $forum_allowlist,
			'ip_allowlist'		=> $ip_allowlist,
			'rate_limit'		=> $this->request->variable('rate_limit', 60),
			'rate_window'		=> $this->request->variable('rate_window', 3600),
			'expires_time'		=> $expires_time,
		]);

		$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_CREDENTIAL_CREATED', false, [$result['credential']['name']]);

		$this->display_credentials('', $result['token'], $result['credential']['name']);
	}

	/**
	 * @param int	$credential_id
	 * @return void
	 */
	protected function process_update($credential_id)
	{
		$credential = $this->credential_manager->get_credential($credential_id);

		if ($credential === null)
		{
			$this->display_credentials();

			return;
		}

		$scopes = $this->request->variable('scopes', ['']);
		$forum_allowlist = $this->request->variable('forum_allowlist', [0]);
		$ip_allowlist = array_filter(array_map('trim', explode(',', $this->request->variable('ip_allowlist', ''))));
		$expires = $this->request->variable('expires', '');
		$expires_time = $expires !== '' ? (int) strtotime($expires . ' 23:59:59') : 0;

		$this->credential_manager->update_credential($credential_id, [
			'name'				=> $this->request->variable('name', '', true),
			'scopes'			=> $scopes,
			'forum_allowlist'	=> $forum_allowlist,
			'ip_allowlist'		=> $ip_allowlist,
			'rate_limit'		=> $this->request->variable('rate_limit', 60),
			'rate_window'		=> $this->request->variable('rate_window', 3600),
			'expires_time'		=> $expires_time,
		]);

		$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_CREDENTIAL_UPDATED', false, [$credential['name']]);

		trigger_error($this->language->lang('PHPBBAPI_CREDENTIAL_SAVED') . adm_back_link($this->u_action));
	}

	/**
	 * @param int	$credential_id
	 * @return void
	 */
	protected function process_toggle($credential_id)
	{
		if (confirm_box(true))
		{
			$credential = $this->credential_manager->get_credential($credential_id);

			if ($credential !== null)
			{
				$this->credential_manager->set_enabled($credential_id, !$credential['enabled']);

				$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_CREDENTIAL_TOGGLED', false, [$credential['name']]);
			}

			trigger_error($this->language->lang('PHPBBAPI_CREDENTIAL_UPDATED') . adm_back_link($this->u_action));
		}
		else
		{
			confirm_box(false, $this->language->lang('PHPBBAPI_CONFIRM_TOGGLE'), build_hidden_fields([
				'action'			=> 'toggle',
				'credential_id'		=> $credential_id,
			]));
		}
	}

	/**
	 * @param int	$credential_id
	 * @return void
	 */
	protected function process_regenerate($credential_id)
	{
		if (confirm_box(true))
		{
			$credential = $this->credential_manager->get_credential($credential_id);

			if ($credential === null)
			{
				$this->display_credentials();

				return;
			}

			$token = $this->credential_manager->regenerate_token($credential_id);

			$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_CREDENTIAL_REGENERATED', false, [$credential['name']]);

			$this->display_credentials('', $token, $credential['name']);
		}
		else
		{
			confirm_box(false, $this->language->lang('PHPBBAPI_CONFIRM_REGENERATE'), build_hidden_fields([
				'action'			=> 'regenerate',
				'credential_id'		=> $credential_id,
			]));
		}
	}

	/**
	 * @param int	$credential_id
	 * @return void
	 */
	protected function process_delete($credential_id)
	{
		if (confirm_box(true))
		{
			$credential = $this->credential_manager->get_credential($credential_id);

			if ($credential !== null)
			{
				$this->credential_manager->delete_credential($credential_id);

				$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_CREDENTIAL_DELETED', false, [$credential['name']]);
			}

			trigger_error($this->language->lang('PHPBBAPI_CREDENTIAL_DELETED') . adm_back_link($this->u_action));
		}
		else
		{
			confirm_box(false, $this->language->lang('PHPBBAPI_CONFIRM_DELETE'), build_hidden_fields([
				'action'			=> 'delete',
				'credential_id'		=> $credential_id,
			]));
		}
	}

	/**
	 * @param string	$error
	 * @param string	$new_token
	 * @param string	$new_token_name
	 * @param array|null	$editing
	 * @return void
	 */
	protected function display_credentials($error = '', $new_token = '', $new_token_name = '', ?array $editing = null)
	{
		$credentials = $this->credential_manager->get_all_credentials();

		$user_ids = array_map('intval', array_column($credentials, 'user_id'));
		$this->user_loader->load_users($user_ids);

		$forums = $this->list_all_forums();
		$forum_names = array_column($forums, 'forum_name', 'forum_id');

		foreach ($credentials as $row)
		{
			$this->template->assign_block_vars('credentials', [
				'CREDENTIAL_ID'	=> (int) $row['credential_id'],
				'NAME'			=> $row['name'],
				'USERNAME'		=> $this->user_loader->get_username((int) $row['user_id'], 'username'),
				'TOKEN_PREFIX'	=> $row['token_prefix'] . '...',
				'RATE_LIMIT'	=> (int) $row['rate_limit'],
				'S_ENABLED'		=> (bool) $row['enabled'],
				'EXPIRES'		=> (int) $row['expires_time'] > 0 ? $this->user->format_date((int) $row['expires_time']) : $this->language->lang('PHPBBAPI_NEVER'),
				'LAST_USED'		=> (int) $row['last_used_time'] > 0 ? $this->user->format_date((int) $row['last_used_time']) : $this->language->lang('PHPBBAPI_NEVER'),
				'U_EDIT'		=> $this->u_action . '&amp;action=edit&amp;credential_id=' . (int) $row['credential_id'],
				'U_TOGGLE'		=> $this->u_action . '&amp;action=toggle&amp;credential_id=' . (int) $row['credential_id'],
				'U_REGENERATE'	=> $this->u_action . '&amp;action=regenerate&amp;credential_id=' . (int) $row['credential_id'],
				'U_DELETE'		=> $this->u_action . '&amp;action=delete&amp;credential_id=' . (int) $row['credential_id'],
				'S_GRACE_ACTIVE'	=> (int) $row['previous_token_expires_time'] > time(),
				'GRACE_UNTIL'		=> (int) $row['previous_token_expires_time'] > time() ? $this->user->format_date((int) $row['previous_token_expires_time']) : '',
			]);

			foreach ($this->credential_manager->get_scopes($row) as $scope)
			{
				$this->template->assign_block_vars('credentials.scope_badges', [
					'VALUE'	=> $scope,
					'CLASS'	=> $this->scope_class($scope),
				]);
			}

			$allowed_forums = $this->credential_manager->get_forum_allowlist($row);

			if (empty($allowed_forums))
			{
				$this->template->assign_block_vars('credentials.forum_badges', [
					'VALUE'	=> $this->language->lang('PHPBBAPI_ALL_FORUMS'),
					'S_ALL'	=> true,
				]);
			}
			else
			{
				foreach ($allowed_forums as $forum_id)
				{
					$this->template->assign_block_vars('credentials.forum_badges', [
						'VALUE'	=> $forum_names[$forum_id] ?? ('#' . $forum_id),
						'S_ALL'	=> false,
					]);
				}
			}
		}

		$editing_scopes = $editing !== null ? $this->credential_manager->get_scopes($editing) : [];
		$editing_forums = $editing !== null ? $this->credential_manager->get_forum_allowlist($editing) : [];

		foreach (credential_manager::SCOPES as $scope)
		{
			$this->template->assign_block_vars('scopes', [
				'VALUE'		=> $scope,
				'S_CHECKED'	=> in_array($scope, $editing_scopes, true),
			]);
		}

		foreach ($forums as $forum)
		{
			$this->template->assign_block_vars('forum_options', [
				'VALUE'		=> (int) $forum['forum_id'],
				'LABEL'		=> $forum['forum_name'],
				'S_CHECKED'	=> in_array((int) $forum['forum_id'], $editing_forums, true),
			]);
		}

		$this->template->assign_vars([
			'U_ACTION'			=> $this->u_action,
			'S_HAS_CREDENTIALS'	=> !empty($credentials),
			'ERROR'				=> $error,
			'S_ERROR'			=> $error !== '',
			'S_NEW_TOKEN'		=> $new_token !== '',
			'NEW_TOKEN'			=> $new_token,
			'NEW_TOKEN_NAME'	=> $new_token_name,
			'S_EDITING'			=> $editing !== null,
			'EDIT_CREDENTIAL_ID'	=> $editing !== null ? (int) $editing['credential_id'] : 0,
			'EDIT_NAME'			=> $editing !== null ? $editing['name'] : '',
			'EDIT_USERNAME'		=> $editing !== null ? $this->user_loader->get_username((int) $editing['user_id'], 'username') : '',
			'EDIT_IP_ALLOWLIST'	=> $editing !== null ? implode(', ', $this->credential_manager->get_ip_allowlist($editing)) : '',
			'EDIT_RATE_LIMIT'	=> $editing !== null ? (int) $editing['rate_limit'] : 60,
			'EDIT_RATE_WINDOW'	=> $editing !== null ? (int) $editing['rate_window'] : 3600,
			'EDIT_EXPIRES'		=> $editing !== null && (int) $editing['expires_time'] > 0 ? date('Y-m-d', (int) $editing['expires_time']) : '',
			'U_CANCEL_EDIT'		=> $this->u_action,
		]);
	}

	/**
	 * @param string	$url
	 * @return bool
	 */
	protected function is_https_url($url)
	{
		return filter_var($url, FILTER_VALIDATE_URL) !== false
			&& strtolower((string) parse_url($url, PHP_URL_SCHEME)) === 'https'
			&& (string) parse_url($url, PHP_URL_HOST) !== '';
	}

	/**
	 * @return void
	 */
	protected function process_create_webhook()
	{
		$url = html_entity_decode($this->request->variable('url', '', true), ENT_QUOTES | ENT_HTML5, 'UTF-8');

		if (!$this->is_https_url($url))
		{
			$this->display_webhooks($this->language->lang('PHPBBAPI_WEBHOOK_URL_INVALID'));

			return;
		}

		$events = $this->request->variable('events', ['']);

		$result = $this->webhook_manager->create_webhook([
			'name'					=> $this->request->variable('name', '', true),
			'url'					=> $url,
			'events'				=> $events,
			'fire_on_ui_actions'	=> $this->request->variable('fire_on_ui_actions', false),
		]);

		$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_WEBHOOK_CREATED', false, [$result['webhook']['name']]);

		$this->display_webhooks('', $result['secret'], $result['webhook']['name']);
	}

	/**
	 * @param int	$webhook_id
	 * @return void
	 */
	protected function process_update_webhook($webhook_id)
	{
		$webhook = $this->webhook_manager->get_webhook($webhook_id);

		if ($webhook === null)
		{
			$this->display_webhooks();

			return;
		}

		$url = html_entity_decode($this->request->variable('url', '', true), ENT_QUOTES | ENT_HTML5, 'UTF-8');

		if (!$this->is_https_url($url))
		{
			$this->display_webhooks($this->language->lang('PHPBBAPI_WEBHOOK_URL_INVALID'));

			return;
		}

		$events = $this->request->variable('events', ['']);

		$this->webhook_manager->update_webhook($webhook_id, [
			'name'					=> $this->request->variable('name', '', true),
			'url'					=> $url,
			'events'				=> $events,
			'fire_on_ui_actions'	=> $this->request->variable('fire_on_ui_actions', false),
		]);

		$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_WEBHOOK_UPDATED', false, [$webhook['name']]);

		trigger_error($this->language->lang('PHPBBAPI_WEBHOOK_SAVED') . adm_back_link($this->u_action));
	}

	/**
	 * @param int	$webhook_id
	 * @return void
	 */
	protected function process_toggle_webhook($webhook_id)
	{
		if (confirm_box(true))
		{
			$webhook = $this->webhook_manager->get_webhook($webhook_id);

			if ($webhook !== null)
			{
				$this->webhook_manager->set_enabled($webhook_id, !$webhook['enabled']);

				$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_WEBHOOK_TOGGLED', false, [$webhook['name']]);
			}

			trigger_error($this->language->lang('PHPBBAPI_WEBHOOK_UPDATED') . adm_back_link($this->u_action));
		}
		else
		{
			confirm_box(false, $this->language->lang('PHPBBAPI_CONFIRM_TOGGLE_WEBHOOK'), build_hidden_fields([
				'action'		=> 'toggle',
				'webhook_id'	=> $webhook_id,
			]));
		}
	}

	/**
	 * @param int	$webhook_id
	 * @return void
	 */
	protected function process_regenerate_secret($webhook_id)
	{
		if (confirm_box(true))
		{
			$webhook = $this->webhook_manager->get_webhook($webhook_id);

			if ($webhook === null)
			{
				$this->display_webhooks();

				return;
			}

			$secret = $this->webhook_manager->regenerate_secret($webhook_id);

			$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_WEBHOOK_SECRET_REGENERATED', false, [$webhook['name']]);

			$this->display_webhooks('', $secret, $webhook['name']);
		}
		else
		{
			confirm_box(false, $this->language->lang('PHPBBAPI_CONFIRM_REGENERATE_WEBHOOK'), build_hidden_fields([
				'action'		=> 'regenerate_secret',
				'webhook_id'	=> $webhook_id,
			]));
		}
	}

	/**
	 * @param int	$webhook_id
	 * @return void
	 */
	protected function process_delete_webhook($webhook_id)
	{
		if (confirm_box(true))
		{
			$webhook = $this->webhook_manager->get_webhook($webhook_id);

			if ($webhook !== null)
			{
				$this->webhook_manager->delete_webhook($webhook_id);

				$this->log->add('admin', $this->user->data['user_id'], $this->user->data['user_ip'], 'LOG_PHPBBAPI_WEBHOOK_DELETED', false, [$webhook['name']]);
			}

			trigger_error($this->language->lang('PHPBBAPI_WEBHOOK_DELETED') . adm_back_link($this->u_action));
		}
		else
		{
			confirm_box(false, $this->language->lang('PHPBBAPI_CONFIRM_DELETE_WEBHOOK'), build_hidden_fields([
				'action'		=> 'delete',
				'webhook_id'	=> $webhook_id,
			]));
		}
	}

	/**
	 * @param string		$error
	 * @param string		$new_secret
	 * @param string		$new_secret_name
	 * @param array|null	$editing
	 * @return void
	 */
	protected function display_webhooks($error = '', $new_secret = '', $new_secret_name = '', ?array $editing = null)
	{
		$webhooks = $this->webhook_manager->get_all_webhooks();

		foreach ($webhooks as $row)
		{
			$this->template->assign_block_vars('webhooks', [
				'WEBHOOK_ID'	=> (int) $row['webhook_id'],
				'NAME'			=> $row['name'],
				'URL'			=> $row['url'],
				'SECRET_PREFIX'	=> $row['secret_prefix'] . '...',
				'FAILURE_COUNT'	=> (int) $row['failure_count'],
				'S_ENABLED'		=> (bool) $row['enabled'],
				'S_FIRE_ON_UI_ACTIONS'	=> (bool) $row['fire_on_ui_actions'],
				'LAST_TRIGGERED'	=> (int) $row['last_triggered_time'] > 0 ? $this->user->format_date((int) $row['last_triggered_time']) : $this->language->lang('PHPBBAPI_NEVER'),
				'U_EDIT'		=> $this->u_action . '&amp;action=edit&amp;webhook_id=' . (int) $row['webhook_id'],
				'U_TOGGLE'		=> $this->u_action . '&amp;action=toggle&amp;webhook_id=' . (int) $row['webhook_id'],
				'U_REGENERATE'	=> $this->u_action . '&amp;action=regenerate_secret&amp;webhook_id=' . (int) $row['webhook_id'],
				'U_DELETE'		=> $this->u_action . '&amp;action=delete&amp;webhook_id=' . (int) $row['webhook_id'],
				'S_GRACE_ACTIVE'	=> (int) $row['previous_secret_expires_time'] > time(),
				'GRACE_UNTIL'		=> (int) $row['previous_secret_expires_time'] > time() ? $this->user->format_date((int) $row['previous_secret_expires_time']) : '',
			]);

			foreach ($this->webhook_manager->get_events($row) as $event)
			{
				$this->template->assign_block_vars('webhooks.event_badges', [
					'VALUE'	=> $event,
					'CLASS'	=> $this->event_class($event),
				]);
			}
		}

		$editing_events = $editing !== null ? $this->webhook_manager->get_events($editing) : [];

		foreach (webhook_manager::EVENTS as $event)
		{
			$this->template->assign_block_vars('events', [
				'VALUE'		=> $event,
				'S_CHECKED'	=> in_array($event, $editing_events, true),
			]);
		}

		$this->template->assign_vars([
			'U_ACTION'			=> $this->u_action,
			'S_HAS_WEBHOOKS'	=> !empty($webhooks),
			'ERROR'				=> $error,
			'S_ERROR'			=> $error !== '',
			'S_NEW_SECRET'		=> $new_secret !== '',
			'NEW_SECRET'		=> $new_secret,
			'NEW_SECRET_NAME'	=> $new_secret_name,
			'S_EDITING'			=> $editing !== null,
			'EDIT_WEBHOOK_ID'	=> $editing !== null ? (int) $editing['webhook_id'] : 0,
			'EDIT_NAME'			=> $editing !== null ? $editing['name'] : '',
			'EDIT_URL'			=> $editing !== null ? $editing['url'] : '',
			'EDIT_FIRE_ON_UI_ACTIONS'	=> $editing !== null && (bool) $editing['fire_on_ui_actions'],
			'U_CANCEL_EDIT'		=> $this->u_action,
		]);
	}

	/**
	 * @return array
	 */
	protected function list_all_forums()
	{
		$sql = 'SELECT forum_id, forum_name
			FROM ' . FORUMS_TABLE . '
			WHERE forum_type = ' . FORUM_POST . '
			ORDER BY left_id ASC';
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return $rows;
	}

	/**
	 * @param string	$scope
	 * @return string
	 */
	protected function scope_class($scope)
	{
		$parts = explode('.', $scope);

		return $parts[1] ?? '';
	}

	/**
	 * @param string	$event
	 * @return string
	 */
	protected function event_class($event)
	{
		$parts = explode('.', $event);

		return $parts[1] ?? '';
	}

	/**
	 * @param string	$method
	 * @return string
	 */
	protected function method_class($method)
	{
		return strtolower((string) $method);
	}

	/**
	 * @param int	$status
	 * @return string
	 */
	protected function status_class($status)
	{
		if ($status >= 500)
		{
			return '5xx';
		}

		if ($status >= 400)
		{
			return '4xx';
		}

		return '2xx';
	}

	/**
	 * @param string	$username
	 * @return array|string	the users row, or the language key explaining why it cannot be bound to a credential
	 */
	protected function resolve_bindable_user($username)
	{
		$username = trim((string) $username);

		if ($username === '')
		{
			return 'PHPBBAPI_USER_NOT_FOUND';
		}

		$sql = 'SELECT user_id, username, user_type FROM ' . USERS_TABLE . '
			WHERE username_clean = \'' . $this->db->sql_escape(utf8_clean_string($username)) . '\'';
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			return 'PHPBBAPI_USER_NOT_FOUND';
		}

		if ((int) $row['user_id'] === ANONYMOUS || in_array((int) $row['user_type'], [USER_INACTIVE, USER_IGNORE], true))
		{
			return 'PHPBBAPI_USER_NOT_BINDABLE';
		}

		if ((int) $row['user_type'] === USER_FOUNDER && (int) $this->user->data['user_type'] !== USER_FOUNDER)
		{
			return 'PHPBBAPI_USER_FOUNDER_ONLY';
		}

		return $row;
	}
}
