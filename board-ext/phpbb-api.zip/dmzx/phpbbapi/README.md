# phpBB API

A secure, scoped, versioned REST API for external applications and mobile clients: full topic/post/poll/attachment CRUD, moderation (lock/unlock, soft-delete/restore, approve/disapprove, move/merge/split), member and private-message management, outgoing webhooks, a real-time SSE event stream, and search — authenticated by per-user API credentials that never bypass phpBB's own permission system. Every request runs with the permissions of the phpBB member the credential is bound to, nothing more.

- **Author:** dmzx — https://www.dmzx-web.net
- **License:** GPL-2.0-only

## Requirements

- phpBB 3.3.0 or newer (including the 4.0.x line)
- PHP 8.1 or newer

## Installation

1. Upload this extension to `ext/dmzx/phpbbapi` in your phpBB root.
2. ACP → Customise → Manage extensions → enable **phpBB API**.
3. **Grant the permission — nobody can manage credentials until you do this.** ACP → Permissions → Administrator permissions: **"Can manage phpBB API credentials and view the request log"** (`a_phpbbapi`). The board's Founder account already has this automatically; everyone else needs it granted explicitly.
4. ACP → phpBB API → **Settings** — confirm the master switch is on and decide whether to require HTTPS (on by default; only turn off for local development).
5. ACP → phpBB API → **API credentials** — create a credential for the user/application that needs access. The token is shown **once**, immediately after creation — copy it before leaving the page.

ACP → phpBB API also has an **Overview** tab (credential counts, requests in the last 24h, error rate, most-used routes), a **Request log** tab (every request ever made, successful or not), and a **Webhooks** tab (see below).

## Authentication

Send the token in every request using one of:

```
Authorization: Bearer <token>
```
```
X-API-Key: <token>
```

Use `X-API-Key` if your host strips the `Authorization` header. A stock Apache with mod_php or PHP-FPM does **not** pass `Authorization` through to PHP by default, so `Bearer` answers `missing_token` there until you enable it - either `CGIPassAuth On` in the vhost/`.htaccess` (Apache 2.4.13+), or the usual rewrite rule:

```
RewriteEngine On
RewriteCond %{HTTP:Authorization} .
RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
```

nginx + PHP-FPM passes the header without extra configuration.

### Entry point: `app.php` vs `index.php`

All endpoints below are shown as `/app.php/api/v1/...` — the version-safe choice, since `index.php` does not route extension paths on 3.3.x. On a **4.0.x** board, `app.php` still works but is now only a 301-redirect stub to the equivalent `index.php` URL (confirmed by reading `app.php` in 4.0.0-a2 itself). That redirect is invisible to browsers and to any real HTTP client library, but `curl` without `-L` will show the raw redirect HTML instead of following it. For a production integration against a 4.0.x-only board, call `/index.php/api/v1/...` directly to skip the extra hop; for a client that might hit either version, keep using `/app.php/api/v1/...` and just make sure your HTTP client follows redirects (the default almost everywhere except bare `curl`).

**Warning: on 4.0.x, following that redirect can silently drop the request body on `POST`/`PATCH`/`DELETE` calls.** Many HTTP clients — including `curl -L` — resend the same method after a `301` but without the original body. Confirmed live: `POST /app.php/api/v1/members/{user_id}/groups` with `curl -L` came back `404 group_not_found` instead of adding the group, because `group_id` silently fell back to its default of `0` (no body arrived, so nothing failed loudly — it just picked the wrong group). The fix is not the fallback logic; it's the entry point. **Always call `/index.php/api/v1/...` directly for write requests on a 4.0.x board**, or configure your client to preserve the body across redirects (e.g. curl's `--post301`/`--post302`). `GET` requests are unaffected since they have no body to lose.

## Scopes

A credential only has the scopes you explicitly grant it, checked on top of — never instead of — the bound member's own phpBB permissions:

| Scope | Grants |
|---|---|
| `forums.read` | List forums |
| `topics.read` | Read topics and topic lists |
| `topics.write` | Create and edit topics |
| `topics.delete` | Delete topics — permanently, or soft-delete (ACL decides which you're actually allowed to do) |
| `topics.moderate` | Lock/unlock/restore topics |
| `topics.vote` | Vote (or change your vote) in a topic's poll |
| `topics.manage` | Move, merge, or split topics |
| `topics.watch` | Watch/unwatch a topic or forum for notifications |
| `posts.read` | Read posts and post lists |
| `posts.write` | Create replies and edit posts |
| `posts.delete` | Delete posts — permanently, or soft-delete (ACL decides which you're actually allowed to do) |
| `posts.attach` | Attach a file when creating a topic or reply (needed *in addition to* `topics.write`/`posts.write` — a credential might create text posts but never handle files) |
| `posts.approve` | Approve, reject, or restore posts awaiting moderation |
| `search.read` | Search posts and topics |
| `members.read` | List/read member profiles and group memberships |
| `members.write` | Add/remove a member's group membership, register new members, delete a member |
| `members.ban` | Ban or unban a member |
| `messages.read` | Read your own private message inbox |
| `messages.write` | Send private messages |
| `reports.read` | List post reports |
| `reports.manage` | Resolve post reports |
| `notifications.read` | Read and mark read your own notifications |
| `stream.read` | Subscribe to the real-time event stream (`GET /api/v1/stream`) |

A credential can additionally be restricted to specific forum IDs and/or specific caller IPs, given a request-per-window rate limit, and given an expiry date — all set per credential in ACP.

`members.write` alone is not enough for group management or registration — those additionally require the bound member to hold the matching phpBB ACP permission (`a_group`, `a_user`), same as every other action in this API: the scope narrows what the credential may attempt, the member's own permissions decide what it may actually do. `messages.write` alone is likewise not enough to send a private message — the bound member also needs `u_sendpm`, and private messaging must be turned on board-wide (ACP → Board settings → Messages). `posts.attach` alone is likewise not enough — the bound member also needs `f_attach` in that forum, and attachments must be turned on board-wide (ACP → Attachments → Attachment settings). Creating a poll needs `f_poll` on top of `topics.write`; `topics.vote` alone needs `f_vote`, and changing an existing vote additionally needs `f_votechg` *and* the poll's own "allow vote changes" setting. `members.ban` alone is likewise not enough — the bound member also needs `a_ban`; phpBB itself refuses to ban yourself or a founder account regardless of permissions, and this API surfaces that as `cannot_ban_self`/`cannot_ban_founder` rather than letting it fail silently. Deleting a member needs `a_userdel` specifically — not the `a_user` that covers registration — mirroring phpBB's own ACP; the same self/founder refusal applies here too, as `cannot_delete_self`/`cannot_delete_founder`. `reports.read`/`reports.manage` are further scoped per forum by `m_report` — a credential only sees/resolves reports in forums the bound member actually moderates.

## Endpoint reference

All endpoints are under `/api/v1/` and return `application/json`. Bodies may be sent as JSON (`Content-Type: application/json`) or form-encoded (array fields as `option_ids[]=1&option_ids[]=2`, a poll as `poll[question]=..&poll[options][]=..&poll[max_options]=1`).

Text you send (titles, subjects, reasons, usernames) is stored exactly the way phpBB's own forms store it - HTML special characters encoded, emoji as numeric character references - and text you read back (`title`, `subject`, `poster`, `username`, `name`, `filename`, `snippet`) is decoded again to plain UTF-8, so a title sent as `Q&A 🔧` comes back as `Q&A 🔧`. Only the `content_html` fields carry HTML.

| Method | Path | Scope |
|---|---|---|
| GET | `/api/v1/me` | *(any valid token)* |
| GET | `/api/v1/forums` | `forums.read` |
| POST | `/api/v1/forums/{forum_id}/watch` | `topics.watch` |
| DELETE | `/api/v1/forums/{forum_id}/watch` | `topics.watch` |
| GET | `/api/v1/forums/{forum_id}/topics` | `topics.read` |
| POST | `/api/v1/forums/{forum_id}/topics` | `topics.write` |
| GET | `/api/v1/topics?ids=1,2,3` | `topics.read` |
| GET | `/api/v1/topics/{topic_id}` | `topics.read` |
| PATCH | `/api/v1/topics/{topic_id}` | `topics.write` |
| DELETE | `/api/v1/topics/{topic_id}` | `topics.delete` + bound member needs `m_delete` |
| POST | `/api/v1/topics/{topic_id}/lock` | `topics.moderate` |
| POST | `/api/v1/topics/{topic_id}/unlock` | `topics.moderate` |
| POST | `/api/v1/topics/{topic_id}/soft-delete` | `topics.delete` + bound member needs `m_softdelete` |
| POST | `/api/v1/topics/{topic_id}/restore` | `topics.moderate` + bound member needs `m_approve` |
| POST | `/api/v1/topics/{topic_id}/move` | `topics.manage` + bound member needs `m_move` |
| POST | `/api/v1/topics/{topic_id}/merge` | `topics.manage` + bound member needs `m_merge` |
| POST | `/api/v1/topics/{topic_id}/split` | `topics.manage` + bound member needs `m_split` |
| POST | `/api/v1/topics/{topic_id}/poll/vote` | `topics.vote` + bound member needs `f_vote` |
| POST | `/api/v1/topics/{topic_id}/watch` | `topics.watch` |
| DELETE | `/api/v1/topics/{topic_id}/watch` | `topics.watch` |
| GET | `/api/v1/topics/{topic_id}/posts` | `posts.read` |
| POST | `/api/v1/topics/{topic_id}/posts` | `posts.write` |
| GET | `/api/v1/posts?ids=1,2,3` | `posts.read` |
| GET | `/api/v1/posts/{post_id}` | `posts.read` |
| PATCH | `/api/v1/posts/{post_id}` | `posts.write` |
| DELETE | `/api/v1/posts/{post_id}` | `posts.delete` + bound member needs `m_delete` |
| POST | `/api/v1/posts/{post_id}/soft-delete` | `posts.delete` + bound member needs `m_softdelete` |
| POST | `/api/v1/posts/{post_id}/restore` | `posts.approve` + bound member needs `m_approve` |
| POST | `/api/v1/posts/{post_id}/approve` | `posts.approve` + bound member needs `m_approve` |
| POST | `/api/v1/posts/{post_id}/disapprove` | `posts.approve` + bound member needs `m_approve` |
| GET | `/api/v1/search?q=...&type=posts\|topics` | `search.read` |
| GET | `/api/v1/members?q=...` | `members.read` |
| POST | `/api/v1/members` | `members.write` + bound member needs `a_user` |
| GET | `/api/v1/members/{user_id}` | `members.read` |
| GET | `/api/v1/members/{user_id}/groups` | `members.read` |
| POST | `/api/v1/members/{user_id}/groups` | `members.write` + bound member needs `a_group` |
| DELETE | `/api/v1/members/{user_id}/groups/{group_id}` | `members.write` + bound member needs `a_group` |
| DELETE | `/api/v1/members/{user_id}` | `members.write` + bound member needs `a_userdel` |
| POST | `/api/v1/members/{user_id}/ban` | `members.ban` + bound member needs `a_ban` |
| POST | `/api/v1/members/{user_id}/unban` | `members.ban` + bound member needs `a_ban` |
| GET | `/api/v1/messages` | `messages.read` |
| POST | `/api/v1/messages` | `messages.write` + bound member needs `u_sendpm` |
| GET | `/api/v1/messages/{msg_id}` | `messages.read` |
| GET | `/api/v1/attachments/{attachment_id}` | `posts.read` |
| GET | `/api/v1/reports?status=open\|closed\|all` | `reports.read` + bound member needs `m_report` |
| POST | `/api/v1/reports/{report_id}/resolve` | `reports.manage` + bound member needs `m_report` |
| GET | `/api/v1/notifications` | `notifications.read` |
| POST | `/api/v1/notifications/{notification_id}/read` | `notifications.read` |
| GET | `/api/v1/stream` | `stream.read` |

**Bulk fetch.** `GET /api/v1/topics?ids=1,2,3` / `GET /api/v1/posts?ids=1,2,3` return several items in one call instead of N separate requests — same `format_topic`/`format_post` shape as their single-item counterparts, wrapped as `{"success": true, "topics": [...]}` / `{"success": true, "posts": [...]}` in the ids' original order. Unlike `GET /topics/{topic_id}`/`GET /posts/{post_id}`, a bad id here (doesn't exist, not visible, outside this credential's readable/allowed forums) is silently left out of the result rather than failing the whole request with a 404 — there's no single id to build one error code around when several were requested at once. Capped at 100 ids per call (extras beyond that are dropped, not rejected — same clamp-not-reject convention as pagination's `limit`).

`POST /api/v1/forums/{forum_id}/topics` accepts `title`, `content`, and optional `type` (`normal`, `sticky`, `announcement` — the latter two require the bound member to hold `f_sticky`/`f_announce` in that forum). `PATCH` on a topic replaces both `title` and `content` — send the current value for whichever you are not changing.

**Polls.** `POST /api/v1/forums/{forum_id}/topics` additionally accepts an optional `poll` object — `question`, `options` (array of at least 2 strings, capped at the board's `max_poll_options`), `max_options` (how many a voter may pick, default 1), `length_days` (0 = never expires), `vote_change` (whether voters may change their vote later). Creating one needs `f_poll` in that forum, on top of `topics.write`; polls can only be attached when a topic is created, not added to one afterwards, and there's no delete/edit endpoint for one in this version — editing the topic's title/content via `PATCH /api/v1/topics/{topic_id}` (or `PATCH /api/v1/posts/{post_id}` on that topic's own first post) leaves an existing poll, its options, and its accumulated votes untouched. `GET /api/v1/topics/{topic_id}` includes a `poll` object (`null` if there isn't one) with each option's `option_id`, `text`, current `votes`, and — for the credential's bound member — `your_votes`, so a client can render the poll and vote without a separate lookup. `POST /api/v1/topics/{topic_id}/poll/vote` accepts `option_ids` (the *complete* set of options you want selected, same semantics as phpBB's own poll form — this doubles as changing your vote, not just casting a first one) and needs the bound member to hold `f_vote` (and, only to change an existing vote, `f_votechg` *and* the poll's own `vote_change` setting).

**Moderation queue and soft-delete.** These act on a post/topic that's already been created, on top of the create/delete actions above. `POST /api/v1/posts/{post_id}/approve` publishes a post that's awaiting approval (a forum with "posts require approval" turned on, or a post flagged for re-approval after editing). `POST /api/v1/posts/{post_id}/disapprove` rejects one still awaiting approval — this **deletes it outright**, same as phpBB's own moderator queue: a rejected, never-published post has nothing else to become, so there's no "disapproved but kept" state to restore from; returns `post_not_pending` if the post was already approved. `POST /api/v1/{topics,posts}/{id}/soft-delete` hides a topic/post (optionally with a `reason`) without erasing it — reversible via `POST /api/v1/{topics,posts}/{id}/restore` — as opposed to the existing `DELETE` endpoints, which are permanent and irreversible via phpBB's own `delete_topics()`/`delete_posts()`. Soft-delete needs `m_softdelete`, distinct from hard-delete's `m_delete` — a board can grant one without the other.

**Move, merge, split.** `POST /api/v1/topics/{topic_id}/move` accepts `to_forum_id` — the bound member needs `f_post` in the destination forum, and either `m_approve` or `f_noapprove` there too (posting rights, basically — matches what phpBB's own moderator UI requires before allowing a move). `POST /api/v1/topics/{topic_id}/merge` accepts `to_topic_id` and an optional `post_ids` array — omit `post_ids` to merge the *entire* source topic, or list specific posts to merge only those (phpBB's own moderator UI works at the post level even though "merge topic into topic" is the common case, so this API mirrors that flexibility rather than only offering the whole-topic shortcut). `POST /api/v1/topics/{topic_id}/split` accepts `post_ids`, `subject`, and `to_forum_id`, and creates a genuinely new topic from those posts (response includes its `topic_id`) — the first post in `post_ids` becomes the new topic's first post and gets its subject rewritten to `subject`, same as choosing "split topic" in the web UI.

**Attachments.** `POST /api/v1/forums/{forum_id}/topics` and `POST /api/v1/topics/{topic_id}/posts` additionally accept up to 10 files, sent as `multipart/form-data` alongside the usual `title`/`content` fields — a plain JSON body has no way to carry a file, so switch `Content-Type` to `multipart/form-data` for that one request instead. **Each file is its own field**: `attachment` for the first, `attachment2` for the second, `attachment3` for the third, and so on through `attachment10` — not `attachment[]`/an array field. (PHP itself merges any bracketed field name into one nested `$_FILES` entry before phpBB ever sees it, which phpBB's own uploader can't split back apart per-file without reaching into the raw superglobal — separately-named fields are what let each file arrive as its own normal, flat upload.) Sending any file requires `posts.attach` *in addition to* `topics.write`/`posts.write`, and the bound member needs `f_attach` in that forum; leave every field out entirely for a normal text-only post, same as today. The response includes `attachment_ids` (empty array if no attachment fields were sent; a rejected upload on *any* field — disallowed extension, too large, etc. — fails the whole request with `attachment_rejected` rather than silently posting with only the files that did pass). The 10-field cap is this API's own input limit, not the board's — your board's own `max_attachments`/`max_attachments_pm` ACP setting still applies on top of it exactly as it would through the web UI. Any post's attachments (from either creating it or reading it back later via `GET /api/v1/posts/{post_id}` / `GET /api/v1/topics/{topic_id}/posts`) show up in an `attachments` array (`attachment_id`, `filename`, `filesize`, `mimetype`) on that post. `GET /api/v1/attachments/{attachment_id}` streams the file back — same visibility/ACL checks as reading the parent post (`u_download` + `f_download`), so an attachment on a post you can't see 404s the same way the post itself would.

`POST /api/v1/members` accepts `username`, `password`, `email` and always creates an active (`USER_NORMAL`) account immediately, regardless of the board's own registration-activation policy — deliberate: an already-permissioned integration creating an account on someone's behalf shouldn't also trigger an email-activation flow. `POST /api/v1/members/{user_id}/groups` accepts a `group_id`.

**Ban / unban.** `POST /api/v1/members/{user_id}/ban` accepts `length_minutes` (0 = permanent), `reason` (moderator-only), and `public_reason` (shown to the banned member). `POST /api/v1/members/{user_id}/unban` takes no body. phpBB rewrote its ban storage between the 3.3.x and 4.0.x lines this extension supports; both are handled transparently, no client-visible difference.

**Delete a member.** `DELETE /api/v1/members/{user_id}` accepts an optional `mode`: `"remove"` also deletes everything the member posted, anything else (including omitting the field) retains their posts under the deleted account's username, same as phpBB's own ACP default.

**Reports.** `GET /api/v1/reports` lists post reports (`status=open` by default, or `closed`/`all`), scoped to forums the bound member holds `m_report` in. `POST /api/v1/reports/{report_id}/resolve` closes one — clearing the reported-post indicator once no open reports remain on that post. Creating a report isn't part of this version's API (reporting is a create-only, member-facing action; this extension's report support is moderator-facing).

**Notifications and watching.** `GET /api/v1/notifications` returns the bound member's own board notifications (`unread_count` alongside the paginated list), same feed as the bell icon in the web UI. `POST /api/v1/notifications/{notification_id}/read` marks one read — 404s if it isn't yours, never someone else's. `POST`/`DELETE /api/v1/topics/{topic_id}/watch` and `POST`/`DELETE /api/v1/forums/{forum_id}/watch` subscribe/unsubscribe the bound member, same mechanism as the "Watch topic"/"Watch forum" links in the UCP — calling `POST` while already watching, or `DELETE` while not, is a harmless no-op either way.

`POST /api/v1/messages` accepts `to` (a username or numeric `user_id`), `subject`, and `content`. `GET /api/v1/messages` only lists your own inbox (folder filtering/outbox/sentbox are not exposed in this version); reading a message via `GET /api/v1/messages/{msg_id}` marks it read, same as opening it in the UCP.

### PATCH/DELETE blocked by your host? Use the method override

Some Apache/ModSecurity setups reject the `PATCH`/`DELETE` HTTP methods outright with a bare `403 Forbidden` — before the request ever reaches phpBB (phpBB core itself never uses either verb, so many hosts never open them up). If that happens, send a normal `POST` to the same `/api/v1/topics/{topic_id}` or `/api/v1/posts/{post_id}` path with either:

```
X-HTTP-Method-Override: PATCH
```

or a `_method` field in the body (`{"_method": "PATCH", "content": "..."}`), and it is handled identically to a real `PATCH`/`DELETE` request. A plain `POST` to either path with no override returns `method_override_required`.

## Examples

Replace `https://example.com/app.php` and `<token>` with your own board and credential token. Every endpoint below has an example; all were run against a live 4.0.x board while building this extension (a few of the rarer paths — merge/split/ban/reports — are shown with a representative response captured during live testing rather than re-run for this listing, but reflect the exact same code paths).

### Identity, forums

**Who am I**

```bash
curl https://example.com/app.php/api/v1/me -H "X-API-Key: <token>"
```
```json
{"success": true, "user_id": 2, "username": "dmzx", "is_founder": true, "scopes": ["topics.read", "topics.write", "..."], "allowed_forums": []}
```

**List forums**

```bash
curl https://example.com/app.php/api/v1/forums -H "X-API-Key: <token>"
```
```json
{"success": true, "forums": [{"forum_id": 2, "parent_id": 1, "name": "Your first forum", "type": 1, "can_read": true, "can_post": true, "can_reply": true}]}
```

**Watch / unwatch a forum**

```bash
curl -X POST   https://example.com/app.php/api/v1/forums/2/watch -H "X-API-Key: <token>"
curl -X DELETE https://example.com/app.php/api/v1/forums/2/watch -H "X-API-Key: <token>"
```
```json
{"success": true}
```

### Topics

**Create a topic**

```bash
curl -X POST https://example.com/app.php/api/v1/forums/2/topics \
  -H "X-API-Key: <token>" \
  -H "Content-Type: application/json" \
  -d '{"title": "Test topic via API", "content": "Created through the phpBB API extension."}'
```
```json
{"success": true, "topic_id": 303, "post_id": 7572, "url": "https://example.com/viewtopic.php?t=303", "attachment_ids": []}
```

**Create a topic with a poll**

```bash
curl -X POST https://example.com/app.php/api/v1/forums/2/topics \
  -H "X-API-Key: <token>" \
  -H "Content-Type: application/json" \
  -d '{"title": "Pick a colour", "content": "Vote below.", "poll": {"question": "Favourite colour?", "options": ["Red", "Green", "Blue"], "max_options": 1, "length_days": 7}}'
```

The response is identical in shape to a plain topic create (`{success, topic_id, post_id, url, attachment_ids}` — poll data is never echoed back here). To read the poll back, `GET` the topic:

```bash
curl https://example.com/app.php/api/v1/topics/303 -H "X-API-Key: <token>"
```
```json
{"success": true, "topic": {"topic_id": 303, "forum_id": 2, "title": "Pick a colour", "type": "normal", "poster_id": 2, "poster": "dmzx", "replies": 0, "views": 1, "first_post_time": 1755500000, "last_post_time": 1755500000, "last_poster_id": 2, "last_poster": "dmzx", "locked": false, "url": "https://example.com/viewtopic.php?t=303", "poll": {"question": "Favourite colour?", "options": [{"option_id": 1, "text": "Red", "votes": 0}, {"option_id": 2, "text": "Green", "votes": 0}, {"option_id": 3, "text": "Blue", "votes": 0}], "max_options": 1, "vote_change": false, "expires": 1756104800, "your_votes": []}}}
```

**Create a topic with multiple attachments**

```bash
curl -X POST https://example.com/app.php/api/v1/forums/2/topics \
  -H "X-API-Key: <token>" \
  -F "title=Screenshots attached" \
  -F "content=See attached." \
  -F "attachment=@screenshot1.png" \
  -F "attachment2=@screenshot2.png" \
  -F "attachment3=@notes.pdf"
```
```json
{"success": true, "topic_id": 305, "post_id": 7600, "url": "https://example.com/viewtopic.php?t=305", "attachment_ids": [12, 13, 14]}
```

One file per field (`attachment`, `attachment2`, `attachment3`, ... up to `attachment10`) — not an `attachment[]` array field, see Endpoint reference above for why.

**List a forum's topics**

```bash
curl "https://example.com/app.php/api/v1/forums/2/topics?limit=10" -H "X-API-Key: <token>"
```
```json
{"success": true, "forum": {"forum_id": 2, "name": "Your first forum"}, "pagination": {"limit": 10, "start": 0, "total": 42, "count": 10}, "topics": [{"topic_id": 303, "...": "one format_topic entry per row, same shape as GET /topics/{topic_id} above"}]}
```

**Get a single topic** — see the poll example above; a topic without a poll has `"poll": null`.

**Bulk fetch topics by id**

```bash
curl "https://example.com/app.php/api/v1/topics?ids=303,304,999999" -H "X-API-Key: <token>"
```
```json
{"success": true, "topics": [{"topic_id": 303, "...": "same shape as GET /topics/{topic_id}"}, {"topic_id": 304, "...": "..."}]}
```

Note `999999` (nonexistent) is simply absent from `topics` — no error, no placeholder entry.

**Edit a topic** — `title` and `content` (of the topic's own first post) are both required, even if you're only changing one; send the current value for the other.

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303 \
  -H "X-API-Key: <token>" \
  -H "X-HTTP-Method-Override: PATCH" \
  -H "Content-Type: application/json" \
  -d '{"title": "Pick a colour (updated)", "content": "Vote below - now with more options."}'
```
```json
{"success": true, "topic_id": 303, "post_id": 7572, "url": "https://example.com/viewtopic.php?t=303"}
```

**Delete a topic** (permanent — see soft-delete below for a reversible alternative; needs `m_delete`)

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303 \
  -H "X-API-Key: <token>" \
  -H "X-HTTP-Method-Override: DELETE"
```
```json
{"success": true}
```

**Lock / unlock a topic**

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303/lock -H "X-API-Key: <token>"
curl -X POST https://example.com/app.php/api/v1/topics/303/unlock -H "X-API-Key: <token>"
```
```json
{"success": true}
```

**Soft-delete / restore a topic** (needs `m_softdelete`/`m_approve`, reversible unlike the hard `DELETE` above)

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303/soft-delete \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" -d '{"reason": "spam"}'
curl -X POST https://example.com/app.php/api/v1/topics/303/restore -H "X-API-Key: <token>"
```
```json
{"success": true}
```

**Move a topic** (needs `f_post` + `m_approve`/`f_noapprove` in the destination forum)

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303/move \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" -d '{"to_forum_id": 11}'
```
```json
{"success": true}
```

**Merge a topic into another** (omit `post_ids` to merge the entire source topic)

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303/merge \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" -d '{"to_topic_id": 290, "post_ids": [7572, 7573]}'
```
```json
{"success": true}
```

**Split posts into a new topic**

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303/split \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" \
  -d '{"post_ids": [7574, 7575], "subject": "Split-off discussion", "to_forum_id": 2}'
```
```json
{"success": true, "topic_id": 304}
```

**Vote in a poll** (the *complete* set of options you want selected — also how you change a vote)

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303/poll/vote \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" -d '{"option_ids": [2]}'
```
```json
{"success": true, "your_votes": [2]}
```

**Watch / unwatch a topic**

```bash
curl -X POST   https://example.com/app.php/api/v1/topics/303/watch -H "X-API-Key: <token>"
curl -X DELETE https://example.com/app.php/api/v1/topics/303/watch -H "X-API-Key: <token>"
```
```json
{"success": true}
```

### Posts

**List a topic's posts**

```bash
curl "https://example.com/app.php/api/v1/topics/303/posts?limit=20" -H "X-API-Key: <token>"
```
```json
{"success": true, "topic": {"topic_id": 303, "forum_id": 2, "title": "Pick a colour", "locked": false}, "pagination": {"limit": 20, "start": 0, "total": 3, "count": 3}, "posts": [{"post_id": 7572, "...": "one format_post entry per row, same shape as GET /posts/{post_id} below"}]}
```

**Reply to a topic**

```bash
curl -X POST https://example.com/app.php/api/v1/topics/303/posts \
  -H "X-API-Key: <token>" \
  -H "Content-Type: application/json" \
  -d '{"content": "This is a reply."}'
```
```json
{"success": true, "topic_id": 303, "post_id": 7573, "url": "https://example.com/viewtopic.php?t=303&p=7573#p7573", "attachment_ids": []}
```

**Get a single post**

```bash
curl https://example.com/app.php/api/v1/posts/7573 -H "X-API-Key: <token>"
```
```json
{"success": true, "post": {"post_id": 7573, "poster_id": 2, "poster": "dmzx", "post_time": 1755500100, "edit_count": 0, "edit_time": 0, "subject": "Re: Pick a colour", "content_html": "This is a reply.", "content_bbcode": "This is a reply.", "url": "https://example.com/viewtopic.php?t=303&p=7573#p7573", "attachments": [], "approved": true}, "topic": {"topic_id": 303, "forum_id": 2, "title": "Pick a colour", "locked": false, "first_post_id": 7570}, "forum": {"forum_id": 2}}
```

`post.approved` is `false` while the post is still awaiting moderator approval (or unpublished after an edit that requires re-approval). `topic.first_post_id` lets a caller tell whether a given post is the topic's own opening post or a reply, without a second request.

**Bulk fetch posts by id**

```bash
curl "https://example.com/app.php/api/v1/posts?ids=7572,7573" -H "X-API-Key: <token>"
```
```json
{"success": true, "posts": [{"post_id": 7572, "...": "same shape as the post object in GET /posts/{post_id}"}, {"post_id": 7573, "...": "..."}]}
```

**Edit a post** (via method override, see above — a plain `PATCH` works the same if your host allows it)

```bash
curl -X POST https://example.com/app.php/api/v1/posts/7573 \
  -H "X-API-Key: <token>" \
  -H "X-HTTP-Method-Override: PATCH" \
  -H "Content-Type: application/json" \
  -d '{"content": "Edited content."}'
```
```json
{"success": true, "topic_id": 303, "post_id": 7573, "url": "https://example.com/viewtopic.php?t=303&p=7573#p7573"}
```

**Delete a post** (permanent — needs `m_delete`)

```bash
curl -X POST https://example.com/app.php/api/v1/posts/7573 \
  -H "X-API-Key: <token>" \
  -H "X-HTTP-Method-Override: DELETE"
```
```json
{"success": true}
```

**Soft-delete / restore a post**

```bash
curl -X POST https://example.com/app.php/api/v1/posts/7573/soft-delete \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" -d '{"reason": "off-topic"}'
curl -X POST https://example.com/app.php/api/v1/posts/7573/restore -H "X-API-Key: <token>"
```
```json
{"success": true}
```

**Approve / disapprove a post** (moderation queue — disapprove deletes it outright, see Endpoint reference)

```bash
curl -X POST https://example.com/app.php/api/v1/posts/7573/approve -H "X-API-Key: <token>"
curl -X POST https://example.com/app.php/api/v1/posts/7573/disapprove -H "X-API-Key: <token>"
```
```json
{"success": true}
```

### Search

```bash
curl "https://example.com/app.php/api/v1/search?type=topics&q=welcome" -H "X-API-Key: <token>"
curl "https://example.com/app.php/api/v1/search?type=posts&q=welcome&author=admin&forum_id=2" -H "X-API-Key: <token>"
```

Note: search runs through the board's configured search backend (the same index `search.php` uses - native, MySQL fulltext, PostgreSQL fulltext or Sphinx), so it matches whole words against both the subject/title and the body, honours `load_search`, `u_search` and `f_search`, and a post can show up for a query that only appears in its (auto-generated `Re: ...`) subject line, not in the snippet shown. A query made only of common or too-short words answers `search_no_keywords`; a board without a working search backend answers `search_unavailable`.

### Members

**List / search members**

```bash
curl "https://example.com/app.php/api/v1/members?q=dmzx&limit=10" -H "X-API-Key: <token>"
```
```json
{"success": true, "pagination": {"limit": 10, "start": 0, "total": 1, "count": 1}, "members": [{"user_id": 2, "username": "dmzx", "regdate": 1750000000, "posts": 128, "colour": "AA0000"}]}
```

**Get a single member**

```bash
curl https://example.com/app.php/api/v1/members/2 -H "X-API-Key: <token>"
```
```json
{"success": true, "member": {"user_id": 2, "username": "dmzx", "regdate": 1750000000, "posts": 128, "colour": "AA0000"}}
```

**Register a new member** (always active immediately — see Endpoint reference for why)

```bash
curl -X POST https://example.com/app.php/api/v1/members \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" \
  -d '{"username": "newuser", "password": "correct-horse-battery-staple", "email": "newuser@example.com"}'
```
```json
{"success": true, "user_id": 15, "username": "newuser"}
```

**List / add / remove a member's groups**

```bash
curl https://example.com/app.php/api/v1/members/15/groups -H "X-API-Key: <token>"
```
```json
{"success": true, "groups": [{"group_id": 2, "name": "REGISTERED", "is_leader": false}]}
```
```bash
curl -X POST https://example.com/app.php/api/v1/members/15/groups \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" -d '{"group_id": 5}'
curl -X POST https://example.com/app.php/api/v1/members/15/groups/5 \
  -H "X-API-Key: <token>" -H "X-HTTP-Method-Override: DELETE"
```
```json
{"success": true}
```

**Ban / unban a member**

```bash
curl -X POST https://example.com/app.php/api/v1/members/15/ban \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" \
  -d '{"length_minutes": 0, "reason": "spam (moderator-only)", "public_reason": "Banned for spam"}'
curl -X POST https://example.com/app.php/api/v1/members/15/unban -H "X-API-Key: <token>"
```
```json
{"success": true}
```

**Delete a member** (`mode: "remove"` also deletes their posts; omitted/anything else retains them)

```bash
curl -X POST https://example.com/app.php/api/v1/members/15 \
  -H "X-API-Key: <token>" -H "X-HTTP-Method-Override: DELETE" \
  -H "Content-Type: application/json" -d '{"mode": "retain"}'
```
```json
{"success": true}
```

### Reports

```bash
curl "https://example.com/app.php/api/v1/reports?status=open" -H "X-API-Key: <token>"
```
```json
{"success": true, "pagination": {"limit": 25, "start": 0, "total": 1, "count": 1}, "reports": [{"report_id": 4, "post_id": 7573, "topic_id": 303, "forum_id": 2, "post_subject": "Re: Pick a colour", "reporter_id": 3, "reporter": "someuser", "reason": "Spam", "report_text": "", "report_time": 1755500200, "resolved": false}]}
```
```bash
curl -X POST https://example.com/app.php/api/v1/reports/4/resolve -H "X-API-Key: <token>"
```
```json
{"success": true}
```

### Messages

**List your inbox**

```bash
curl https://example.com/app.php/api/v1/messages -H "X-API-Key: <token>"
```
```json
{"success": true, "pagination": {"limit": 25, "start": 0, "total": 1, "count": 1}, "messages": [{"msg_id": 9, "subject": "Welcome", "author_id": 2, "author": "dmzx", "sent_time": 1755500300, "unread": true}]}
```

**Get a single message** (marks it read, same as opening it in the UCP)

```bash
curl https://example.com/app.php/api/v1/messages/9 -H "X-API-Key: <token>"
```
```json
{"success": true, "message": {"msg_id": 9, "subject": "Welcome", "author_id": 2, "author": "dmzx", "sent_time": 1755500300, "unread": false, "content_html": "Hi there!", "content_bbcode": "Hi there!"}}
```

**Send a message**

```bash
curl -X POST https://example.com/app.php/api/v1/messages \
  -H "X-API-Key: <token>" -H "Content-Type: application/json" \
  -d '{"to": "someuser", "subject": "Welcome", "content": "Hi there!"}'
```
```json
{"success": true, "msg_id": 10, "to": {"user_id": 3, "username": "someuser"}}
```

### Attachments

```bash
curl https://example.com/app.php/api/v1/attachments/12 -H "X-API-Key: <token>" -o downloaded_file
```

Not a JSON response — streams the file back with the correct `Content-Type`/`Content-Disposition`, same visibility/ACL checks as reading the parent post. A post's own `attachments` array (seen in `GET /posts/{post_id}` above) lists `attachment_id`/`filename`/`filesize`/`mimetype` for each file already attached to it.

### Notifications

```bash
curl https://example.com/app.php/api/v1/notifications -H "X-API-Key: <token>"
```
```json
{"success": true, "pagination": {"limit": 25, "start": 0, "total": 2, "count": 2}, "unread_count": 1, "notifications": [{"notification_id": 21, "title": "someuser replied to Pick a colour", "url": "https://example.com/viewtopic.php?t=303&p=7573#p7573", "time": 1755500100, "unread": true}]}
```
```bash
curl -X POST https://example.com/app.php/api/v1/notifications/21/read -H "X-API-Key: <token>"
```
```json
{"success": true}
```

### Real-time stream

See the dedicated [Real-time stream (SSE)](#real-time-stream-sse) section above for `GET /api/v1/stream` — curl and `EventSource` examples live there rather than being duplicated here.

### Error envelope

```json
{"success": false, "error": "<code>"}
```

| HTTP | Code | Meaning |
|---|---|---|
| 401 | `missing_token` | No token supplied |
| 401 | `invalid_token` | Token not found |
| 403 | `credential_disabled` / `credential_expired` | Credential is off or past its expiry |
| 403 | `ip_not_allowed` / `forum_not_allowed` | Outside this credential's allowlist |
| 403 | `https_required` | Request did not arrive over HTTPS |
| 403 | `account_unavailable` / `account_banned` | The bound member is inactive/a bot/banned |
| 403 | `insufficient_permissions` | Missing scope, or the bound member lacks the phpBB permission |
| 403 | `forum_password_required` | Forum is password-protected — the API cannot supply it |
| 403 | `topic_locked` / `post_locked` | Locked, and the bound member is not a moderator |
| 403 | `edit_time_expired` | Past the board's edit-time window, and not a moderator |
| 404 | `forum_not_found` / `topic_not_found` / `post_not_found` | Does not exist, or not visible to the bound member |
| 404 | `member_not_found` / `group_not_found` | Does not exist, or the member is inactive/a bot |
| 404 | `message_not_found` | Does not exist, isn't yours, or is on hold |
| 404 | `attachment_not_found` | Does not exist, isn't attached to a visible post, or its extension is no longer allowed |
| 404 | `poll_not_found` | Topic has no poll |
| 404 | `poll_option_not_found` | An `option_id` in the vote doesn't belong to this poll |
| 403 | `messages_disabled` | Board's Private Messages setting is off |
| 403 | `pm_not_allowed` | Recipient has disabled private messages (bypassed for admins/moderators, same as phpBB itself) |
| 403 | `attachments_disabled` | Board's Attachments setting is off |
| 403 | `poll_closed` | Poll's `length_days` window has passed |
| 403 | `vote_change_not_allowed` | Already voted, and either `f_votechg` or the poll's own vote-change setting says no |
| 403 | `vote_converted` | Poll was migrated from other forum software and can no longer accept votes (a phpBB-core restriction, not this extension's) |
| 400 | `attachment_rejected` | Upload failed the board's own attachment rules (extension, size, quota, dimensions, etc.) |
| 400 | `too_many_poll_options` | More `options` than the board's `max_poll_options` |
| 400 | `too_many_vote_options` | More `option_ids` than the poll's own `max_options` |
| 400 | `poll_question_too_long` | Poll `question` over 255 characters |
| 400 | `post_not_pending` | `disapprove` called on a post that isn't awaiting approval |
| 400 | `already_in_forum` | `move` target is the topic's current forum |
| 400 | `merge_same_topic` | `merge` target is the source topic itself |
| 400 | `member_not_banned` | `unban` called on a member with no active ban |
| 400 | `report_already_resolved` | `resolve` called on a report that's already closed |
| 403 | `cannot_ban_self` / `cannot_ban_founder` | phpBB refuses these regardless of permissions |
| 403 | `cannot_delete_self` / `cannot_delete_founder` | phpBB refuses these regardless of permissions |
| 404 | `report_not_found` | Does not exist, or is a PM report (out of scope for this API) |
| 404 | `notification_not_found` | Does not exist, or isn't yours |
| 400 | `missing_fields` / `title_too_long` / `message_rejected` | Validation failed (the last one reuses phpBB's own posting rules — banned words, length limits, etc.) |
| 400 | `subject_too_long` | `POST /api/v1/messages` subject over 255 characters |
| 400 | `search_query_too_short` | Fewer than 3 characters |
| 400 | `method_override_required` | `POST` sent to a PATCH/DELETE-only path without a method override (see above) |
| 400 | `group_action_failed` | The group add/remove itself failed (e.g. already a member) |
| 400 | *(various, lowercased)* | `POST /api/v1/members` validation failures reuse phpBB's own registration validator codes verbatim, lowercased — e.g. `username_taken`, `field_too_short`, `email_invalid_email` |
| 400 | `registration_failed` | `POST /api/v1/members` — phpBB's own `user_add()` rejected the account for a reason not caught by validation |
| 500 | `no_group` | `POST /api/v1/members` — the board's `REGISTERED` special group is missing from the database |
| 429 | `rate_limit_exceeded` | This credential's own rate limit |
| 503 | `api_disabled` | Master switch is off in ACP |

Every response (success or error) from a rate-limited credential also carries `X-RateLimit-Limit`, `X-RateLimit-Remaining`, and `X-RateLimit-Reset` (unix time the current window ends) — check `X-RateLimit-Remaining` to back off before hitting a 429, not just after. A credential with `rate_limit` set to `0` (unlimited) sends none of these three headers, since there is no limit to report.

## Security notes

- **Permissions are never bypassed.** Every request resolves to the credential's bound phpBB member and runs phpBB's own `submit_post()`, `delete_topics()`/`delete_posts()`, and ACL checks exactly as if that member used the web UI — a credential cannot do anything the member could not already do themselves.
- **Deletion requires moderator-level `m_delete`.** Self-service deletion of one's own post via the API is deliberately not supported in this version — the destructive-action surface is kept to moderators only.
- **Tokens are hashed.** Only a SHA-256 hash is stored.
- **Token rotation.** ACP → phpBB API → API credentials → **Regenerate** issues a new token immediately, without deleting the credential (scopes/allowlists/rate limit all stay as configured) — the old token keeps working for 24 hours so you can update whichever application uses it, then stops working. Prefer a clean break with no overlap instead? Delete the credential and create a new one, same as before.
- **Rate limiting** is enforced per credential via phpBB's own cache layer (no extra database writes on the hot path) — see the `X-RateLimit-*` response headers below for checking remaining quota before hitting it.
- **CORS is off by default.** Server-to-server and mobile clients are unaffected either way; only fill in "Allowed CORS origins" in Settings if browser JavaScript needs to call the API directly.
- **Audit log.** Every request — successful or not — is recorded with time, IP, method, route, status, and error code. ACP → phpBB API → Request log.

## Real-time stream (SSE)

`GET /api/v1/stream` (scope `stream.read`) is a [Server-Sent Events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events) connection that emits `topic.created`/`post.created` as they happen, instead of polling. Each event's `data` is `{"event": "...", "time": ..., "data": {...}}` — the same envelope shape as a webhook delivery (see below), so a client already parsing webhook payloads recognizes this one too. A topic's own first post is only ever reported as `topic.created`, never also as `post.created`. Only approved, non-deleted content in forums the bound member can read is included — same permission model as every other endpoint, plus the credential's own forum allowlist if one is set.

```
curl -N -H "X-API-Key: <token>" "https://example.com/index.php/api/v1/stream"
```

```js
const source = new EventSource('/index.php/api/v1/stream?access_token=<token>');
source.addEventListener('topic.created', e => console.log(JSON.parse(e.data)));
source.addEventListener('post.created',  e => console.log(JSON.parse(e.data)));
```

**Resuming where you left off:** pass `?since=<unix time>`, or rely on `Last-Event-ID` — the browser's native `EventSource` sends this automatically on every reconnect. Each event's SSE `id:` field is `{time}-{t|p}-{topic or post id}` (also returned as `id` inside the JSON), a unique, ordered cursor, so events created within the same second are never skipped across a reconnect and a plain `new EventSource(url)` resumes correctly with no extra client code. A bare unix time is still accepted as `Last-Event-ID` and behaves like `?since=`. A brand-new connection with neither falls back to a short lookback window. The connection closes after each batch with a `retry: 5000` hint — `EventSource` reconnects on its own, this is not a persistent held-open connection.

**Auth via query string, `/stream` only.** Every other endpoint expects `Authorization: Bearer <token>` or `X-API-Key: <token>`. The native browser `EventSource` API cannot set custom request headers at all, so `?access_token=<token>` is accepted as a fallback — deliberately only useful here, since anything that *can* set a header (curl, fetch, axios, a mobile HTTP client) has no reason to use it. Trade-off accepted: a token in a URL can leak via server access logs, proxies, or browser history in a way a header never does — prefer a header wherever your client supports one.

## Webhooks

ACP → phpBB API → **Webhooks** lets you register a URL to receive a signed `POST` whenever something matching your subscribed events happens through this API — creating, editing, or moderating a topic or post, or a new member registering. Configuration is ACP-only; there is no REST endpoint for managing webhooks (nothing to scope/authenticate as an external caller for, since only someone who already holds `a_phpbbapi` can reach that ACP page).

**Events:**

| Category | Events |
|---|---|
| Topics | `topic.created`, `topic.updated`, `topic.deleted`, `topic.locked`, `topic.unlocked`, `topic.soft_deleted`, `topic.restored`, `topic.moved`, `topic.merged`, `topic.split` |
| Posts | `post.created`, `post.updated`, `post.deleted`, `post.approved`, `post.disapproved`, `post.soft_deleted`, `post.restored` |
| Members | `member.registered` |

By default only fires for actions taken *through this API* — not for the same things happening via the normal web UI or another extension. Each webhook has its own **Fire for forum-UI actions too** toggle (off by default) that extends it to the matching forum-UI action as well — a moderator locking a topic by hand, a member replying through the normal posting form, and so on — still limited to the same subscribed event list, just a second trigger source. Opt-in rather than on-by-default: an integration-focused "notify my external system when my API integration does something" is a narrower, more predictable default than "notify on all board activity," while a webhook that genuinely wants full coverage can still ask for it.

Every topic/post event's `data` carries at least `topic_id`/`post_id` (whichever applies) and `forum_id`; a few carry action-specific extras: `topic.updated`/`post.updated` add `title`/`url` (the latter topic-only) same as their `.created` counterparts, `topic.soft_deleted`/`post.soft_deleted` add `reason`, `topic.moved` adds `to_forum_id`, `topic.merged` adds `to_topic_id`, and `topic.split` adds `new_topic_id`/`to_forum_id` (`topic_id`/`forum_id` stay the *source* topic's, unaffected by the split). `member.registered`'s `data` is unrelated to a topic/post — just `user_id`/`username`.

**Delivery:** a JSON body `{"event": "topic.created", "time": 1699999999, "data": {...}}`, `Content-Type: application/json`, plus:

```
X-Webhook-Event: topic.created
X-Webhook-Signature: sha256=<hex-encoded HMAC-SHA256 of the raw request body, using the webhook's own secret>
```

Verify a delivery by recomputing the same HMAC over the raw body with your secret and comparing to the header. The secret is shown once, right after creating the webhook — same "copy it now" rule as an API credential's token, though for a different reason: unlike a token (only ever hashed and *compared*), the secret has to stay usable by phpBB itself to keep signing future deliveries, so it's stored server-side rather than one-way hashed.

**Rotating a secret.** ACP → phpBB API → Webhooks → **Regenerate** issues a new secret immediately, without deleting the webhook (URL/events/delivery history all stay as configured) — for 24 hours after that, every delivery is signed with *both* secrets: `X-Webhook-Signature` (new) and `X-Webhook-Signature-Previous` (old, only present during this window). Verify against `X-Webhook-Signature` with your new secret once you've updated it; while you're still on the old one, `X-Webhook-Signature-Previous` will match it instead. After 24 hours only `X-Webhook-Signature` (new) is sent.

**Example delivery** — what your endpoint receives for a `topic.created` event:

```
POST /your-webhook-endpoint HTTP/1.1
Content-Type: application/json
X-Webhook-Event: topic.created
X-Webhook-Signature: sha256=5a8f...c3e1

{"event": "topic.created", "time": 1755500000, "data": {"topic_id": 303, "post_id": 7572, "forum_id": 2, "title": "Test topic via API", "url": "https://example.com/viewtopic.php?t=303"}}
```

**Verifying the signature** (PHP — use a timing-safe comparison, never `===`, on the recomputed hash):

```php
$payload = file_get_contents('php://input');
$signature = 'sha256=' . hash_hmac('sha256', $payload, $webhook_secret);

if (!hash_equals($signature, $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] ?? '')) {
    http_response_code(401);
    exit;
}
```

Same idea in Node.js:

```js
const crypto = require('crypto');
const expected = 'sha256=' + crypto.createHmac('sha256', webhookSecret).update(rawBody).digest('hex');
const valid = crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(req.headers['x-webhook-signature'] || ''));
```

**Delivery is fire-and-forget, best-effort** — the first attempt happens inline with the action that triggered it (a failed attempt never affects that API response) and is logged (`failure_count`/`last_triggered_time` on the webhook itself). A failed delivery is then retried automatically with exponential backoff — 1 min, 5 min, 30 min, 2 hours, then 12 hours — for up to 5 retries (~15 hours total) before being given up on. Retries only run opportunistically, the same way every other phpBB background task does: on phpBB's own cron beacon (fired on page loads) or via system cron if you've configured one for your board — a quiet board with nobody browsing it won't retry until someone does, or until cron is polled. A webhook that gets deleted or disabled while a retry is still pending is simply not retried further.

**ACP → phpBB API → Webhook deliveries** shows every delivery attempt (including retries of the same failure, tracked as one row) — event, HTTP status, delivered/failed, and, while a retry is still pending, which attempt number and when it's next due.

## Support

Issues and questions: info@dmzx-web.net / https://www.dmzx-web.net
