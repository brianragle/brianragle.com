<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\cron\task;

use dmzx\phpbbapi\core\webhook_dispatcher;
use phpbb\config\config;
use phpbb\cron\task\base;

class retry_webhook_deliveries extends base
{
	const RUN_INTERVAL = 300;

	/** @var config */
	protected $config;

	/** @var webhook_dispatcher */
	protected $webhook_dispatcher;

	/**
	 * @param config			$config
	 * @param webhook_dispatcher	$webhook_dispatcher
	 */
	public function __construct(config $config, webhook_dispatcher $webhook_dispatcher)
	{
		$this->config = $config;
		$this->webhook_dispatcher = $webhook_dispatcher;
	}

	/**
	 * {@inheritdoc}
	 */
	public function run()
	{
		$this->webhook_dispatcher->process_due_retries();
		$this->config->set('phpbbapi_webhook_retry_last_gc', time());
	}

	/**
	 * {@inheritdoc}
	 */
	public function should_run()
	{
		return (int) $this->config['phpbbapi_webhook_retry_last_gc'] < time() - self::RUN_INTERVAL;
	}
}
