<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\db\driver\driver_interface;
use phpbb\user;

class message_manager
{
	const MAX_LIMIT = 100;
	const DEFAULT_LIMIT = 25;
	const MAX_SUBJECT_LENGTH = 255;

	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var config */
	protected $config;

	/** @var user */
	protected $user;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/**
	 * @param driver_interface	$db
	 * @param auth				$auth
	 * @param config			$config
	 * @param user				$user
	 * @param string			$root_path
	 * @param string			$php_ext
	 */
	public function __construct(driver_interface $db, auth $auth, config $config, user $user, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->config = $config;
		$this->user = $user;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	/**
	 * @param int	$limit
	 * @param int	$start
	 * @return array
	 */
	public function list_inbox($limit, $start)
	{
		$this->assert_can_read();
		$this->sort_new_messages();

		$limit = $this->clamp_limit($limit);
		$start = max(0, (int) $start);
		$user_id = (int) $this->user->data['user_id'];

		$sql_where = 't.user_id = ' . $user_id . '
			AND t.folder_id = ' . PRIVMSGS_INBOX . '
			AND t.pm_deleted = 0';

		$sql = 'SELECT COUNT(*) AS total
			FROM ' . PRIVMSGS_TO_TABLE . ' t
			WHERE ' . $sql_where;
		$result = $this->db->sql_query($sql);
		$total = (int) $this->db->sql_fetchfield('total');
		$this->db->sql_freeresult($result);

		$sql = 'SELECT t.msg_id, t.pm_unread, p.message_subject, p.message_time, p.author_id, u.username
			FROM ' . PRIVMSGS_TO_TABLE . ' t, ' . PRIVMSGS_TABLE . ' p, ' . USERS_TABLE . ' u
			WHERE ' . $sql_where . '
				AND t.msg_id = p.msg_id
				AND p.author_id = u.user_id
			ORDER BY p.message_time DESC';
		$result = $this->db->sql_query_limit($sql, $limit, $start);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return [
			'pagination'	=> ['limit' => $limit, 'start' => $start, 'total' => $total, 'count' => count($rows)],
			'messages'		=> array_map([$this, 'format_message_summary'], $rows),
		];
	}

	/**
	 * @param int	$msg_id
	 * @return array
	 */
	public function get_message($msg_id)
	{
		$this->assert_can_read();
		$this->sort_new_messages();

		$user_id = (int) $this->user->data['user_id'];

		$sql = 'SELECT t.msg_id, t.folder_id, t.pm_unread, p.message_subject, p.message_text, p.bbcode_uid, p.bbcode_bitfield, p.message_time, p.author_id, u.username
			FROM ' . PRIVMSGS_TO_TABLE . ' t, ' . PRIVMSGS_TABLE . ' p, ' . USERS_TABLE . ' u
			WHERE t.msg_id = ' . (int) $msg_id . '
				AND t.user_id = ' . (int) $user_id . '
				AND t.pm_deleted = 0
				AND t.folder_id <> ' . PRIVMSGS_HOLD_BOX . '
				AND t.msg_id = p.msg_id
				AND p.author_id = u.user_id';
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('message_not_found', 404);
		}

		if ((int) $row['pm_unread'])
		{
			$this->include_pm_functions();
			update_unread_status(1, (int) $row['msg_id'], $user_id, (int) $row['folder_id']);
		}

		return $this->format_message_detail($row);
	}

	/**
	 * @param string	$to
	 * @param string	$subject
	 * @param string	$content
	 * @return array
	 */
	public function send_message($to, $subject, $content)
	{
		$this->assert_can_send();

		$to = trim((string) $to);
		$subject = utf8_encode_ucr(trim((string) $subject));
		$content = trim((string) $content);

		if ($to === '' || $subject === '' || $content === '')
		{
			throw new api_exception('missing_fields', 400);
		}

		$recipient = $this->load_recipient($to);
		$this->assert_recipient_allows_pm($recipient);

		if (utf8_strlen($subject) > self::MAX_SUBJECT_LENGTH)
		{
			throw new api_exception('subject_too_long', 400);
		}

		$this->include_pm_functions();

		$bbcode_status = (bool) $this->config['allow_bbcode'] && (bool) $this->config['auth_bbcode_pm'] && $this->auth->acl_get('u_pm_bbcode');
		$smilies_status = (bool) $this->config['allow_smilies'] && (bool) $this->config['auth_smilies_pm'] && $this->auth->acl_get('u_pm_smilies');
		$img_status = (bool) $this->config['auth_img_pm'] && $this->auth->acl_get('u_pm_img');
		$flash_status = (bool) $this->config['auth_flash_pm'] && $this->auth->acl_get('u_pm_flash');
		$url_status = (bool) $this->config['allow_post_links'];

		$message_parser = new \parse_message($content);
		$message_parser->parse($bbcode_status, $url_status, $smilies_status, $img_status, $flash_status, true, $url_status);

		if (!empty($message_parser->warn_msg))
		{
			throw new api_exception('message_rejected', 400);
		}

		$pm_data = [
			'msg_id'				=> 0,
			'from_user_id'			=> (int) $this->user->data['user_id'],
			'from_user_ip'			=> $this->user->ip,
			'from_username'			=> $this->user->data['username'],
			'reply_from_root_level'	=> 0,
			'reply_from_msg_id'		=> 0,
			'icon_id'				=> 0,
			'enable_sig'			=> false,
			'enable_bbcode'			=> $bbcode_status,
			'enable_smilies'		=> $smilies_status,
			'enable_urls'			=> $url_status,
			'bbcode_bitfield'		=> $message_parser->bbcode_bitfield,
			'bbcode_uid'			=> $message_parser->bbcode_uid,
			'message'				=> $message_parser->message,
			'attachment_data'		=> [],
			'filename_data'			=> [],
			'address_list'			=> ['u' => [(int) $recipient['user_id'] => 'to']],
		];

		$msg_id = submit_pm('post', $subject, $pm_data);

		return [
			'msg_id'	=> (int) $msg_id,
			'to'		=> ['user_id' => (int) $recipient['user_id'], 'username' => text::plain($recipient['username'])],
		];
	}

	/**
	 * @param array	$row
	 * @return array
	 */
	protected function format_message_summary(array $row)
	{
		return [
			'msg_id'		=> (int) $row['msg_id'],
			'subject'		=> text::plain($row['message_subject']),
			'author_id'		=> (int) $row['author_id'],
			'author'		=> text::plain($row['username']),
			'sent_time'		=> (int) $row['message_time'],
			'unread'		=> (bool) $row['pm_unread'],
		];
	}

	/**
	 * @param array	$row
	 * @return array
	 */
	protected function format_message_detail(array $row)
	{
		$parse_flags = ((int) $row['bbcode_bitfield'] ? OPTION_FLAG_BBCODE : 0) | OPTION_FLAG_SMILIES;

		return [
			'msg_id'			=> (int) $row['msg_id'],
			'subject'			=> text::plain($row['message_subject']),
			'author_id'			=> (int) $row['author_id'],
			'author'			=> text::plain($row['username']),
			'sent_time'			=> (int) $row['message_time'],
			'unread'			=> (bool) $row['pm_unread'],
			'content_html'		=> generate_text_for_display($row['message_text'], $row['bbcode_uid'], $row['bbcode_bitfield'], $parse_flags, true),
			'content_bbcode'	=> generate_text_for_edit($row['message_text'], $row['bbcode_uid'], $parse_flags)['text'],
		];
	}

	/**
	 * @param string	$to
	 * @return array
	 */
	protected function load_recipient($to)
	{
		$to = trim((string) $to);

		if (ctype_digit($to))
		{
			$sql_where = 'user_id = ' . (int) $to;
		}
		else
		{
			$sql_where = "username_clean = '" . $this->db->sql_escape(utf8_clean_string($to)) . "'";
		}

		$sql = 'SELECT user_id, username, user_type
			FROM ' . USERS_TABLE . '
			WHERE ' . $sql_where;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || (int) $row['user_id'] === ANONYMOUS || in_array((int) $row['user_type'], [USER_INACTIVE, USER_IGNORE], true))
		{
			throw new api_exception('member_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param array	$recipient
	 * @return void
	 */
	protected function assert_recipient_allows_pm(array $recipient)
	{
		$can_ignore_allow_pm = $this->auth->acl_gets('a_', 'm_') || $this->auth->acl_getf_global('m_');

		if ($can_ignore_allow_pm)
		{
			return;
		}

		$sql = 'SELECT user_allow_pm FROM ' . USERS_TABLE . '
			WHERE user_id = ' . (int) $recipient['user_id'];
		$result = $this->db->sql_query($sql);
		$allow_pm = (int) $this->db->sql_fetchfield('user_allow_pm');
		$this->db->sql_freeresult($result);

		if (!$allow_pm)
		{
			throw new api_exception('pm_not_allowed', 403);
		}
	}

	/**
	 * @return void
	 */
	protected function assert_can_use_pm()
	{
		if (!$this->config['allow_privmsg'])
		{
			throw new api_exception('messages_disabled', 403);
		}
	}

	/**
	 * @return void
	 */
	protected function assert_can_read()
	{
		$this->assert_can_use_pm();

		if (!$this->auth->acl_get('u_readpm'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}
	}

	/**
	 * @return void
	 */
	protected function assert_can_send()
	{
		$this->assert_can_use_pm();

		if (!$this->auth->acl_get('u_sendpm'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}
	}

	/**
	 * @return void
	 */
	protected function sort_new_messages()
	{
		if (!(int) $this->user->data['user_new_privmsg'])
		{
			return;
		}

		if (!function_exists('submit_pm'))
		{
			include($this->root_path . 'includes/functions_privmsgs.' . $this->php_ext);
		}

		if (!isset($this->user->data['message_limit']))
		{
			set_user_message_limit();
		}

		global $global_privmsgs_rules;

		place_pm_into_folder($global_privmsgs_rules);
	}

	/**
	 * @param int	$limit
	 * @return int
	 */
	protected function clamp_limit($limit)
	{
		$limit = (int) $limit;

		if ($limit <= 0)
		{
			return self::DEFAULT_LIMIT;
		}

		return min(self::MAX_LIMIT, $limit);
	}

	/**
	 * @return void
	 */
	protected function include_pm_functions()
	{
		if (!function_exists('submit_pm'))
		{
			include($this->root_path . 'includes/functions_privmsgs.' . $this->php_ext);
		}

		if (!class_exists('parse_message', false))
		{
			include($this->root_path . 'includes/message_parser.' . $this->php_ext);
		}
	}
}
