<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\controller;

use dmzx\phpbbapi\core\attachment_manager;
use dmzx\phpbbapi\core\audit_logger;
use dmzx\phpbbapi\core\auth_resolver;
use dmzx\phpbbapi\core\content_reader;
use dmzx\phpbbapi\core\credential_manager;
use dmzx\phpbbapi\core\exception\api_exception;
use dmzx\phpbbapi\core\member_manager;
use dmzx\phpbbapi\core\message_manager;
use dmzx\phpbbapi\core\moderation_manager;
use dmzx\phpbbapi\core\notification_manager;
use dmzx\phpbbapi\core\poll_manager;
use dmzx\phpbbapi\core\post_composer;
use dmzx\phpbbapi\core\rate_limiter;
use dmzx\phpbbapi\core\report_manager;
use dmzx\phpbbapi\core\text;
use dmzx\phpbbapi\core\webhook_dispatcher;
use phpbb\config\config;
use phpbb\request\request;
use phpbb\user;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\StreamedResponse;

class api_controller
{
	const STREAM_LOOKBACK_SECONDS = 2;
	const STREAM_EVENT_LIMIT = 20;
	const STREAM_RETRY_MS = 5000;
	const MAX_ATTACHMENTS_PER_REQUEST = 10;

	/** @var auth_resolver */
	protected $auth_resolver;

	/** @var rate_limiter */
	protected $rate_limiter;

	/** @var audit_logger */
	protected $audit_logger;

	/** @var credential_manager */
	protected $credential_manager;

	/** @var content_reader */
	protected $content_reader;

	/** @var post_composer */
	protected $post_composer;

	/** @var moderation_manager */
	protected $moderation_manager;

	/** @var member_manager */
	protected $member_manager;

	/** @var message_manager */
	protected $message_manager;

	/** @var attachment_manager */
	protected $attachment_manager;

	/** @var poll_manager */
	protected $poll_manager;

	/** @var report_manager */
	protected $report_manager;

	/** @var notification_manager */
	protected $notification_manager;

	/** @var webhook_dispatcher */
	protected $webhooks;

	/** @var config */
	protected $config;

	/** @var request */
	protected $request;

	/** @var user */
	protected $user;

	/** @var array|null */
	protected $json_body;

	/**
	 * @param auth_resolver			$auth_resolver
	 * @param rate_limiter			$rate_limiter
	 * @param audit_logger			$audit_logger
	 * @param credential_manager	$credential_manager
	 * @param content_reader		$content_reader
	 * @param post_composer			$post_composer
	 * @param moderation_manager	$moderation_manager
	 * @param member_manager		$member_manager
	 * @param message_manager		$message_manager
	 * @param attachment_manager	$attachment_manager
	 * @param poll_manager			$poll_manager
	 * @param report_manager		$report_manager
	 * @param notification_manager	$notification_manager
	 * @param webhook_dispatcher	$webhooks
	 * @param config				$config
	 * @param request				$request
	 * @param user					$user
	 */
	public function __construct(auth_resolver $auth_resolver, rate_limiter $rate_limiter, audit_logger $audit_logger, credential_manager $credential_manager, content_reader $content_reader, post_composer $post_composer, moderation_manager $moderation_manager, member_manager $member_manager, message_manager $message_manager, attachment_manager $attachment_manager, poll_manager $poll_manager, report_manager $report_manager, notification_manager $notification_manager, webhook_dispatcher $webhooks, config $config, request $request, user $user)
	{
		$this->auth_resolver = $auth_resolver;
		$this->rate_limiter = $rate_limiter;
		$this->audit_logger = $audit_logger;
		$this->credential_manager = $credential_manager;
		$this->content_reader = $content_reader;
		$this->post_composer = $post_composer;
		$this->moderation_manager = $moderation_manager;
		$this->member_manager = $member_manager;
		$this->message_manager = $message_manager;
		$this->attachment_manager = $attachment_manager;
		$this->poll_manager = $poll_manager;
		$this->report_manager = $report_manager;
		$this->notification_manager = $notification_manager;
		$this->webhooks = $webhooks;
		$this->config = $config;
		$this->request = $request;
		$this->user = $user;
	}

	/**
	 * @param string	$path
	 * @return JsonResponse
	 */
	public function handle_preflight($path = '')
	{
		return $this->apply_cors(new JsonResponse(null, 204));
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_me()
	{
		return $this->run(null, 'GET /api/v1/me', function (array $credential) {
			return [
				'success'			=> true,
				'user_id'			=> (int) $credential['user_id'],
				'username'			=> text::plain($this->user->data['username']),
				'is_founder'		=> (int) $this->user->data['user_type'] === USER_FOUNDER,
				'scopes'			=> $this->credential_manager->get_scopes($credential),
				'allowed_forums'	=> $this->credential_manager->get_forum_allowlist($credential),
			];
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_list_forums()
	{
		return $this->run('forums.read', 'GET /api/v1/forums', function (array $credential) {
			$forums = $this->content_reader->list_forums();
			$allowlist = $this->credential_manager->get_forum_allowlist($credential);

			if (!empty($allowlist))
			{
				$forums = array_values(array_filter($forums, static function ($forum) use ($allowlist) {
					return in_array($forum['forum_id'], $allowlist, true);
				}));
			}

			return ['success' => true, 'forums' => $forums];
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_topics_bulk()
	{
		return $this->run('topics.read', 'GET /api/v1/topics', function (array $credential) {
			$ids = $this->parse_bulk_ids($this->request->variable('ids', ''));
			$allowlist = $this->credential_manager->get_forum_allowlist($credential);

			return ['success' => true, 'topics' => $this->content_reader->get_topics_by_ids($ids, $allowlist)];
		});
	}

	/**
	 * @param int	$forum_id
	 * @return JsonResponse
	 */
	public function handle_forum_topics($forum_id)
	{
		$forum_id = (int) $forum_id;

		if ($this->request->server('REQUEST_METHOD') === 'POST')
		{
			return $this->run('topics.write', 'POST /api/v1/forums/{forum_id}/topics', function (array $credential) use ($forum_id) {
				$this->assert_forum_allowed($credential, $forum_id);

				$attachment_data = $this->collect_attachment($credential, $forum_id);
				$title = (string) $this->input('title', '');

				$result = $this->post_composer->create_topic(
					$forum_id,
					$title,
					(string) $this->input('content', ''),
					(string) $this->input('type', 'normal'),
					$attachment_data,
					$this->input_poll()
				);

				$this->webhooks->dispatch('topic.created', [
					'topic_id'	=> $result['topic_id'],
					'post_id'	=> $result['post_id'],
					'forum_id'	=> $forum_id,
					'title'		=> text::plain($title),
					'url'		=> $result['url'],
				]);

				return ['success' => true, '_status' => 201] + $result;
			});
		}

		return $this->run('topics.read', 'GET /api/v1/forums/{forum_id}/topics', function (array $credential) use ($forum_id) {
			$this->assert_forum_allowed($credential, $forum_id);

			$data = $this->content_reader->list_topics($forum_id, (int) $this->request->variable('limit', content_reader::DEFAULT_LIMIT), (int) $this->request->variable('start', 0));

			return ['success' => true] + $data;
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic($topic_id)
	{
		$topic_id = (int) $topic_id;
		$method = $this->resolve_method();

		if ($method === 'PATCH')
		{
			return $this->run('topics.write', 'PATCH /api/v1/topics/{topic_id}', function (array $credential) use ($topic_id) {
				$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
				$this->assert_forum_allowed($credential, $forum_id);

				$title = (string) $this->input('title', '');
				$result = $this->post_composer->update_topic($topic_id, $title, (string) $this->input('content', ''));

				$this->webhooks->dispatch('topic.updated', [
					'topic_id'	=> $result['topic_id'],
					'post_id'	=> $result['post_id'],
					'forum_id'	=> $forum_id,
					'title'		=> text::plain($title),
					'url'		=> $result['url'],
				]);

				return ['success' => true] + $result;
			});
		}

		if ($method === 'DELETE')
		{
			return $this->run('topics.delete', 'DELETE /api/v1/topics/{topic_id}', function (array $credential) use ($topic_id) {
				$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
				$this->assert_forum_allowed($credential, $forum_id);

				$this->moderation_manager->delete_topic($topic_id);

				$this->webhooks->dispatch('topic.deleted', ['topic_id' => $topic_id, 'forum_id' => $forum_id]);

				return ['success' => true];
			});
		}

		if ($method === 'POST')
		{
			return $this->run(null, 'POST /api/v1/topics/{topic_id}', function () {
				throw new api_exception('method_override_required', 400);
			});
		}

		return $this->run('topics.read', 'GET /api/v1/topics/{topic_id}', function (array $credential) use ($topic_id) {
			$this->assert_forum_allowed($credential, $this->content_reader->resolve_topic_forum_id($topic_id));

			return ['success' => true, 'topic' => $this->content_reader->get_topic($topic_id)];
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_lock($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.moderate', 'POST /api/v1/topics/{topic_id}/lock', function (array $credential) use ($topic_id) {
			$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$this->moderation_manager->lock_topic($topic_id);

			$this->webhooks->dispatch('topic.locked', ['topic_id' => $topic_id, 'forum_id' => $forum_id]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_unlock($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.moderate', 'POST /api/v1/topics/{topic_id}/unlock', function (array $credential) use ($topic_id) {
			$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$this->moderation_manager->unlock_topic($topic_id);

			$this->webhooks->dispatch('topic.unlocked', ['topic_id' => $topic_id, 'forum_id' => $forum_id]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_poll_vote($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.vote', 'POST /api/v1/topics/{topic_id}/poll/vote', function (array $credential) use ($topic_id) {
			$this->assert_forum_allowed($credential, $this->content_reader->resolve_topic_forum_id($topic_id));

			$result = $this->poll_manager->vote($topic_id, $this->input_ids('option_ids'));

			return ['success' => true] + $result;
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_soft_delete($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.delete', 'POST /api/v1/topics/{topic_id}/soft-delete', function (array $credential) use ($topic_id) {
			$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$reason = (string) $this->input('reason', '');
			$this->moderation_manager->soft_delete_topic($topic_id, $reason);

			$this->webhooks->dispatch('topic.soft_deleted', ['topic_id' => $topic_id, 'forum_id' => $forum_id, 'reason' => text::plain($reason)]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_restore($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.moderate', 'POST /api/v1/topics/{topic_id}/restore', function (array $credential) use ($topic_id) {
			$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$this->moderation_manager->restore_topic($topic_id);

			$this->webhooks->dispatch('topic.restored', ['topic_id' => $topic_id, 'forum_id' => $forum_id]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_move($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.manage', 'POST /api/v1/topics/{topic_id}/move', function (array $credential) use ($topic_id) {
			$to_forum_id = (int) $this->input('to_forum_id', 0);
			$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);

			$this->assert_forum_allowed($credential, $forum_id);
			$this->assert_forum_allowed($credential, $to_forum_id);

			$this->moderation_manager->move_topic($topic_id, $to_forum_id);

			$this->webhooks->dispatch('topic.moved', ['topic_id' => $topic_id, 'forum_id' => $forum_id, 'to_forum_id' => $to_forum_id]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_merge($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.manage', 'POST /api/v1/topics/{topic_id}/merge', function (array $credential) use ($topic_id) {
			$to_topic_id = (int) $this->input('to_topic_id', 0);
			$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);

			$this->assert_forum_allowed($credential, $forum_id);
			$this->assert_forum_allowed($credential, $this->content_reader->resolve_topic_forum_id($to_topic_id));

			$this->moderation_manager->merge_topic($topic_id, $to_topic_id, $this->input_ids('post_ids'));

			$this->webhooks->dispatch('topic.merged', ['topic_id' => $topic_id, 'forum_id' => $forum_id, 'to_topic_id' => $to_topic_id]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_split($topic_id)
	{
		$topic_id = (int) $topic_id;

		return $this->run('topics.manage', 'POST /api/v1/topics/{topic_id}/split', function (array $credential) use ($topic_id) {
			$to_forum_id = (int) $this->input('to_forum_id', 0);
			$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
			$post_ids = $this->input_ids('post_ids');

			$this->assert_forum_allowed($credential, $forum_id);
			$this->assert_forum_allowed($credential, $to_forum_id);

			$result = $this->moderation_manager->split_topic(
				$topic_id,
				$post_ids,
				(string) $this->input('subject', ''),
				$to_forum_id
			);

			$this->webhooks->dispatch('topic.split', [
				'topic_id'		=> $topic_id,
				'forum_id'		=> $forum_id,
				'new_topic_id'	=> $result['topic_id'],
				'to_forum_id'	=> $to_forum_id,
				'post_ids'		=> $post_ids,
			]);

			return ['success' => true] + $result;
		});
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_posts($topic_id)
	{
		$topic_id = (int) $topic_id;

		if ($this->request->server('REQUEST_METHOD') === 'POST')
		{
			return $this->run('posts.write', 'POST /api/v1/topics/{topic_id}/posts', function (array $credential) use ($topic_id) {
				$forum_id = $this->content_reader->resolve_topic_forum_id($topic_id);
				$this->assert_forum_allowed($credential, $forum_id);

				$attachment_data = $this->collect_attachment($credential, $forum_id);

				$result = $this->post_composer->create_reply($topic_id, (string) $this->input('content', ''), $attachment_data);

				$this->webhooks->dispatch('post.created', [
					'post_id'	=> $result['post_id'],
					'topic_id'	=> $topic_id,
					'forum_id'	=> $forum_id,
					'url'		=> $result['url'],
				]);

				return ['success' => true, '_status' => 201] + $result;
			});
		}

		return $this->run('posts.read', 'GET /api/v1/topics/{topic_id}/posts', function (array $credential) use ($topic_id) {
			$this->assert_forum_allowed($credential, $this->content_reader->resolve_topic_forum_id($topic_id));

			$data = $this->content_reader->list_posts($topic_id, (int) $this->request->variable('limit', content_reader::DEFAULT_LIMIT), (int) $this->request->variable('start', 0));

			return ['success' => true] + $data;
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_posts_bulk()
	{
		return $this->run('posts.read', 'GET /api/v1/posts', function (array $credential) {
			$ids = $this->parse_bulk_ids($this->request->variable('ids', ''));
			$allowlist = $this->credential_manager->get_forum_allowlist($credential);

			return ['success' => true, 'posts' => $this->content_reader->get_posts_by_ids($ids, $allowlist)];
		});
	}

	/**
	 * @param int	$post_id
	 * @return JsonResponse
	 */
	public function handle_post($post_id)
	{
		$post_id = (int) $post_id;
		$method = $this->resolve_method();

		if ($method === 'PATCH')
		{
			return $this->run('posts.write', 'PATCH /api/v1/posts/{post_id}', function (array $credential) use ($post_id) {
				$forum_id = $this->content_reader->resolve_post_forum_id($post_id);
				$this->assert_forum_allowed($credential, $forum_id);

				$result = $this->post_composer->update_post($post_id, (string) $this->input('content', ''));

				$this->webhooks->dispatch('post.updated', [
					'post_id'	=> $result['post_id'],
					'topic_id'	=> $result['topic_id'],
					'forum_id'	=> $forum_id,
					'url'		=> $result['url'],
				]);

				return ['success' => true] + $result;
			});
		}

		if ($method === 'DELETE')
		{
			return $this->run('posts.delete', 'DELETE /api/v1/posts/{post_id}', function (array $credential) use ($post_id) {
				$forum_id = $this->content_reader->resolve_post_forum_id($post_id);
				$this->assert_forum_allowed($credential, $forum_id);

				$this->moderation_manager->delete_post($post_id);

				$this->webhooks->dispatch('post.deleted', ['post_id' => $post_id, 'forum_id' => $forum_id]);

				return ['success' => true];
			});
		}

		if ($method === 'POST')
		{
			return $this->run(null, 'POST /api/v1/posts/{post_id}', function () {
				throw new api_exception('method_override_required', 400);
			});
		}

		return $this->run('posts.read', 'GET /api/v1/posts/{post_id}', function (array $credential) use ($post_id) {
			$this->assert_forum_allowed($credential, $this->content_reader->resolve_post_forum_id($post_id));

			return ['success' => true] + $this->content_reader->get_post($post_id);
		});
	}

	/**
	 * @param int	$post_id
	 * @return JsonResponse
	 */
	public function handle_post_approve($post_id)
	{
		$post_id = (int) $post_id;

		return $this->run('posts.approve', 'POST /api/v1/posts/{post_id}/approve', function (array $credential) use ($post_id) {
			$forum_id = $this->content_reader->resolve_post_forum_id($post_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$this->moderation_manager->approve_post($post_id);

			$this->webhooks->dispatch('post.approved', ['post_id' => $post_id, 'forum_id' => $forum_id]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$post_id
	 * @return JsonResponse
	 */
	public function handle_post_disapprove($post_id)
	{
		$post_id = (int) $post_id;

		return $this->run('posts.approve', 'POST /api/v1/posts/{post_id}/disapprove', function (array $credential) use ($post_id) {
			$forum_id = $this->content_reader->resolve_post_forum_id($post_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$reason = (string) $this->input('reason', '');
			$this->moderation_manager->disapprove_post($post_id, $reason);

			$this->webhooks->dispatch('post.disapproved', ['post_id' => $post_id, 'forum_id' => $forum_id, 'reason' => text::plain($reason)]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$post_id
	 * @return JsonResponse
	 */
	public function handle_post_soft_delete($post_id)
	{
		$post_id = (int) $post_id;

		return $this->run('posts.delete', 'POST /api/v1/posts/{post_id}/soft-delete', function (array $credential) use ($post_id) {
			$forum_id = $this->content_reader->resolve_post_forum_id($post_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$reason = (string) $this->input('reason', '');
			$this->moderation_manager->soft_delete_post($post_id, $reason);

			$this->webhooks->dispatch('post.soft_deleted', ['post_id' => $post_id, 'forum_id' => $forum_id, 'reason' => text::plain($reason)]);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$post_id
	 * @return JsonResponse
	 */
	public function handle_post_restore($post_id)
	{
		$post_id = (int) $post_id;

		return $this->run('posts.approve', 'POST /api/v1/posts/{post_id}/restore', function (array $credential) use ($post_id) {
			$forum_id = $this->content_reader->resolve_post_forum_id($post_id);
			$this->assert_forum_allowed($credential, $forum_id);

			$this->moderation_manager->restore_post($post_id);

			$this->webhooks->dispatch('post.restored', ['post_id' => $post_id, 'forum_id' => $forum_id]);

			return ['success' => true];
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_search()
	{
		return $this->run('search.read', 'GET /api/v1/search', function (array $credential) {
			$data = $this->content_reader->search(
				$this->request->variable('type', 'posts'),
				$this->request->variable('q', '', true),
				(int) $this->request->variable('forum_id', 0),
				$this->request->variable('author', '', true),
				(int) $this->request->variable('limit', content_reader::DEFAULT_LIMIT),
				(int) $this->request->variable('start', 0),
				$this->credential_manager->get_forum_allowlist($credential)
			);

			return ['success' => true] + $data;
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_members()
	{
		if ($this->request->server('REQUEST_METHOD') === 'POST')
		{
			return $this->run('members.write', 'POST /api/v1/members', function () {
				$result = $this->member_manager->register_member(
					(string) $this->input('username', ''),
					(string) $this->input('password', ''),
					(string) $this->input('email', '')
				);

				$this->webhooks->dispatch('member.registered', $result);

				return ['success' => true, '_status' => 201] + $result;
			});
		}

		return $this->run('members.read', 'GET /api/v1/members', function () {
			$data = $this->member_manager->list_members(
				$this->request->variable('q', '', true),
				(int) $this->request->variable('limit', member_manager::DEFAULT_LIMIT),
				(int) $this->request->variable('start', 0)
			);

			return ['success' => true] + $data;
		});
	}

	/**
	 * @param int	$user_id
	 * @return JsonResponse
	 */
	public function handle_member($user_id)
	{
		$user_id = (int) $user_id;
		$method = $this->resolve_method();

		if ($method === 'DELETE')
		{
			return $this->run('members.write', 'DELETE /api/v1/members/{user_id}', function () use ($user_id) {
				$this->member_manager->delete_member($user_id, (string) $this->input('mode', 'retain'));

				return ['success' => true];
			});
		}

		if ($method === 'POST')
		{
			return $this->run(null, 'POST /api/v1/members/{user_id}', function () {
				throw new api_exception('method_override_required', 400);
			});
		}

		return $this->run('members.read', 'GET /api/v1/members/{user_id}', function () use ($user_id) {
			return ['success' => true, 'member' => $this->member_manager->get_member($user_id)];
		});
	}

	/**
	 * @param int	$user_id
	 * @return JsonResponse
	 */
	public function handle_member_groups($user_id)
	{
		$user_id = (int) $user_id;

		if ($this->request->server('REQUEST_METHOD') === 'POST')
		{
			return $this->run('members.write', 'POST /api/v1/members/{user_id}/groups', function () use ($user_id) {
				$group_id = (int) $this->input('group_id', 0);

				$this->member_manager->add_to_group($user_id, $group_id);

				return ['success' => true];
			});
		}

		return $this->run('members.read', 'GET /api/v1/members/{user_id}/groups', function () use ($user_id) {
			return ['success' => true, 'groups' => $this->member_manager->get_member_groups($user_id)];
		});
	}

	/**
	 * @param int	$user_id
	 * @param int	$group_id
	 * @return JsonResponse
	 */
	public function handle_member_group($user_id, $group_id)
	{
		$user_id = (int) $user_id;
		$group_id = (int) $group_id;
		$method = $this->resolve_method();

		if ($method === 'DELETE')
		{
			return $this->run('members.write', 'DELETE /api/v1/members/{user_id}/groups/{group_id}', function () use ($user_id, $group_id) {
				$this->member_manager->remove_from_group($user_id, $group_id);

				return ['success' => true];
			});
		}

		return $this->run(null, 'POST /api/v1/members/{user_id}/groups/{group_id}', function () {
			throw new api_exception('method_override_required', 400);
		});
	}

	/**
	 * @param int	$user_id
	 * @return JsonResponse
	 */
	public function handle_member_ban($user_id)
	{
		$user_id = (int) $user_id;

		return $this->run('members.ban', 'POST /api/v1/members/{user_id}/ban', function () use ($user_id) {
			$this->member_manager->ban_member(
				$user_id,
				(int) $this->input('length_minutes', 0),
				(string) $this->input('reason', ''),
				(string) $this->input('public_reason', '')
			);

			return ['success' => true];
		});
	}

	/**
	 * @param int	$user_id
	 * @return JsonResponse
	 */
	public function handle_member_unban($user_id)
	{
		$user_id = (int) $user_id;

		return $this->run('members.ban', 'POST /api/v1/members/{user_id}/unban', function () use ($user_id) {
			$this->member_manager->unban_member($user_id);

			return ['success' => true];
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_reports()
	{
		return $this->run('reports.read', 'GET /api/v1/reports', function () {
			$data = $this->report_manager->list_reports(
				(string) $this->request->variable('status', 'open'),
				(int) $this->request->variable('limit', report_manager::DEFAULT_LIMIT),
				(int) $this->request->variable('start', 0)
			);

			return ['success' => true] + $data;
		});
	}

	/**
	 * @param int	$report_id
	 * @return JsonResponse
	 */
	public function handle_report_resolve($report_id)
	{
		$report_id = (int) $report_id;

		return $this->run('reports.manage', 'POST /api/v1/reports/{report_id}/resolve', function () use ($report_id) {
			$this->report_manager->resolve_report($report_id);

			return ['success' => true];
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_notifications()
	{
		return $this->run('notifications.read', 'GET /api/v1/notifications', function () {
			$data = $this->notification_manager->list_notifications(
				(int) $this->request->variable('limit', notification_manager::DEFAULT_LIMIT),
				(int) $this->request->variable('start', 0)
			);

			return ['success' => true] + $data;
		});
	}

	/**
	 * @param int	$notification_id
	 * @return JsonResponse
	 */
	public function handle_notification_read($notification_id)
	{
		$notification_id = (int) $notification_id;

		return $this->run('notifications.read', 'POST /api/v1/notifications/{notification_id}/read', function () use ($notification_id) {
			$this->notification_manager->mark_read($notification_id);

			return ['success' => true];
		});
	}

	/**
	 * @return Response
	 */
	public function handle_stream()
	{
		return $this->run_binary('stream.read', 'GET /api/v1/stream', function (array $credential) {
			$readable_forum_ids = $this->content_reader->get_readable_forum_ids();
			$allowlist = $this->credential_manager->get_forum_allowlist($credential);

			if (!empty($allowlist))
			{
				$readable_forum_ids = array_values(array_intersect($readable_forum_ids, $allowlist));
			}

			$since_q = (int) $this->request->variable('since', 0);
			$last_event = content_reader::parse_event_id((string) $this->request->server('HTTP_LAST_EVENT_ID'));

			if ($since_q > 0)
			{
				$since = $since_q;
				$after = [];
			}
			else if ($last_event['time'] > 0)
			{
				$since = $last_event['time'];
				$after = $last_event;
			}
			else
			{
				$since = time() - self::STREAM_LOOKBACK_SECONDS;
				$after = [];
			}

			$events = $this->content_reader->list_new_activity($readable_forum_ids, $since, self::STREAM_EVENT_LIMIT, $after);

			return new Response($this->format_sse_batch($events, time()), 200, [
				'Content-Type'		=> 'text/event-stream; charset=UTF-8',
				'Cache-Control'		=> 'no-cache',
				'X-Accel-Buffering'	=> 'no',
			]);
		}, true);
	}

	/**
	 * @param array	$events	list_new_activity() rows
	 * @param int	$now
	 * @return string	one text/event-stream batch, terminated by a "done" event and a retry hint
	 */
	protected function format_sse_batch(array $events, $now)
	{
		$body = '';

		foreach ($events as $ev)
		{
			$body .= 'id: ' . $ev['id'] . "\n";
			$body .= 'event: ' . $ev['event'] . "\n";
			$body .= 'data: ' . json_encode($ev) . "\n\n";
		}

		$body .= 'event: done' . "\n";
		$body .= 'data: {"t":' . (int) $now . '}' . "\n\n";
		$body .= 'retry: ' . self::STREAM_RETRY_MS . "\n";
		$body .= ': ok' . "\n\n";

		return $body;
	}

	/**
	 * @param int	$topic_id
	 * @return JsonResponse
	 */
	public function handle_topic_watch($topic_id)
	{
		$topic_id = (int) $topic_id;
		$method = $this->resolve_method();

		return $this->run('topics.watch', $method . ' /api/v1/topics/{topic_id}/watch', function (array $credential) use ($topic_id, $method) {
			$this->assert_forum_allowed($credential, $this->content_reader->resolve_topic_forum_id($topic_id));

			if ($method === 'DELETE')
			{
				$this->notification_manager->unwatch_topic($topic_id);
			}
			else
			{
				$this->notification_manager->watch_topic($topic_id);
			}

			return ['success' => true];
		});
	}

	/**
	 * @param int	$forum_id
	 * @return JsonResponse
	 */
	public function handle_forum_watch($forum_id)
	{
		$forum_id = (int) $forum_id;
		$method = $this->resolve_method();

		return $this->run('topics.watch', $method . ' /api/v1/forums/{forum_id}/watch', function (array $credential) use ($forum_id, $method) {
			$this->assert_forum_allowed($credential, $forum_id);

			if ($method === 'DELETE')
			{
				$this->notification_manager->unwatch_forum($forum_id);
			}
			else
			{
				$this->notification_manager->watch_forum($forum_id);
			}

			return ['success' => true];
		});
	}

	/**
	 * @return JsonResponse
	 */
	public function handle_messages()
	{
		if ($this->request->server('REQUEST_METHOD') === 'POST')
		{
			return $this->run('messages.write', 'POST /api/v1/messages', function () {
				$result = $this->message_manager->send_message(
					(string) $this->input('to', ''),
					(string) $this->input('subject', ''),
					(string) $this->input('content', '')
				);

				return ['success' => true, '_status' => 201] + $result;
			});
		}

		return $this->run('messages.read', 'GET /api/v1/messages', function () {
			$data = $this->message_manager->list_inbox(
				(int) $this->request->variable('limit', message_manager::DEFAULT_LIMIT),
				(int) $this->request->variable('start', 0)
			);

			return ['success' => true] + $data;
		});
	}

	/**
	 * @param int	$msg_id
	 * @return JsonResponse
	 */
	public function handle_message($msg_id)
	{
		$msg_id = (int) $msg_id;

		return $this->run('messages.read', 'GET /api/v1/messages/{msg_id}', function () use ($msg_id) {
			return ['success' => true, 'message' => $this->message_manager->get_message($msg_id)];
		});
	}

	/**
	 * @param int	$attachment_id
	 * @return Response
	 */
	public function handle_attachment_download($attachment_id)
	{
		$attachment_id = (int) $attachment_id;

		return $this->run_binary('posts.read', 'GET /api/v1/attachments/{attachment_id}', function () use ($attachment_id) {
			$attachment = $this->attachment_manager->load_for_download($attachment_id);
			$handle = $this->attachment_manager->open_stream($attachment);

			$response = new StreamedResponse(function () use ($handle) {
				fpassthru($handle);
				fclose($handle);
			});

			$response->headers->set('Content-Type', $attachment['mimetype'] !== '' ? $attachment['mimetype'] : 'application/octet-stream');
			$response->headers->set('Content-Disposition', $response->headers->makeDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, $attachment['real_filename']));

			return $response;
		});
	}

	/**
	 * @param array		$credential
	 * @param int		$forum_id
	 * @return array	zero or more attachment_data entries, ready for post_composer
	 */
	protected function collect_attachment(array $credential, $forum_id)
	{
		$fields = $this->attachment_field_names();

		if (!array_filter($fields, [$this, 'has_upload']))
		{
			return [];
		}

		if (!$this->credential_manager->has_scope($credential, 'posts.attach'))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$entries = [];

		foreach ($fields as $field)
		{
			if (!$this->has_upload($field))
			{
				continue;
			}

			$entry = $this->attachment_manager->upload($field, $forum_id, count($entries));

			if ($entry !== null)
			{
				$entries[] = $entry;
			}
		}

		return $entries;
	}

	/**
	 * @return array	['attachment', 'attachment2', ..., 'attachment' . MAX_ATTACHMENTS_PER_REQUEST]
	 */
	protected function attachment_field_names()
	{
		$fields = ['attachment'];

		for ($i = 2; $i <= self::MAX_ATTACHMENTS_PER_REQUEST; $i++)
		{
			$fields[] = 'attachment' . $i;
		}

		return $fields;
	}

	/**
	 * @param string	$field
	 * @return bool
	 */
	protected function has_upload($field)
	{
		$file = $this->request->file($field);

		return isset($file['name']) && $file['name'] !== 'none' && $file['name'] !== '';
	}

	/**
	 * @param string	$raw	comma-separated ids, e.g. "1,2,3"
	 * @return array
	 */
	protected function parse_bulk_ids($raw)
	{
		$raw = trim((string) $raw);

		if ($raw === '')
		{
			return [];
		}

		return array_filter(array_map('intval', explode(',', $raw)), static function ($id) {
			return $id > 0;
		});
	}

	/**
	 * @param string|null	$scope
	 * @param string		$route
	 * @param callable		$action
	 * @return JsonResponse
	 */
	protected function run($scope, $route, callable $action)
	{
		$method = (string) $this->request->server('REQUEST_METHOD');
		$credential = null;
		$rate_info = null;

		try
		{
			$credential = $this->auth_resolver->resolve();

			$rate_info = $this->rate_limiter->check($credential);

			if ($rate_info !== null && !$rate_info['allowed'])
			{
				throw new api_exception('rate_limit_exceeded', 429);
			}

			if ($scope !== null && !$this->credential_manager->has_scope($credential, $scope))
			{
				throw new api_exception('insufficient_permissions', 403);
			}

			$payload = $action($credential);
			$status = $payload['_status'] ?? 200;
			unset($payload['_status']);

			$this->audit_logger->log((int) $credential['credential_id'], (int) $credential['user_id'], (string) $this->request->server('REMOTE_ADDR'), $method, $route, $status, '');

			return $this->apply_rate_headers($this->json($payload, $status), $rate_info);
		}
		catch (api_exception $e)
		{
			$this->audit_logger->log($credential ? (int) $credential['credential_id'] : 0, $credential ? (int) $credential['user_id'] : 0, (string) $this->request->server('REMOTE_ADDR'), $method, $route, $e->get_http_status(), $e->get_error_code());

			return $this->apply_rate_headers($this->json(['success' => false, 'error' => $e->get_error_code()], $e->get_http_status()), $rate_info);
		}
	}

	/**
	 * @param string|null	$scope
	 * @param string		$route
	 * @param callable		$action
	 * @param bool			$allow_query_token	see auth_resolver::resolve()
	 * @return Response
	 */
	protected function run_binary($scope, $route, callable $action, $allow_query_token = false)
	{
		$method = (string) $this->request->server('REQUEST_METHOD');
		$credential = null;
		$rate_info = null;

		try
		{
			$credential = $this->auth_resolver->resolve($allow_query_token);

			$rate_info = $this->rate_limiter->check($credential);

			if ($rate_info !== null && !$rate_info['allowed'])
			{
				throw new api_exception('rate_limit_exceeded', 429);
			}

			if ($scope !== null && !$this->credential_manager->has_scope($credential, $scope))
			{
				throw new api_exception('insufficient_permissions', 403);
			}

			$response = $action($credential);

			$this->audit_logger->log((int) $credential['credential_id'], (int) $credential['user_id'], (string) $this->request->server('REMOTE_ADDR'), $method, $route, $response->getStatusCode(), '');

			return $this->apply_rate_headers($this->apply_cors($response), $rate_info);
		}
		catch (api_exception $e)
		{
			$this->audit_logger->log($credential ? (int) $credential['credential_id'] : 0, $credential ? (int) $credential['user_id'] : 0, (string) $this->request->server('REMOTE_ADDR'), $method, $route, $e->get_http_status(), $e->get_error_code());

			return $this->apply_rate_headers($this->json(['success' => false, 'error' => $e->get_error_code()], $e->get_http_status()), $rate_info);
		}
	}

	/**
	 * @param array	$credential
	 * @param int	$forum_id
	 * @return void
	 */
	protected function assert_forum_allowed(array $credential, $forum_id)
	{
		if (!$this->credential_manager->is_forum_allowed($credential, $forum_id))
		{
			throw new api_exception('forum_not_allowed', 403);
		}
	}

	/**
	 * @return string
	 */
	protected function resolve_method()
	{
		$method = (string) $this->request->server('REQUEST_METHOD');

		if ($method !== 'POST')
		{
			return $method;
		}

		$override = strtoupper((string) $this->request->server('HTTP_X_HTTP_METHOD_OVERRIDE'));

		if ($override === '')
		{
			$override = strtoupper((string) $this->input('_method', ''));
		}

		return in_array($override, ['PATCH', 'DELETE'], true) ? $override : 'POST';
	}

	/**
	 * @param string	$key
	 * @param mixed		$default
	 * @return mixed
	 */
	protected function input($key, $default = '')
	{
		$body = $this->body();

		if (array_key_exists($key, $body))
		{
			return $this->sanitise($body[$key]);
		}

		return $this->request->variable($key, $default, true);
	}

	/**
	 * @param mixed	$value
	 * @return mixed	strings HTML-encoded the way \phpbb\request\type_cast_helper::set_var() does for form input
	 */
	protected function sanitise($value)
	{
		if (is_array($value))
		{
			return array_map([$this, 'sanitise'], $value);
		}

		if (is_string($value))
		{
			$value = utf8_normalize_nfc($value);
			$value = utf8_htmlspecialchars($value);
		}

		return $value;
	}

	/**
	 * @param string	$key
	 * @return array	positive ints, from the JSON body or a form-encoded key[]=1&key[]=2 list
	 */
	protected function input_ids($key)
	{
		$body = $this->body();
		$ids = array_key_exists($key, $body) ? (array) $body[$key] : $this->request->variable($key, [0]);

		return array_values(array_filter(array_map('intval', $ids), static function ($id) {
			return $id > 0;
		}));
	}

	/**
	 * @return array	empty for no poll, else question, options, max_options, length_days, vote_change - from the JSON body or form-encoded poll[question]=..&poll[options][]=..
	 */
	protected function input_poll()
	{
		$body = $this->body();

		if (array_key_exists('poll', $body))
		{
			return (array) $this->sanitise($body['poll']);
		}

		$question = $this->request->variable(['poll', 'question'], '', true);
		$options = $this->request->variable(['poll', 'options'], [''], true);

		if ($question === '' && empty(array_filter($options)))
		{
			return [];
		}

		return [
			'question'		=> $question,
			'options'		=> $options,
			'max_options'	=> $this->request->variable(['poll', 'max_options'], 1),
			'length_days'	=> $this->request->variable(['poll', 'length_days'], 0),
			'vote_change'	=> $this->request->variable(['poll', 'vote_change'], 0),
		];
	}

	/**
	 * @return array
	 */
	protected function body()
	{
		if ($this->json_body === null)
		{
			$decoded = json_decode((string) file_get_contents('php://input'), true);
			$this->json_body = (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : [];
		}

		return $this->json_body;
	}

	/**
	 * @param array	$payload
	 * @param int	$status
	 * @return JsonResponse
	 */
	protected function json(array $payload, $status)
	{
		return $this->apply_cors(new JsonResponse($payload, $status));
	}

	/**
	 * @param Response	$response
	 * @return Response
	 */
	protected function apply_cors(Response $response)
	{
		$origin = (string) $this->request->server('HTTP_ORIGIN');
		$allowed = array_filter(array_map('trim', explode(',', (string) $this->config['phpbbapi_cors_origins'])));

		if ($origin !== '' && in_array($origin, $allowed, true))
		{
			$response->headers->set('Access-Control-Allow-Origin', $origin);
			$response->headers->set('Vary', 'Origin');
			$response->headers->set('Access-Control-Allow-Headers', 'Authorization, X-API-Key, Content-Type');
			$response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
		}

		return $response;
	}

	/**
	 * @param Response	$response
	 * @param array|null	$rate_info	rate_limiter::check()'s return value - null (unlimited credential) sends no headers
	 * @return Response
	 */
	protected function apply_rate_headers(Response $response, $rate_info)
	{
		if ($rate_info !== null)
		{
			$response->headers->set('X-RateLimit-Limit', (string) $rate_info['limit']);
			$response->headers->set('X-RateLimit-Remaining', (string) $rate_info['remaining']);
			$response->headers->set('X-RateLimit-Reset', (string) $rate_info['reset']);
		}

		return $response;
	}
}
