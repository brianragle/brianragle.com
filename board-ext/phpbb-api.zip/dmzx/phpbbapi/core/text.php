<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

class text
{
	/**
	 * @param mixed	$value	a string as phpBB stores it: HTML-encoded by the request service, non-BMP characters as numeric character references
	 * @return string	plain UTF-8 text for a JSON response
	 */
	public static function plain($value)
	{
		return utf8_decode_ncr(htmlspecialchars_decode((string) $value, ENT_COMPAT));
	}
}
