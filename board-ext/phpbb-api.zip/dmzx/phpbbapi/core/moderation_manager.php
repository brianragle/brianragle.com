<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\config\config;
use phpbb\content_visibility;
use phpbb\db\driver\driver_interface;
use phpbb\log\log;
use phpbb\notification\manager as core_notification_manager;
use phpbb\user;

class moderation_manager
{
	const MAX_TITLE_LENGTH = 255;

	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var content_visibility */
	protected $visibility;

	/** @var config */
	protected $config;

	/** @var user */
	protected $user;

	/** @var log */
	protected $log;

	/** @var core_notification_manager */
	protected $notifications;

	/** @var string */
	protected $root_path;

	/** @var string */
	protected $php_ext;

	/**
	 * @param driver_interface			$db
	 * @param auth						$auth
	 * @param content_visibility		$visibility
	 * @param config					$config
	 * @param user						$user
	 * @param log						$log
	 * @param core_notification_manager	$notifications
	 * @param string					$root_path
	 * @param string					$php_ext
	 */
	public function __construct(driver_interface $db, auth $auth, content_visibility $visibility, config $config, user $user, log $log, core_notification_manager $notifications, $root_path, $php_ext)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->visibility = $visibility;
		$this->config = $config;
		$this->user = $user;
		$this->log = $log;
		$this->notifications = $notifications;
		$this->root_path = $root_path;
		$this->php_ext = $php_ext;
	}

	/**
	 * @param int	$topic_id
	 * @return void
	 */
	public function delete_topic($topic_id)
	{
		$topic = $this->load_topic($topic_id);

		if (!$this->auth->acl_get('m_delete', (int) $topic['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$this->include_admin_functions();

		$this->mod_log('LOG_DELETE_TOPIC', [
			'forum_id'	=> (int) $topic['forum_id'],
			'topic_id'	=> (int) $topic['topic_id'],
			$topic['topic_title'],
			$topic['topic_first_poster_name'],
			'',
		]);

		delete_topics('topic_id', [(int) $topic_id]);
	}

	/**
	 * @param int	$post_id
	 * @return void
	 */
	public function delete_post($post_id)
	{
		$post = $this->load_post($post_id);

		if (!$this->auth->acl_get('m_delete', (int) $post['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$this->include_admin_functions();

		$this->mod_log('LOG_DELETE_POST', [
			'forum_id'	=> (int) $post['forum_id'],
			'topic_id'	=> (int) $post['topic_id'],
			'post_id'	=> (int) $post['post_id'],
			$post['post_subject'],
			$this->poster_name($post),
			'',
		]);

		delete_posts('post_id', [(int) $post_id]);
	}

	/**
	 * @param int	$topic_id
	 * @return void
	 */
	public function lock_topic($topic_id)
	{
		$this->set_topic_status($topic_id, ITEM_LOCKED);
	}

	/**
	 * @param int	$topic_id
	 * @return void
	 */
	public function unlock_topic($topic_id)
	{
		$this->set_topic_status($topic_id, ITEM_UNLOCKED);
	}

	/**
	 * @param int	$post_id
	 * @return void
	 */
	public function approve_post($post_id)
	{
		$post = $this->load_post_for_visibility($post_id);

		if (!$this->auth->acl_get('m_approve', (int) $post['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		if (!in_array((int) $post['post_visibility'], [ITEM_UNAPPROVED, ITEM_REAPPROVE], true))
		{
			throw new api_exception('post_not_pending', 400);
		}

		$this->visibility->set_post_visibility(ITEM_APPROVED, (int) $post['post_id'], (int) $post['topic_id'], (int) $post['forum_id'], (int) $this->user->data['user_id'], time(), '', $this->is_topic_starter($post), $this->is_topic_latest($post));

		$this->mod_log('LOG_POST_APPROVED', [
			'forum_id'	=> (int) $post['forum_id'],
			'topic_id'	=> (int) $post['topic_id'],
			'post_id'	=> (int) $post['post_id'],
			$post['post_subject'],
		]);

		$this->notify_post_approved($post);
	}

	/**
	 * @param int		$post_id
	 * @param string	$reason
	 * @return void
	 */
	public function disapprove_post($post_id, $reason = '')
	{
		$post = $this->load_post_for_visibility($post_id);

		if (!$this->auth->acl_get('m_approve', (int) $post['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		if (!in_array((int) $post['post_visibility'], [ITEM_UNAPPROVED, ITEM_REAPPROVE], true))
		{
			throw new api_exception('post_not_pending', 400);
		}

		$this->include_admin_functions();

		$disapprove_topic = (int) $post['topic_posts_approved'] === 0 && (int) $post['topic_posts_softdeleted'] === 0 && (int) $post['topic_posts_unapproved'] === 1;

		$this->mod_log($disapprove_topic ? 'LOG_TOPIC_DISAPPROVED' : 'LOG_POST_DISAPPROVED', [
			'forum_id'	=> (int) $post['forum_id'],
			'topic_id'	=> (int) $post['topic_id'],
			$post['post_subject'],
			utf8_encode_ucr((string) $reason),
			$this->poster_name($post),
		]);

		delete_posts('post_id', [(int) $post['post_id']]);

		$this->notifications->delete_notifications('notification.type.post_in_queue', (int) $post['post_id']);

		if ($disapprove_topic)
		{
			$this->notifications->delete_notifications('notification.type.topic_in_queue', (int) $post['topic_id']);
		}

		if ((int) $post['poster_id'] !== ANONYMOUS)
		{
			$post['disapprove_reason'] = utf8_encode_ucr((string) $reason);
			$this->notifications->add_notifications($disapprove_topic ? 'notification.type.disapprove_topic' : 'notification.type.disapprove_post', $post);
		}
	}

	/**
	 * @param int	$post_id
	 * @return void
	 */
	public function restore_post($post_id)
	{
		$post = $this->load_post_for_visibility($post_id);

		if (!$this->auth->acl_get('m_approve', (int) $post['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		if ((int) $post['post_visibility'] !== ITEM_DELETED)
		{
			throw new api_exception('post_not_deleted', 400);
		}

		$this->visibility->set_post_visibility(ITEM_APPROVED, (int) $post['post_id'], (int) $post['topic_id'], (int) $post['forum_id'], (int) $this->user->data['user_id'], time(), '', $this->is_topic_starter($post), $this->is_topic_latest($post));

		$this->mod_log('LOG_POST_RESTORED', [
			'forum_id'	=> (int) $post['forum_id'],
			'topic_id'	=> (int) $post['topic_id'],
			'post_id'	=> (int) $post['post_id'],
			$post['post_subject'],
		]);
	}

	/**
	 * @param int		$post_id
	 * @param string	$reason
	 * @return void
	 */
	public function soft_delete_post($post_id, $reason)
	{
		$post = $this->load_post_for_visibility($post_id);

		if (!$this->auth->acl_get('m_softdelete', (int) $post['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$this->visibility->set_post_visibility(ITEM_DELETED, (int) $post['post_id'], (int) $post['topic_id'], (int) $post['forum_id'], (int) $this->user->data['user_id'], time(), utf8_encode_ucr((string) $reason), $this->is_topic_starter($post), $this->is_topic_latest($post));

		$this->mod_log('LOG_SOFTDELETE_POST', [
			'forum_id'	=> (int) $post['forum_id'],
			'topic_id'	=> (int) $post['topic_id'],
			'post_id'	=> (int) $post['post_id'],
			$post['post_subject'],
			$this->poster_name($post),
			utf8_encode_ucr((string) $reason),
		]);
	}

	/**
	 * @param int	$topic_id
	 * @return void
	 */
	public function restore_topic($topic_id)
	{
		$topic = $this->load_topic($topic_id);

		if (!$this->auth->acl_get('m_approve', (int) $topic['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$this->visibility->set_topic_visibility(ITEM_APPROVED, (int) $topic_id, (int) $topic['forum_id'], (int) $this->user->data['user_id'], time(), '');

		$this->mod_log('LOG_TOPIC_RESTORED', [
			'forum_id'	=> (int) $topic['forum_id'],
			'topic_id'	=> (int) $topic['topic_id'],
			$topic['topic_title'],
		]);
	}

	/**
	 * @param int		$topic_id
	 * @param string	$reason
	 * @return void
	 */
	public function soft_delete_topic($topic_id, $reason)
	{
		$topic = $this->load_topic($topic_id);

		if (!$this->auth->acl_get('m_softdelete', (int) $topic['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$this->visibility->set_topic_visibility(ITEM_DELETED, (int) $topic_id, (int) $topic['forum_id'], (int) $this->user->data['user_id'], time(), utf8_encode_ucr((string) $reason));

		$this->mod_log('LOG_SOFTDELETE_TOPIC', [
			'forum_id'	=> (int) $topic['forum_id'],
			'topic_id'	=> (int) $topic['topic_id'],
			$topic['topic_title'],
			$topic['topic_first_poster_name'],
			utf8_encode_ucr((string) $reason),
		]);
	}

	/**
	 * @param int	$topic_id
	 * @param int	$to_forum_id
	 * @return void
	 */
	public function move_topic($topic_id, $to_forum_id)
	{
		$topic = $this->load_topic($topic_id);

		if (!$this->auth->acl_get('m_move', (int) $topic['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$to_forum = $this->load_postable_forum($to_forum_id);

		if ((int) $topic['forum_id'] === (int) $to_forum['forum_id'])
		{
			throw new api_exception('already_in_forum', 400);
		}

		$this->include_admin_functions();

		$from_forum = $this->load_forum_name((int) $topic['forum_id']);

		move_topics([(int) $topic_id], (int) $to_forum['forum_id']);

		$this->mod_log('LOG_MOVE', [
			'forum_id'	=> (int) $to_forum['forum_id'],
			'topic_id'	=> (int) $topic['topic_id'],
			$from_forum,
			$to_forum['forum_name'],
			(int) $topic['forum_id'],
		]);
	}

	/**
	 * @param int	$topic_id
	 * @param int	$to_topic_id
	 * @param array	$post_ids
	 * @return void
	 */
	public function merge_topic($topic_id, $to_topic_id, array $post_ids = [])
	{
		$topic = $this->load_topic($topic_id);
		$to_topic = $this->load_topic($to_topic_id);

		if ((int) $topic_id === (int) $to_topic_id)
		{
			throw new api_exception('merge_same_topic', 400);
		}

		if (!$this->auth->acl_get('m_merge', (int) $topic['forum_id']) || !$this->auth->acl_get('m_merge', (int) $to_topic['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$valid_ids = $this->load_topic_post_ids($topic_id);

		if (empty($post_ids))
		{
			$post_ids = $valid_ids;
		}
		else
		{
			$post_ids = array_map('intval', $post_ids);

			if (count(array_diff($post_ids, $valid_ids)))
			{
				throw new api_exception('post_not_found', 404);
			}
		}

		if (empty($post_ids))
		{
			throw new api_exception('missing_fields', 400);
		}

		$this->include_admin_functions();

		move_posts($post_ids, (int) $to_topic_id);

		$this->mod_log('LOG_MERGE', [
			'forum_id'	=> (int) $to_topic['forum_id'],
			'topic_id'	=> (int) $to_topic['topic_id'],
			$to_topic['topic_title'],
		]);
	}

	/**
	 * @param int		$topic_id
	 * @param array		$post_ids
	 * @param string	$subject
	 * @param int		$to_forum_id
	 * @return array
	 */
	public function split_topic($topic_id, array $post_ids, $subject, $to_forum_id)
	{
		$topic = $this->load_topic($topic_id);

		if (!$this->auth->acl_get('m_split', (int) $topic['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$subject = utf8_encode_ucr(trim((string) $subject));

		if ($subject === '' || empty($post_ids))
		{
			throw new api_exception('missing_fields', 400);
		}

		if (utf8_strlen($subject) > self::MAX_TITLE_LENGTH)
		{
			throw new api_exception('title_too_long', 400);
		}

		$to_forum = $this->load_postable_forum($to_forum_id);

		$post_ids = array_values(array_map('intval', $post_ids));
		$valid_ids = $this->load_topic_post_ids($topic_id);

		if (count(array_diff($post_ids, $valid_ids)))
		{
			throw new api_exception('post_not_found', 404);
		}

		$this->include_admin_functions();

		$sql = 'INSERT INTO ' . TOPICS_TABLE . ' ' . $this->db->sql_build_array('INSERT', [
			'forum_id'			=> (int) $to_forum['forum_id'],
			'topic_title'		=> $subject,
			'icon_id'			=> 0,
			'topic_visibility'	=> ITEM_APPROVED,
		]);
		$this->db->sql_query($sql);
		$to_topic_id = (int) $this->db->sql_nextid();

		move_posts($post_ids, $to_topic_id);

		$sql = 'UPDATE ' . POSTS_TABLE . "
			SET post_subject = '" . $this->db->sql_escape($subject) . "'
			WHERE post_id = " . (int) $post_ids[0];
		$this->db->sql_query($sql);

		$this->config->increment('num_topics', 1, false);

		$this->mod_log('LOG_SPLIT_DESTINATION', [
			'forum_id'	=> (int) $to_forum['forum_id'],
			'topic_id'	=> $to_topic_id,
			$subject,
		]);
		$this->mod_log('LOG_SPLIT_SOURCE', [
			'forum_id'	=> (int) $topic['forum_id'],
			'topic_id'	=> (int) $topic['topic_id'],
			$topic['topic_title'],
		]);

		return ['topic_id' => $to_topic_id];
	}

	/**
	 * @param int	$topic_id
	 * @param int	$status		ITEM_LOCKED or ITEM_UNLOCKED
	 * @return void
	 */
	protected function set_topic_status($topic_id, $status)
	{
		$topic = $this->load_topic($topic_id);

		if (!$this->auth->acl_get('m_lock', (int) $topic['forum_id']))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		$sql = 'UPDATE ' . TOPICS_TABLE . '
			SET topic_status = ' . (int) $status . '
			WHERE topic_id = ' . (int) $topic_id;
		$this->db->sql_query($sql);

		$this->mod_log($status === ITEM_LOCKED ? 'LOG_LOCK' : 'LOG_UNLOCK', [
			'forum_id'	=> (int) $topic['forum_id'],
			'topic_id'	=> (int) $topic['topic_id'],
			'post_id'	=> 0,
			$topic['topic_title'],
		]);
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function load_topic($topic_id)
	{
		$sql = 'SELECT topic_id, forum_id, topic_status, topic_title, topic_first_poster_name
			FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('topic_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param int	$forum_id
	 * @return array
	 */
	protected function load_postable_forum($forum_id)
	{
		$sql = 'SELECT forum_id, forum_type, forum_name
			FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . (int) $forum_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row || (int) $row['forum_type'] !== FORUM_POST)
		{
			throw new api_exception('forum_not_found', 404);
		}

		$forum_id = (int) $row['forum_id'];

		if (!$this->auth->acl_get('f_post', $forum_id) || (!$this->auth->acl_get('m_approve', $forum_id) && !$this->auth->acl_get('f_noapprove', $forum_id)))
		{
			throw new api_exception('insufficient_permissions', 403);
		}

		return $row;
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function load_topic_post_ids($topic_id)
	{
		$sql = 'SELECT post_id FROM ' . POSTS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$rows = $this->db->sql_fetchrowset($result);
		$this->db->sql_freeresult($result);

		return array_map('intval', array_column($rows, 'post_id'));
	}

	/**
	 * @param int	$post_id
	 * @return array
	 */
	protected function load_post($post_id)
	{
		$sql = 'SELECT p.post_id, p.forum_id, p.topic_id, p.post_subject, p.poster_id, p.post_username, u.username
			FROM ' . POSTS_TABLE . ' p
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = p.poster_id)
			WHERE p.post_id = ' . (int) $post_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('post_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param int	$post_id
	 * @return array	the same p.*, u.*, t.*, f.* row shape phpbb_get_post_data() gives mcp_queue.php, which the notification types read
	 */
	protected function load_post_for_visibility($post_id)
	{
		$sql = 'SELECT p.*, u.*, t.*, f.*
			FROM ' . POSTS_TABLE . ' p
			LEFT JOIN ' . USERS_TABLE . ' u ON (u.user_id = p.poster_id)
			LEFT JOIN ' . TOPICS_TABLE . ' t ON (t.topic_id = p.topic_id)
			LEFT JOIN ' . FORUMS_TABLE . ' f ON (f.forum_id = p.forum_id)
			WHERE p.post_id = ' . (int) $post_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('post_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param array	$post	a load_post_for_visibility() row, read before set_post_visibility() ran
	 * @return void
	 */
	protected function notify_post_approved(array $post)
	{
		$was_visibility = (int) $post['post_visibility'];
		$topic_had_no_approved_posts = (int) $post['topic_posts_approved'] === 0;

		if ($topic_had_no_approved_posts)
		{
			$this->notifications->delete_notifications('notification.type.topic_in_queue', (int) $post['topic_id']);

			if ($was_visibility === ITEM_UNAPPROVED)
			{
				$this->notifications->add_notifications(['notification.type.topic'], $post);
			}
		}
		else if ($was_visibility === ITEM_UNAPPROVED)
		{
			$this->notifications->add_notifications(['notification.type.bookmark', 'notification.type.post'], $post);
		}

		$this->notifications->add_notifications(['notification.type.quote'], $post);
		$this->notifications->delete_notifications('notification.type.post_in_queue', (int) $post['post_id']);
		$this->notifications->mark_notifications(['notification.type.quote', 'notification.type.bookmark', 'notification.type.post'], (int) $post['post_id'], (int) $this->user->data['user_id']);

		if ((int) $post['poster_id'] !== ANONYMOUS)
		{
			$this->notifications->add_notifications($topic_had_no_approved_posts ? 'notification.type.approve_topic' : 'notification.type.approve_post', $post);
		}
	}

	/**
	 * @param array	$post	a row carrying poster_id, post_username and username
	 * @return string
	 */
	protected function poster_name(array $post)
	{
		return ((int) $post['poster_id'] === ANONYMOUS && !empty($post['post_username'])) ? (string) $post['post_username'] : (string) $post['username'];
	}

	/**
	 * @param int	$forum_id
	 * @return string
	 */
	protected function load_forum_name($forum_id)
	{
		$sql = 'SELECT forum_name FROM ' . FORUMS_TABLE . '
			WHERE forum_id = ' . (int) $forum_id;
		$result = $this->db->sql_query($sql);
		$forum_name = (string) $this->db->sql_fetchfield('forum_name');
		$this->db->sql_freeresult($result);

		return $forum_name;
	}

	/**
	 * @param string	$operation	a LOG_* moderator log key
	 * @param array		$data
	 * @return void
	 */
	protected function mod_log($operation, array $data)
	{
		$this->log->add('mod', (int) $this->user->data['user_id'], (string) $this->user->ip, $operation, false, $data);
	}

	/**
	 * @param array	$post	a load_post_for_visibility() row
	 * @return bool
	 */
	protected function is_topic_starter(array $post)
	{
		return (int) $post['post_id'] === (int) $post['topic_first_post_id'];
	}

	/**
	 * @param array	$post	a load_post_for_visibility() row
	 * @return bool
	 */
	protected function is_topic_latest(array $post)
	{
		return (int) $post['post_id'] === (int) $post['topic_last_post_id'];
	}

	/**
	 * @return void
	 */
	protected function include_admin_functions()
	{
		if (!function_exists('delete_topics'))
		{
			include($this->root_path . 'includes/functions_admin.' . $this->php_ext);
		}
	}
}
