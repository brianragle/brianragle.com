<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use phpbb\cache\driver\driver_interface as cache_driver_interface;

class rate_limiter
{
	/** @var cache_driver_interface */
	protected $cache;

	/**
	 * @param cache_driver_interface	$cache
	 */
	public function __construct(cache_driver_interface $cache)
	{
		$this->cache = $cache;
	}

	/**
	 * @param array	$credential
	 * @return array|null	null = unlimited (rate_limit <= 0), no headers to send.
	 *						Otherwise ['allowed' => bool, 'limit' => int, 'remaining' => int, 'reset' => int (unix time)]
	 */
	public function check(array $credential)
	{
		$limit = (int) $credential['rate_limit'];

		if ($limit <= 0)
		{
			return null;
		}

		$window = max(1, (int) $credential['rate_window']);
		$bucket = (int) floor(time() / $window);
		$key = '_phpbbapi_rl_' . (int) $credential['credential_id'] . '_' . $bucket;
		$reset = ($bucket + 1) * $window;

		$count = $this->cache->get($key);
		$count = ($count === false) ? 0 : (int) $count;

		if ($count >= $limit)
		{
			return ['allowed' => false, 'limit' => $limit, 'remaining' => 0, 'reset' => $reset];
		}

		$this->cache->put($key, $count + 1, $window);

		return ['allowed' => true, 'limit' => $limit, 'remaining' => max(0, $limit - $count - 1), 'reset' => $reset];
	}
}
