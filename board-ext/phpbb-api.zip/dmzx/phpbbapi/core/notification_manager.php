<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core;

use dmzx\phpbbapi\core\exception\api_exception;
use phpbb\auth\auth;
use phpbb\content_visibility;
use phpbb\db\driver\driver_interface;
use phpbb\notification\manager as core_notification_manager;
use phpbb\user;

class notification_manager
{
	const MAX_LIMIT = 100;
	const DEFAULT_LIMIT = 25;

	/** @var driver_interface */
	protected $db;

	/** @var auth */
	protected $auth;

	/** @var content_visibility */
	protected $visibility;

	/** @var core_notification_manager */
	protected $notifications;

	/** @var user */
	protected $user;

	/** @var content_reader */
	protected $content_reader;

	/**
	 * @param driver_interface			$db
	 * @param auth						$auth
	 * @param content_visibility		$visibility
	 * @param core_notification_manager	$notifications
	 * @param user						$user
	 * @param content_reader			$content_reader
	 */
	public function __construct(driver_interface $db, auth $auth, content_visibility $visibility, core_notification_manager $notifications, user $user, content_reader $content_reader)
	{
		$this->db = $db;
		$this->auth = $auth;
		$this->visibility = $visibility;
		$this->notifications = $notifications;
		$this->user = $user;
		$this->content_reader = $content_reader;
	}

	/**
	 * @param int	$limit
	 * @param int	$start
	 * @return array
	 */
	public function list_notifications($limit, $start)
	{
		$limit = $this->clamp_limit($limit);
		$start = max(0, (int) $start);

		$data = $this->notifications->load_notifications('notification.method.board', [
			'user_id'		=> (int) $this->user->data['user_id'],
			'limit'			=> $limit,
			'start'			=> $start,
			'count_total'	=> true,
			'count_unread'	=> true,
		]);

		return [
			'pagination'	=> ['limit' => $limit, 'start' => $start, 'total' => (int) $data['total_count'], 'count' => count($data['notifications'])],
			'unread_count'	=> (int) $data['unread_count'],
			'notifications'	=> array_values(array_map([$this, 'format_notification'], $data['notifications'])),
		];
	}

	/**
	 * @param int	$notification_id
	 * @return void
	 */
	public function mark_read($notification_id)
	{
		$sql = 'SELECT notification_id FROM ' . NOTIFICATIONS_TABLE . '
			WHERE notification_id = ' . (int) $notification_id . '
				AND user_id = ' . (int) $this->user->data['user_id'];
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('notification_not_found', 404);
		}

		$this->notifications->mark_notifications_by_id('notification.method.board', (int) $notification_id);
	}

	/**
	 * @param int	$topic_id
	 * @return void
	 */
	public function watch_topic($topic_id)
	{
		$topic = $this->load_topic($topic_id);

		$this->add_watch(TOPICS_WATCH_TABLE, 'topic_id', (int) $topic['topic_id']);
	}

	/**
	 * @param int	$topic_id
	 * @return void
	 */
	public function unwatch_topic($topic_id)
	{
		$this->load_topic($topic_id);

		$this->remove_watch(TOPICS_WATCH_TABLE, 'topic_id', (int) $topic_id);
	}

	/**
	 * @param int	$forum_id
	 * @return void
	 */
	public function watch_forum($forum_id)
	{
		$forum = $this->load_forum($forum_id);

		$this->add_watch(FORUMS_WATCH_TABLE, 'forum_id', (int) $forum['forum_id']);
	}

	/**
	 * @param int	$forum_id
	 * @return void
	 */
	public function unwatch_forum($forum_id)
	{
		$this->load_forum($forum_id);

		$this->remove_watch(FORUMS_WATCH_TABLE, 'forum_id', (int) $forum_id);
	}

	/**
	 * @param string	$table
	 * @param string	$id_column
	 * @param int		$item_id
	 * @return void
	 */
	protected function add_watch($table, $id_column, $item_id)
	{
		$user_id = (int) $this->user->data['user_id'];

		$sql = 'SELECT 1 FROM ' . $table . '
			WHERE ' . $id_column . ' = ' . (int) $item_id . '
				AND user_id = ' . $user_id;
		$result = $this->db->sql_query($sql);
		$exists = (bool) $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if ($exists)
		{
			return;
		}

		$this->db->sql_query('INSERT INTO ' . $table . ' ' . $this->db->sql_build_array('INSERT', [
			$id_column		=> (int) $item_id,
			'user_id'		=> $user_id,
			'notify_status'	=> 0,
		]));
	}

	/**
	 * @param string	$table
	 * @param string	$id_column
	 * @param int		$item_id
	 * @return void
	 */
	protected function remove_watch($table, $id_column, $item_id)
	{
		$this->db->sql_query('DELETE FROM ' . $table . '
			WHERE ' . $id_column . ' = ' . (int) $item_id . '
				AND user_id = ' . (int) $this->user->data['user_id']);
	}

	/**
	 * @param int	$topic_id
	 * @return array
	 */
	protected function load_topic($topic_id)
	{
		$sql = 'SELECT topic_id, forum_id, topic_visibility, topic_type, topic_poster
			FROM ' . TOPICS_TABLE . '
			WHERE topic_id = ' . (int) $topic_id;
		$result = $this->db->sql_query($sql);
		$row = $this->db->sql_fetchrow($result);
		$this->db->sql_freeresult($result);

		if (!$row)
		{
			throw new api_exception('topic_not_found', 404);
		}

		$this->content_reader->assert_forum_readable((int) $row['forum_id']);

		if (!$this->visibility->is_visible('topic', (int) $row['forum_id'], $row))
		{
			throw new api_exception('topic_not_found', 404);
		}

		return $row;
	}

	/**
	 * @param int	$forum_id
	 * @return array
	 */
	protected function load_forum($forum_id)
	{
		return $this->content_reader->assert_forum_readable((int) $forum_id);
	}

	/**
	 * @param \phpbb\notification\type\type_interface	$notification
	 * @return array
	 */
	protected function format_notification($notification)
	{
		return [
			'notification_id'	=> (int) $notification->notification_id,
			'title'				=> strip_tags($notification->get_title()),
			'url'				=> $notification->get_url(),
			'time'				=> (int) $notification->notification_time,
			'unread'			=> !$notification->notification_read,
		];
	}

	/**
	 * @param int	$limit
	 * @return int
	 */
	protected function clamp_limit($limit)
	{
		$limit = (int) $limit;

		if ($limit <= 0)
		{
			return self::DEFAULT_LIMIT;
		}

		return min(self::MAX_LIMIT, $limit);
	}
}
