<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\event;

use phpbb\event\data;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		return [
			'core.permissions'	=> 'add_permissions',
		];
	}

	/**
	 * @param data	$event
	 * @return void
	 */
	public function add_permissions(data $event)
	{
		$event['permissions'] = array_merge($event['permissions'], [
			'a_phpbbapi'	=> ['lang' => 'ACL_A_PHPBBAPI', 'cat' => 'misc'],
		]);
	}
}
