<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\cron\task;

use dmzx\phpbbapi\core\audit_logger;
use dmzx\phpbbapi\core\webhook_dispatcher;
use phpbb\config\config;
use phpbb\cron\task\base;

class prune_logs extends base
{
	const RUN_INTERVAL = 86400;

	/** @var config */
	protected $config;

	/** @var audit_logger */
	protected $audit_logger;

	/** @var webhook_dispatcher */
	protected $webhook_dispatcher;

	/**
	 * @param config				$config
	 * @param audit_logger			$audit_logger
	 * @param webhook_dispatcher	$webhook_dispatcher
	 */
	public function __construct(config $config, audit_logger $audit_logger, webhook_dispatcher $webhook_dispatcher)
	{
		$this->config = $config;
		$this->audit_logger = $audit_logger;
		$this->webhook_dispatcher = $webhook_dispatcher;
	}

	/**
	 * {@inheritdoc}
	 */
	public function run()
	{
		$days = (int) $this->config['phpbbapi_log_retention_days'];

		if ($days > 0)
		{
			$before = time() - ($days * 86400);

			$this->audit_logger->prune($before);
			$this->webhook_dispatcher->prune_log($before);
		}

		$this->config->set('phpbbapi_log_last_prune', time(), false);
	}

	/**
	 * {@inheritdoc}
	 */
	public function is_runnable()
	{
		return (int) $this->config['phpbbapi_log_retention_days'] > 0;
	}

	/**
	 * {@inheritdoc}
	 */
	public function should_run()
	{
		return (int) $this->config['phpbbapi_log_last_prune'] < time() - self::RUN_INTERVAL;
	}
}
