<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\migrations;

class v1_0_1_unicode_columns extends \phpbb\db\migration\migration
{
	/**
	 * @return array
	 */
	public static function depends_on()
	{
		return ['\dmzx\phpbbapi\migrations\install_phpbbapi'];
	}

	/**
	 * @return array
	 */
	public function update_schema()
	{
		return [
			'change_columns' => [
				$this->table_prefix . 'phpbbapi_credentials' => [
					'name'	=> ['VCHAR_UNI:100', ''],
				],
				$this->table_prefix . 'phpbbapi_webhooks' => [
					'name'	=> ['VCHAR_UNI:100', ''],
				],
				$this->table_prefix . 'phpbbapi_webhook_log' => [
					'response_snippet'	=> ['VCHAR_UNI:255', ''],
				],
			],
		];
	}

	/**
	 * @return array
	 */
	public function revert_schema()
	{
		return [
			'change_columns' => [
				$this->table_prefix . 'phpbbapi_credentials' => [
					'name'	=> ['VCHAR:100', ''],
				],
				$this->table_prefix . 'phpbbapi_webhooks' => [
					'name'	=> ['VCHAR:100', ''],
				],
				$this->table_prefix . 'phpbbapi_webhook_log' => [
					'response_snippet'	=> ['VCHAR:255', ''],
				],
			],
		];
	}
}
