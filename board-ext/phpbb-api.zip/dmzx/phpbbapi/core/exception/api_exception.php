<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\core\exception;

class api_exception extends \RuntimeException
{
	/** @var string */
	protected $error_code;

	/** @var int */
	protected $http_status;

	/**
	 * @param string	$error_code
	 * @param int		$http_status
	 */
	public function __construct($error_code, $http_status)
	{
		parent::__construct($error_code);

		$this->error_code = $error_code;
		$this->http_status = $http_status;
	}

	/**
	 * @return string
	 */
	public function get_error_code()
	{
		return $this->error_code;
	}

	/**
	 * @return int
	 */
	public function get_http_status()
	{
		return $this->http_status;
	}
}
