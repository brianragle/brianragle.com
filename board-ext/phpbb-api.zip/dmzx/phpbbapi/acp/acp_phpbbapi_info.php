<?php
/**
 *
 * phpBB API. An extension for phpBB.
 *
 * @copyright (c) 2026 dmzx - https://www.dmzx-web.net
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace dmzx\phpbbapi\acp;

class acp_phpbbapi_info
{
	function module()
	{
		return [
			'filename'	=> '\dmzx\phpbbapi\acp\acp_phpbbapi_module',
			'title'		=> 'ACP_PHPBBAPI_TITLE',
			'modes'		=> [
				'overview'	=> [
					'title'	=> 'ACP_PHPBBAPI_OVERVIEW_TITLE',
					'auth'	=> 'ext_dmzx/phpbbapi && acl_a_phpbbapi',
					'cat'	=> ['ACP_CAT_DOT_MODS'],
				],
				'credentials'	=> [
					'title'	=> 'ACP_PHPBBAPI_CREDENTIALS_TITLE',
					'auth'	=> 'ext_dmzx/phpbbapi && acl_a_phpbbapi',
					'cat'	=> ['ACP_CAT_DOT_MODS'],
				],
				'log'	=> [
					'title'	=> 'ACP_PHPBBAPI_LOG_TITLE',
					'auth'	=> 'ext_dmzx/phpbbapi && acl_a_phpbbapi',
					'cat'	=> ['ACP_CAT_DOT_MODS'],
				],
				'settings'	=> [
					'title'	=> 'ACP_PHPBBAPI_SETTINGS_TITLE',
					'auth'	=> 'ext_dmzx/phpbbapi && acl_a_phpbbapi',
					'cat'	=> ['ACP_CAT_DOT_MODS'],
				],
				'webhooks'	=> [
					'title'	=> 'ACP_PHPBBAPI_WEBHOOKS_TITLE',
					'auth'	=> 'ext_dmzx/phpbbapi && acl_a_phpbbapi',
					'cat'	=> ['ACP_CAT_DOT_MODS'],
				],
				'webhook_log'	=> [
					'title'	=> 'ACP_PHPBBAPI_WEBHOOK_LOG_TITLE',
					'auth'	=> 'ext_dmzx/phpbbapi && acl_a_phpbbapi',
					'cat'	=> ['ACP_CAT_DOT_MODS'],
				],
			],
		];
	}
}
